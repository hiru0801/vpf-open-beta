"""Read club facts and player registrations for a specified VPF season."""

import re
from collections import defaultdict
from urllib.parse import parse_qs, urlsplit

POSITIONS = ('Thủ môn','Hậu vệ','Tiền vệ','Tiền đạo')
PLAYER_PATH = re.compile(r'/player/([a-z0-9-]+)/?')
STAFF_PREFIXES = ('hlv-', 'cbptkt-', 'tro-ly-', 'truong-doan-', 'bac-si-', 'phien-dich-')
FOUNDING_SOURCES = {
    'TNG': (2026, ['Hội Nhà báo Thái Nguyên · Thành lập CLB bóng đá nam', 'https://hoinhabao.thainguyen.gov.vn/vi/news/chinh-tri-thoi-su/thai-nguyen-chao-don-clb-bong-da-nam-tro-ve-san-sang-cho-mua-giai-moi-4590.html']),
    'BEC': (1976, ['Thanh Niên · Lịch sử Becamex Bình Dương', 'https://thanhnien.vn/bbinh-duong-bieu-lo-tham-vong-qua-ao-dau-moi-1851314065.htm']),
    'VHI': (2024, ['Bóng đá 24h · Lịch sử Đại học Văn Hiến', 'https://www.bongda24h.vn/bong-da-viet-nam/doi-sinh-vien-di-vao-lich-su-bong-da-viet-nam-168-433826-amp.html']),
}


def player_id(hrefs):
    """A VPF player slug is stable across ?sid= season/competition variants."""
    ids=set()
    for href in hrefs:
        location=urlsplit(href)
        hit=PLAYER_PATH.fullmatch(location.path)
        if location.netloc=='vpf.vn' and location.scheme=='https' and hit:
            ids.add(hit[1])
    return next(iter(ids)) if len(ids)==1 else None


def club_links(document, clubs, sid, text, aliases, fold):
    candidates=defaultdict(set)
    for link in document.xpath('//*[contains(@class,"jsMatchDivHome") or contains(@class,"jsMatchDivAway")]//a[contains(@href,"/team/")]'):
        name,url=text(link),link.get('href')
        if not name or parse_qs(urlsplit(url).query).get('sid')!=[sid]:
            continue
        for key,club in clubs.items():
            if fold(name) in aliases(club):
                candidates[key].add(url)
    return {key:next(iter(urls)) for key,urls in candidates.items() if len(urls)==1}


def profile(document, key, club, text, fold, aliases):
    names=document.xpath('//article//h2')
    if len(names)!=1 or fold(text(names[0])) not in aliases(club):
        raise ValueError('Hồ sơ VPF không khớp tên CLB.')
    table=document.xpath('//*[@id="stab_players_stats"]//table[.//th[contains(.,"Số áo")]]')
    if len(table)!=1:
        raise ValueError('Không tìm thấy một danh sách cầu thủ.')
    players=[]
    for row in table[0].xpath('.//tr[td]'):
        cells=row.xpath('./td')
        name,position,number=map(text,cells[:3])
        identity=player_id(cells[0].xpath('.//a/@href'))
        registered=position in POSITIONS or (not position and number.isdecimal() and identity and not identity.startswith(STAFF_PREFIXES))
        if registered and name:
            players.append(dict(name=name,position=position or None,number=int(number) if number else None,
                                **({'playerId':identity} if identity else {})))
    if not players:
        raise ValueError('Hồ sơ VPF chưa có cầu thủ.')
    players.sort(key=lambda p:(POSITIONS.index(p['position']) if p['position'] else len(POSITIONS),
                               p['number'] is None,p['number'] or 0,p['name']))
    fields={}
    for heading in document.xpath('//article//p[contains(concat(" ",normalize-space(@class)," ")," jo-title ")]'):
        value=' '.join(text(node) for node in heading.itersiblings()).strip()
        if text(heading).casefold()=='sân nhà':
            fields['stadium']=re.sub(r'\s*\(sức chứa:.*\)\s*$', '', value, flags=re.I).strip()
        if text(heading).casefold()=='huấn luyện viên':
            fields['coach']=value
    if not fields.get('stadium') or not fields.get('coach'):
        raise ValueError('Thiếu sân nhà hoặc HLV trên hồ sơ VPF.')
    main=document.xpath('//*[@id="stab_main"]')
    history=text(main[0]) if main else ''
    found=re.findall(r'(?:Năm thành lập\s*:\s*|thành lập năm\s+|thành lập ngày\s+\d{1,2}\s+tháng\s+\d{1,2}\s+năm\s+)(\d{4})',history,re.I)
    if len(set(found))==1:
        fields['year']=int(found[0])
    elif key in FOUNDING_SOURCES:
        fields['year'],fields['yearSource']=FOUNDING_SOURCES[key]
    return {**fields,'players':players}
