"""Build and seal one reviewed web release. Place the output on static hosting."""

import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile

from audit import json_text
from release_inputs import APP, input_hash, paths, tree_hash


def build(candidate_path, database, output):
    raw=candidate_path.read_bytes()
    candidate=json.loads(raw)
    current=(APP/'updates.json').read_bytes()
    digest=hashlib.sha256(json_text(candidate).encode()).hexdigest()
    revision=candidate['revision']
    if candidate.get('schema')!=2:
        raise ValueError('Cần dữ liệu có mã mùa (schema 2).')
    if database.is_relative_to(APP) or database.is_relative_to(output):
        raise ValueError('Đặt SQLite ngoài thư mục mã nguồn và thư mục phát hành.')
    if not database.is_file():
        raise ValueError('Chưa có nhật ký SQLite.')
    if output.exists():
        raise FileExistsError('Thư mục bản phát hành đã tồn tại.')
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.vpf-build-',dir=output.parent) as temp:
        work=Path(temp)/'source'
        for name in paths(APP):
            dest=work/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(APP/name,dest)
        code_digest=input_hash(work)
        with closing(sqlite3.connect(database,timeout=8)) as conn:
            recorded=conn.execute('SELECT digest,input_digest FROM release WHERE revision=?',(revision,)).fetchone()
            if recorded!=(digest,code_digest):
                raise ValueError('Dữ liệu hoặc mã nguồn khác bản đã duyệt. Dùng bản đã duyệt hoặc nâng revision.')
            (work/'updates.json').write_bytes(current)
            draft=work/'draft.json'
            draft.write_bytes(raw)
            command=['node',str(work/'tools/publish.cjs')]
            if candidate!=json.loads(current):
                subprocess.run([*command,'--verify-next',str(draft)],check=True)
                command.append(str(draft))
            subprocess.run(command,check=True)
            release_id=hashlib.sha256((digest+code_digest).encode()).hexdigest()[:24]
            public=Path(temp)/'public'
            public.mkdir()
            subprocess.run(['node',str(work/'tools/build-web.cjs'),release_id,str(public)],check=True)
            subprocess.run([sys.executable,str(work/'tools/prepare-assets.py'),str(work/'assets'),
                            str(public/'releases'/release_id/'assets')],check=True)
            shutil.copytree(work/'calendars',public/'calendars')
            files=sorted(p.relative_to(public).as_posix() for p in public.rglob('*') if p.is_file())
            artifact=tree_hash(public,files)
            (public/'release-files.json').write_text(json_text({
                'releaseId':release_id,'artifactDigest':artifact,
                'files':{name:hashlib.sha256((public/name).read_bytes()).hexdigest() for name in files},
            })+'\n',encoding='utf-8')
            with conn:
                conn.execute('BEGIN IMMEDIATE')
                prior=conn.execute('SELECT artifact_digest FROM release WHERE revision=?',(revision,)).fetchone()[0]
                if prior and prior!=artifact:
                    raise ValueError('Tệp đầu ra khác bản đã niêm phong cho revision này.')
                conn.execute('UPDATE release SET artifact_digest=? WHERE revision=?',(artifact,revision))
        public.rename(output)
    print(f'Bản web {revision} · {release_id} · {output}')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--draft',type=Path,default=APP/'updates.json')
    parser.add_argument('--db',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:
        build(args.draft.resolve(),args.db.resolve(),args.out.resolve())
    except (ValueError,OSError,sqlite3.Error,subprocess.CalledProcessError) as error:
        parser.exit(1,str(error)+'\n')


if __name__=='__main__':
    main()
