"""Validate HTTPS serving, version consistency, calendar access and source freshness."""
import argparse
from datetime import datetime, timedelta, timezone
import json
import re
from urllib.parse import urljoin, urlsplit
from urllib.request import urlopen


def recent(value, maximum):
    try:
        age=datetime.now(timezone.utc)-datetime.fromisoformat(value)
    except (TypeError,ValueError):
        return False
    return -timedelta(minutes=5)<=age<=maximum


def run(base, allow_local, check_freshness):
    url=urlsplit(base)
    if url.scheme!='https' and not (allow_local and url.hostname in ('127.0.0.1','localhost')):
        raise ValueError('Bản beta cần HTTPS. HTTP chỉ dùng cho thử cục bộ.')
    errors=[]

    def get(path):
        with urlopen(urljoin(base.rstrip('/')+'/',path),timeout=8) as response:
            if response.status!=200 or urlsplit(response.geturl()).netloc!=url.netloc:
                raise ValueError('Đường dẫn chuyển hướng ngoài máy chủ: '+path)
            return response.headers,response.read(4_000_000)

    def expect(condition,label):
        print(('PASS · ' if condition else 'FAIL · ')+label)
        if not condition:
            errors.append(label)

    _,payload=get('release-info.json')
    release=json.loads(payload)
    rid=release['releaseId']
    if not re.fullmatch(r'[a-f0-9]{24}',rid):
        raise ValueError('Mã bản Web sai định dạng.')
    print('Web rev '+str(release['revision'])+' · '+rid)
    headers,index=get('index.html')
    expect('releases/'+rid+'/index-data.js' in index.decode(),'HTML khớp mã release')
    expect('no-cache' in headers.get('Cache-Control',''),'HTML được xác thực lại')
    expect("frame-ancestors 'none'" in headers.get('Content-Security-Policy',''),'Chặn nhúng trang qua HTTP header')
    if url.scheme=='https':
        expect(bool(headers.get('Strict-Transport-Security')),'HSTS có mặt')
    headers,_=get('releases/'+rid+'/index-data.js')
    expect('immutable' in headers.get('Cache-Control',''),'Tài nguyên có mã release được cache dài hạn')
    _,worker=get('worker.js')
    expect(rid.encode() in worker,'Service worker khớp mã release')
    headers,calendar=get('calendars/SLN.ics')
    expect(calendar.startswith(b'BEGIN:VCALENDAR') and b'UID:' in calendar,'Lịch CLB phục vụ qua URL và có UID')
    expect(headers.get_content_type()=='text/calendar','Content-Type lịch là text/calendar')
    _,raw=get('data-status.json')
    status=json.loads(raw)
    _,raw=get('news-feed.json')
    news=json.loads(raw)
    sources={'bongdaplus','thanhnien','znews','vtc','vnexpress','vff'}
    expect(news.get('schema')==1 and bool(news.get('articles')) and len(news['articles'])<=120
           and set(news.get('sources',{}))==sources and all(row.get('source') in sources for row in news['articles']),
           'Bản tin hợp lệ và giới hạn ở sáu nguồn đã chọn')
    if check_freshness:
        expect(news.get('mode')=='sync','Bộ đồng bộ đang phục vụ JSON tin tức ngoài bản chụp')
        expect(status.get('schema')==1 and status.get('mode')=='sync' and status.get('state')=='ok'
               and recent(status.get('lastSuccessfulCheckAt'),timedelta(hours=3)),'Bộ đồng bộ đọc được dữ liệu trận từ VPF trong 3 giờ')
        expect(recent(status.get('lastHighlightCheckAt'),timedelta(hours=3)),'Kho video VPF đã được kiểm tra trong 3 giờ')
        for source in sorted(sources):
            state=news.get('sources',{}).get(source,{})
            expect(state.get('status')=='ok' and recent(state.get('checkedAt'),timedelta(minutes=20)),'Đã đọc nguồn tin '+source)
    return not errors


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('url')
    parser.add_argument('--local-http',action='store_true')
    parser.add_argument('--snapshot',action='store_true',help='Chỉ kiểm tra phục vụ bản tĩnh và HTTP headers')
    args=parser.parse_args()
    try:
        raise SystemExit(0 if run(args.url,args.local_http,not args.snapshot) else 1)
    except (OSError,ValueError,KeyError,TypeError) as error:
        parser.exit(1,str(error)+'\n')
