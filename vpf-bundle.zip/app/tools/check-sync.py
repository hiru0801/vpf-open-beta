"""Exercise scheduled fixtures and older scorer corrections without network access."""

from copy import deepcopy
from datetime import datetime, timedelta
from html import escape
import json
from pathlib import Path
import runpy
import subprocess
from tempfile import TemporaryDirectory

from lxml import html

ROOT=Path(__file__).resolve().parents[1]
tool=runpy.run_path(str(ROOT/'tools/backfill-vpf.py'))
source=tool['source']
published=datetime.fromisoformat(json.loads((ROOT/'updates.json').read_text())['publishedAt'])
at=(published+timedelta(hours=1)).isoformat(timespec='milliseconds')
snapshot=tool['snapshot']()
fixture_id='vl1-9-SLN-NBI'
older_id='nc-11'
fixture=snapshot['matches'][fixture_id]
older=snapshot['matches'][older_id]
match_url='https://vpf.vn/match/qa-fixture/'


def calendar_html(match, *, kickoff, venue='', score='v', linked=True):
    year,month,day=match['date'].split('-')
    home,away=(snapshot['clubs'][match[key]]['name'] for key in ('homeClub','awayClub'))
    if linked:
        score=f'<a href="{match_url}">{escape(score)}</a>'
    return html.fromstring(f'''<div class="js-matchday-wrapper">
      <div>{day} Tháng {int(month)}, {year}</div>
      <div class="js-matchday-matches"><div class="jstable-row">
        <div class="jsMatchDivTime">{escape(kickoff)}</div>
        <div class="jsMatchDivVenue">{escape(venue)}</div>
        <div class="js-ma-tran">{match.get('tie','')}</div>
        <div class="jsMatchDivHome">{escape(home)}</div>
        <div class="jsMatchDivAway">{escape(away)}</div>
        <div class="jsMatchDivScore">{score}</div>
      </div></div></div>''')


def valid_candidate(draft):
    subprocess.run(['node','tools/publish.cjs','--check','-'],cwd=ROOT,
                   input=json.dumps(draft,ensure_ascii=False).encode(),check=True)


with TemporaryDirectory() as temp:
    cache=Path(temp)
    newest=calendar_html(fixture,kickoff='19:00',venue='SVĐ Sân QA')
    source['cached_page']=lambda *_:newest
    draft,_=tool['prepare'](cache,at,['vl1'],True,10)
    entry=draft['matches'][-1]
    assert entry['id']==fixture_id and entry['patch']=={'time':'19:00','venue':'Sân QA'}
    valid_candidate(draft)

    newest=calendar_html(fixture,kickoff='Hoãn thi đấu',score='',linked=False)
    draft,_=tool['prepare'](cache,at,['vl1'],True,10)
    assert draft['matches'][-1]['patch']=={'status':'postponed','date':None,'time':None}
    valid_candidate(draft)

    newest=calendar_html(fixture,kickoff='',venue='Thông báo sau')
    draft,_=tool['prepare'](cache,at,['vl1'],True,10)
    assert draft is None

    newest=calendar_html(older,kickoff=older['time'],score='2 - 3')
    events=deepcopy(older['events'])
    goal=next(event for event in events if event['minute']=='77' and event['type']=='goal')
    goal.update(name='Lê Minh Bình',number=68,playerId='le-minh-binh')
    source['parse_match']=lambda *args,**kwargs: (dict(date=older['date'],score=older['score'],
                                                      events=deepcopy(events)),[])
    draft,_=tool['prepare'](cache,at,['nc'],True,10)
    assert draft is None
    draft,_=tool['prepare'](cache,at,['nc'],True,None)
    assert draft['matches'][-1]['id']==older_id
    assert any(event['name']=='Lê Minh Bình' for event in draft['matches'][-1]['patch']['events'])
    valid_candidate(draft)

    goal.update(name='Cầu thủ QA',number=99,playerId='qa-player')
    draft,report=tool['prepare'](cache,at,['nc'],True,None)
    assert draft is None and report[older_id]['pendingReview']

print('PASS · đổi giờ/sân, hoãn, dữ liệu trống, đối chiếu bàn cũ và hàng chờ xác minh.')
