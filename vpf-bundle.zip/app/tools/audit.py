"""Private SQLite log for audited VPF release drafts."""

import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import os
import sqlite3
import subprocess

from release_inputs import APP, input_hash
SCHEMA = """
CREATE TABLE IF NOT EXISTS release (
  revision INTEGER PRIMARY KEY,
  published_at TEXT NOT NULL,
  digest TEXT NOT NULL UNIQUE,
  snapshot TEXT NOT NULL,
  input_digest TEXT,
  artifact_digest TEXT
);
CREATE TABLE IF NOT EXISTS match_review (
  revision INTEGER NOT NULL REFERENCES release(revision),
  entry INTEGER NOT NULL,
  match_id TEXT NOT NULL,
  source TEXT NOT NULL,
  fields TEXT NOT NULL,
  checks TEXT NOT NULL,
  note TEXT NOT NULL,
  PRIMARY KEY (revision, entry)
);
CREATE INDEX IF NOT EXISTS review_match ON match_review(match_id, revision);
"""


def json_text(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def record(db, feed_path):
    code_digest = input_hash()
    payload = feed_path.read_bytes()
    subprocess.run(['node', str(APP / 'tools' / 'publish.cjs'), '--check', '-'], input=payload, check=True)
    feed = json.loads(payload)
    snapshot = json_text(feed)
    digest = hashlib.sha256(snapshot.encode()).hexdigest()
    revision = feed['revision']
    if input_hash() != code_digest:
        raise ValueError('Mã nguồn đã đổi khi đang kiểm tra.')
    with db:
        db.execute('BEGIN IMMEDIATE')
        existing = db.execute('SELECT digest,input_digest FROM release WHERE revision = ?', (revision,)).fetchone()
        if existing:
            if existing[0] != digest or existing[1] not in (None,code_digest):
                raise ValueError('Phiên bản này đã có nội dung khác trong nhật ký.')
            if existing[1] is None:
                db.execute('UPDATE release SET input_digest=? WHERE revision=?',(code_digest,revision))
            print(f'Đã lưu bản {revision} từ trước.')
            return
        db.execute('INSERT INTO release (revision,published_at,digest,snapshot,input_digest) VALUES (?, ?, ?, ?, ?)',
                   (revision,feed['publishedAt'],digest,snapshot,code_digest))
        db.executemany('INSERT INTO match_review VALUES (?, ?, ?, ?, ?, ?, ?)', [
            (revision, i, item['id'], item['source'][1], json_text(list(item['patch'])),
             json_text(item.get('checks', [])), item.get('note', ''))
            for i, item in enumerate(feed['matches'], 1)
        ])
    print(f'Đã lưu bản {revision} cùng {len(feed["matches"])} mục đối chiếu.')


def show(db, match_id=None):
    if match_id:
        rows = db.execute(
            'SELECT revision, match_id, source, fields, checks, note FROM match_review '
            'WHERE match_id = ? ORDER BY revision, entry', (match_id,)
        )
        for revision, match, source, fields, checks, note in rows:
            print(json_text(dict(revision=revision, match=match, source=source, fields=json.loads(fields),
                                 checks=json.loads(checks), note=note)))
    else:
        for row in db.execute('SELECT revision, published_at, digest FROM release ORDER BY revision'):
            print(*row, sep=' · ')


def main():
    parser = argparse.ArgumentParser(description='Nhật ký đối chiếu dữ liệu VPF')
    parser.add_argument('--db', required=True, type=Path, help='Tệp SQLite ở ngoài thư mục web')
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('record', help='Ghi bản dữ liệu đã kiểm tra').add_argument('feed', type=Path)
    commands.add_parser('show', help='Xem các mục đã ghi').add_argument('--match')
    args = parser.parse_args()
    path = args.db.resolve()
    if path.is_relative_to(APP):
        parser.error('Đặt tệp SQLite ngoài thư mục chứa ứng dụng.')
    if args.command == 'show' and not path.is_file():
        parser.error('Chưa có tệp SQLite.')
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    if not path.exists():
        try:
            os.close(os.open(path, flags, 0o600))
        except FileExistsError:
            pass
    try:
        with closing(sqlite3.connect(path, timeout=8)) as db:
            db.execute('PRAGMA foreign_keys = ON')
            db.executescript(SCHEMA)
            columns={row[1] for row in db.execute('PRAGMA table_info(release)')}
            for name in ('input_digest','artifact_digest'):
                if name not in columns:
                    db.execute(f'ALTER TABLE release ADD COLUMN {name} TEXT')
            if args.command == 'record':
                record(db, args.feed.resolve())
            else:
                show(db, args.match)
    except (OSError, ValueError, subprocess.CalledProcessError, sqlite3.Error) as error:
        parser.exit(1, str(error) + '\n')


if __name__ == '__main__':
    main()
