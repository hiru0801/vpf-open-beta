"""Publish a small independent headline index from six editorial sites."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
import argparse
import gzip
from html import unescape
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path
import re
import subprocess
from tempfile import NamedTemporaryFile
from time import sleep
import unicodedata
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener
from zoneinfo import ZoneInfo

from lxml import etree, html

APP = Path(__file__).resolve().parents[1]
VN = ZoneInfo('Asia/Ho_Chi_Minh')
VFF = 'https://www.vff.org.vn/chuyen-muc/giai-quoc-gia/bong-da-nam-cac-giai-quoc-gia/'
SOURCES = (
    ('bongdaplus', 'https://bongdaplus.vn/v-league', 'vl1'),
    ('bongdaplus', 'https://bongdaplus.vn/hang-nhat-quoc-gia', 'vl2'),
    ('bongdaplus', 'https://bongdaplus.vn/cup-quoc-gia', 'nc'),
    ('bongdaplus', 'https://bongdaplus.vn/bong-da-viet-nam', None),
    ('vnexpress', 'https://vnexpress.net/the-thao/v-league', 'vl1'),
    ('vff', VFF+'giai-vo-dich-quoc-gia-v-league-1/', 'vl1'),
    ('vff', VFF+'giai-hang-nhat-quoc-gia-v-league-2/', 'vl2'),
    ('vff', VFF+'giai-cup-quoc-gia-national-cup/', 'nc'),
    ('znews', 'https://znews.vn/bong-da-viet-nam.html', None),
    ('vtc', 'https://vtcnews.vn/bong-da-viet-nam-115.html', None),
    ('thanhnien', 'https://thanhnien.vn/the-thao/bong-da-viet-nam.htm', None),
    ('thanhnien', 'https://thanhnien.vn/rss/the-thao/bong-da-viet-nam.rss', None),
)
ANCHORS = {
    'bongdaplus': '//a[contains(concat(" ",normalize-space(@class)," ")," title ")]',
    'vff': '//a[.//h4[@class="title"]]',
    'vnexpress': '//h3[contains(@class,"title-news")]/a',
    'znews': '//h3[@class="article-title"]/a',
    'vtc': '//article//h2/a|//article//h3/a',
    'thanhnien': '//a[@data-linktype="newsdetail"]',
}
ARTICLE_PATH = {
    'bongdaplus': r'/[^/]+/[^/]+-\d+\.html',
    'vff': r'/[^/]+/',
    'vnexpress': r'/[^/]+-\d+\.html',
    'znews': r'/[^/]+-post\d+\.html',
    'vtc': r'/[^/]+-ar\d+\.html',
    'thanhnien': r'/[^/]+-\d+\.htm',
}
HOSTS = {key:{urlsplit(url).hostname} for key,url,_ in SOURCES}
HOSTS['bongdaplus'].add('s27.bongdaplus.vn')
HOSTS['vtc'].add('www.vtcnews.vn')
HOSTS['vff'].add('vff.org.vn')
ALIASES = {
    'HNO': ('Hà Nội FC','CLB Hà Nội','Hà Nội vs','Hà Nội gặp'),
    'TCV': ('Thể Công','Viettel'), 'SLN': ('SLNA',), 'HAG': ('HAGL',),
    'HLH': ('Hà Tĩnh',), 'DNA': ('Đà Nẵng',), 'HCM': ('CA TP HCM','CA TPHCM','CA TP Hồ Chí Minh'),
    'DNC': ('Trường Tươi Đồng Nai',), 'BEC': ('Becamex','Becamex Bình Dương'),
    'TPH': ('CLB TP HCM','CLB TP Hồ Chí Minh','Ho Chi Minh City FC'),
    'HUE': ('CLB Huế','Huế FC','Huế vs','Huế gặp','gặp Huế','vs Huế'),
}
LEAGUES = {
    'vl1': r'\b(?:v league(?! 2\b)|vleague(?! 2\b)|lpbank v league|vdqg)\b',
    'vl2': r'\b(?:v league 2|vleague 2|(?:giai|bong da) hang nhat(?! (?:anh|duc|phap|tay ban nha)\b)|hang nhat quoc gia|hnqg)\b',
    'nc': r'\b(?:cup (?:bong da )?quoc gia|cup qg|sacombank national cup)\b',
}
OTHER = re.compile(r'\b(?:u (?:1[5-9]|2[0-3])|u(?:1[5-9]|2[0-3])|world cup|doi tuyen|tuyen viet nam|afc champions|c[12] chau a|giai chau a|chau a|shopee cup|futsal|bong da nu|hang nhi|hang ba|sieu cup|melbourne victory|vissel kobe)\b')
FOOTBALL = re.compile(r'\b(?:bong da|clb|fc|hlv|doi bong|cau thu|vong|tran|da|ban thang|chuyen nhuong|thang|thua|hoa|nhan dinh|vs)\b')
MAX_PER_SECTION = 22
MAX_PER_PUBLISHER = 20
MAX_ARTICLES = 120
AGE = timedelta(days=120)
BONGDAPPLUS_SECTIONS={'v-league':'vl1','hang-nhat-quoc-gia':'vl2','cup-quoc-gia':'nc'}


def fold(value):
    value = unicodedata.normalize('NFKD', unescape(value).lower().replace('đ', 'd'))
    return ' '.join(re.findall(r'[a-z0-9]+', ''.join(c for c in value if not unicodedata.combining(c))))


def club_patterns(clubs):
    patterns = {}
    for cid, club in clubs.items():
        names = (*club.get('aliases', ()), club['name'], *ALIASES.get(cid, ()))
        if cid in ('HNO','TPH','HUE'):
            names = ALIASES[cid]
        options = sorted({fold(name) for name in names if len(fold(name)) >= 4}, key=len, reverse=True)
        patterns[cid] = re.compile(r'\b(?:'+'|'.join(map(re.escape, options))+r')\b')
    return patterns


def classify(title, context, section, clubs, patterns):
    main = fold(title)
    body = main+' '+fold(context)
    # Longest/specific labels first so Công an TP.HCM is not tagged as TP.HCM FC.
    ids = [cid for cid, rx in patterns.items() if rx.search(body)]
    named = any(patterns[cid].search(main) for cid in ids)
    leagues = [key for key, pattern in LEAGUES.items() if re.search(pattern, main)]
    if 'vl2' in leagues and not re.search(r'\bv ?league 1\b',main):
        leagues = [key for key in leagues if key!='vl1']
    if OTHER.search(main) and not section:
        return [], []
    if section:
        leagues = list(dict.fromkeys([section,*leagues]))
    if not leagues:
        leagues = [key for key,pattern in LEAGUES.items() if re.search(pattern,body)]
    if not leagues and named and (FOOTBALL.search(main) or len(ids)>1):
        leagues = list(dict.fromkeys(clubs[cid]['league'] for cid in ids))
    return (leagues, ids) if leagues else ([], [])


def article_url(source, value, base):
    if not value:
        return None
    url = urlsplit(urljoin(base,value))
    if url.scheme!='https' or url.netloc not in HOSTS[source] or not re.fullmatch(ARTICLE_PATH[source],url.path):
        return None
    if source=='vff' and ('/chuyen-muc/' in url.path or url.path.startswith(('/wp-', '/tag/'))):
        return None
    return urlunsplit(('https',url.netloc,url.path,'',''))


class SourceRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old, new = urlsplit(req.full_url), urlsplit(newurl)
        if new.scheme!='https' or old.netloc!=new.netloc:
            raise ValueError('Chuyển sang tên miền khác')
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def fetch(url, cache=None):
    filename = cache/(hashlib.sha256(url.encode()).hexdigest()+'.html') if cache else None
    if filename and filename.exists():
        return filename.read_bytes()
    request = Request(url,headers={'User-Agent':'VPF-App-NguonTin/1.0','Accept-Encoding':'identity',
                                   'Cache-Control':'no-cache'})
    opener = build_opener(SourceRedirect())
    for attempt in range(2):
        try:
            with opener.open(request,timeout=10) as response:
                raw = response.read(3_000_001)
            break
        except (HTTPError, URLError, TimeoutError) as error:
            transient = (error.code in (502,503,504) if isinstance(error,HTTPError) else
                         isinstance(getattr(error,'reason',error),TimeoutError))
            if attempt or not transient:
                raise
            sleep(1)
    if len(raw)>3_000_000:
        raise ValueError('Trang vượt giới hạn dung lượng')
    if raw[:2]==b'\x1f\x8b':
        with gzip.GzipFile(fileobj=BytesIO(raw)) as compressed:
            raw = compressed.read(3_000_001)
    if len(raw)>3_000_000:
        raise ValueError('Trang vượt giới hạn sau giải nén')
    if filename:
        filename.write_bytes(raw)
    return raw


def parse_date(value):
    value = ' '.join(value.split()).strip()
    value = re.sub(r'([+-])(\d):(\d{2})$',r'\g<1>0\2:\3',value)
    try:
        mark = datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError:
        try:
            mark = parsedate_to_datetime(value)
        except (ValueError,TypeError):
            vn = re.search(r'(\d{1,2}:\d{2})\s+(\d{1,2}/\d{1,2}/\d{4})|(\d{1,2}/\d{1,2}/\d{4})\D+(\d{1,2}:\d{2})',value)
            if not vn:
                return None
            try:
                mark = datetime.strptime(' '.join((vn[2] or vn[3],vn[1] or vn[4])),'%d/%m/%Y %H:%M')
            except ValueError:
                return None
    return (mark if mark.tzinfo else mark.replace(tzinfo=VN)).astimezone(VN)


def page(raw):
    return html.fromstring(raw.decode('utf-8-sig',errors='replace'))


def listing(source, url, raw):
    if url.endswith('.rss'):
        xml = etree.fromstring(raw,etree.XMLParser(resolve_entities=False,no_network=True))
        for item in xml.xpath('//item'):
            title = item.findtext('title','')
            context = page(('<div>'+item.findtext('description','')+'</div>').encode()).text_content()
            yield title,item.findtext('link',''),context,item.findtext('pubDate','')
        return
    doc = page(raw)
    anchors = doc.xpath(ANCHORS[source])
    if not anchors:
        raise ValueError('Chuyên mục không trả danh sách bài đọc được')
    for node in anchors:
        parents = node.xpath('ancestor::article[1]|ancestor::div[contains(concat(" ",normalize-space(@class)," ")," box-category-content ") or @class="info"][1]')
        box = parents[-1] if parents else node.getparent()
        note = ' '.join(box.xpath('.//*[self::p or self::div][contains(@class,"desc") or contains(@class,"summ") or contains(@class,"excerpt")]//text()'))
        when = box.xpath('.//time/@datetime|.//time/text()')
        yield node.get('title') or node.text_content(),node.get('href'),note,' '.join(when)


def article_metadata(raw):
    doc = page(raw)
    props = doc.xpath('//meta[@property="article:published_time" or @name="pubdate" or @name="publishdate" or @itemprop="datePublished"]/@content')
    stamps = []
    for script in doc.xpath('//script[@type="application/ld+json"]/text()'):
        stamps += re.findall(r'"datePublished"\s*:\s*"([^"]+)"',script)
    stamps.extend(props)
    stamps.extend(doc.xpath('//time/@datetime|//time/text()'))
    summary = doc.xpath('//meta[@name="description" or @property="og:description"]/@content')
    return next((date for label in stamps if (date:=parse_date(label))),None),' '.join(summary[:1])


def atomic_json(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with NamedTemporaryFile(dir=path.parent,delete=False,mode='w',encoding='utf-8') as output:
        json.dump(value,output,ensure_ascii=False,separators=(',',':'))
        output.write('\n')
        os.fchmod(output.fileno(),0o644)
    Path(output.name).replace(path)


def run(path, cache, now):
    raw = subprocess.check_output(['node','-e',"global.window={};require('./data.js');console.log(JSON.stringify(window.VPF_DATA.clubs))"],cwd=APP)
    clubs = json.loads(raw)
    patterns = club_patterns(clubs)
    old = json.loads(path.read_text()) if path.exists() else {}
    publishers={name for name,_,_ in SOURCES}
    items = {row['url']:row for row in old.get('articles',[]) if row.get('source') in publishers
             and (published:=parse_date(row['publishedAt'])) and now-AGE<=published<=now+timedelta(minutes=5)}
    checks = {name:state for name,state in old.get('sources',{}).items() if name in publishers}
    section_checks = {}

    def scan(config):
        source,url,section = config
        try:
            rows = list(listing(source,url,fetch(url,cache)))
            return config,rows,None
        except (OSError,ValueError,etree.LxmlError) as error:
            return config,[],str(error)

    pending = {}
    results = {}
    with ThreadPoolExecutor(max_workers=8) as pool:
        for (source,url,section),rows,error in pool.map(scan,SOURCES):
            results.setdefault(source,[]).append(error)
            accepted = set()
            for title,href,summary,raw_date in rows:
                link = article_url(source,href,url)
                if not link or link in accepted:
                    continue
                article_section=section
                if source=='bongdaplus':
                    article_section=BONGDAPPLUS_SECTIONS.get(urlsplit(link).path.split('/')[1])
                    # The domestic landing page also lists national teams and youth leagues.
                    if not article_section:
                        continue
                title = ' '.join(unescape(title).split())
                leagues,ids = classify(title,summary,article_section,clubs,patterns)
                if not 8<=len(title)<=270 or not leagues or len(accepted)>=MAX_PER_SECTION:
                    continue
                accepted.add(link)
                if link in items or link in pending:
                    continue
                pending[link]=(source,title,leagues,ids,article_section,raw_date)
            section_checks[url]={'publisher':source,'found':len(accepted),'status':'unavailable' if error else 'ok'}

        def collect(link):
            source,title,leagues,ids,section,raw_date = pending[link]
            mark = parse_date(raw_date)
            if not mark:
                try:
                    mark,summary = article_metadata(fetch(link,cache))
                    proposed,teams = classify(title,summary,section,clubs,patterns)
                    if not section and not any(re.search(p,fold(title)) for p in LEAGUES.values()) and OTHER.search(fold(summary)):
                        return link,None
                    leagues = list(dict.fromkeys([*leagues,*proposed]))
                    ids = list(dict.fromkeys([*ids,*teams]))
                except (OSError,ValueError,etree.LxmlError):
                    return link,None
            if not mark or not now-AGE<=mark<=now+timedelta(minutes=5):
                return link,None
            return link,dict(source=source,title=title,url=link,publishedAt=mark.isoformat(timespec='seconds'),leagues=leagues,clubs=ids)

        detail_counts = {name:[0,0] for name in publishers}
        for link,row in pool.map(collect,pending):
            detail_counts[pending[link][0]][0]+=1
            if row:
                detail_counts[row['source']][1]+=1
                items[link]=row

    for source,errors in results.items():
        attempted,parsed=detail_counts[source]
        if any(error is None for error in errors) and (not attempted or parsed):
            checks[source]={'status':'ok' if not any(errors) else 'partial','checkedAt':now.isoformat(timespec='seconds')}
        else:
            checks[source]={**checks.get(source,{}),'status':'unavailable'}
    # Keep a bounded share of the feed per publisher so selective filters stay useful.
    retained = []
    counts = {}
    order = lambda item: (item['publishedAt'],item['url'])
    for source in results:
        unique = {}
        for item in sorted(items.values(),key=order,reverse=True):
            if item['source']==source:
                unique.setdefault(fold(item['title']),item)
        newest = list(unique.values())
        # Always keep the newest headlines first; reserve slots only for the remainder.
        reserved = {item['url']:item for item in newest[:10]}
        reserved.update({item['url']:item for league in LEAGUES
                    for item in [row for row in newest if league in row['leagues']][:4]}
        )
        for item in newest:
            if len(reserved)>=MAX_PER_PUBLISHER:
                break
            reserved.setdefault(item['url'],item)
        if reserved:
            retained.extend(list(reserved.values())[:MAX_PER_PUBLISHER])
            counts[source]=min(len(reserved),MAX_PER_PUBLISHER)
    retained.sort(key=order,reverse=True)
    last_success=max((info['checkedAt'] for info in checks.values() if info.get('checkedAt')),default=None)
    atomic_json(path,dict(schema=1,mode='snapshot' if cache else 'sync',checkedAt=now.isoformat(timespec='seconds'),lastSuccessfulCheckAt=last_success,
                          sources=checks,articles=retained[:MAX_ARTICLES]))
    print(json.dumps(dict(total=len(retained),kept=counts,sections=section_checks,
                          failed={key:next(x for x in errors if x) for key,errors in results.items() if all(errors)}),ensure_ascii=False))
    return bool(retained) and all(status['status']=='ok' for status in checks.values())


def check_health(path, now):
    payload=json.loads(path.read_text())
    sources=payload.get('sources',{})
    deadline=now-timedelta(minutes=20)
    fresh=[name for name,state in sources.items() if state.get('status')=='ok' and
           (stamp:=parse_date(state.get('checkedAt',''))) and deadline<=stamp<=now+timedelta(minutes=5)]
    expected={name for name,_,_ in SOURCES}
    print(json.dumps({'fresh':sorted(fresh),'delayed':sorted(expected-set(fresh))},ensure_ascii=False))
    return expected.issubset(fresh)


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--output',required=True,type=Path,help='Đường dẫn news-feed.json phục vụ công khai')
    cli.add_argument('--cache',type=Path,help='Chỉ dùng khi tái hiện kiểm thử')
    cli.add_argument('--check-health',action='store_true',help='Báo lỗi nếu bất kỳ nguồn nào gián đoạn hoặc quá 20 phút chưa đọc được')
    opts=cli.parse_args()
    if opts.cache:
        opts.cache.mkdir(parents=True,exist_ok=True)
    try:
        now=datetime.now(VN)
        passed=check_health(opts.output,now) if opts.check_health else run(opts.output,opts.cache,now)
    except (OSError,ValueError,KeyError,TypeError,subprocess.CalledProcessError) as error:
        cli.exit(1,str(error)+'\n')
    raise SystemExit(0 if passed else 1)
