"""Inputs that determine the identity of a VPF release."""

from hashlib import sha256
import json
import re
from pathlib import Path, PurePosixPath

APP = Path(__file__).resolve().parents[1]
RUNTIME = ('index.html','styles.css','data.js','data-update.js','calendar.js',
           'theme.js','match-view.js','competition-view.js','web-data.js','news-view.js',
           'news-snapshot.js','app.js','worker.js')
BUILD = ('tools/publish.cjs','tools/build-web.cjs','tools/release.py','tools/release_inputs.py',
         'tools/prepare-assets.py')


def paths(root):
    assets=sorted(p.relative_to(root).as_posix() for p in (root/'assets').rglob('*') if p.is_file())
    return (*RUNTIME,*BUILD,*assets)


def tree_hash(root, names):
    digest=sha256()
    for name in sorted(names):
        file=root/name
        if file.is_symlink():
            raise ValueError(f'Tệp phát hành phải là tệp thông thường: {name}')
        digest.update(name.encode()+b'\x00'+sha256(file.read_bytes()).digest())
    return digest.hexdigest()


def input_hash(root=APP):
    return tree_hash(root, paths(root))



def verify_bundle(root, expected=None, *, allow_retained=False):
    """Check the sealed files against their hashes and, for deployment, SQLite."""
    manifest=json.loads((root/'release-files.json').read_text(encoding='utf-8'))
    metadata=json.loads((root/'release-info.json').read_text(encoding='utf-8'))
    release_id=metadata['releaseId']
    prefix=f'releases/{release_id}/'
    if not re.fullmatch(r'[a-f0-9]{24}',release_id) or metadata['root']!=prefix or manifest['releaseId']!=release_id:
        raise ValueError('Sai mã bản phát hành.')
    files=manifest['files']
    for name in files:
        path=PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or path.as_posix()!=name:
            raise ValueError('Sai đường dẫn trong manifest: '+name)
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    extra=actual-set(files)-{'release-files.json'}
    if allow_retained:
        extra={name for name in extra if name.startswith(prefix) or not re.fullmatch(r'releases/[a-f0-9]{24}/.+',name)}
    if not set(files).issubset(actual) or extra or any(p.is_symlink() for p in root.rglob('*')):
        raise ValueError('Danh sách tệp phát hành không khớp manifest.')
    for name,digest in files.items():
        if sha256((root/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Mã băm tệp phát hành không khớp: '+name)
    digest=tree_hash(root,files)
    if digest!=manifest['artifactDigest'] or expected is not None and digest!=expected:
        raise ValueError('Mã băm gói phát hành không khớp bản niêm phong.')
    return metadata
