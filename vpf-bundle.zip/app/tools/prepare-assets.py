"""Prepare the web image and font variants from the original offline assets."""

from pathlib import Path
import shutil
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont

source,output=map(Path,sys.argv[1:])
output.mkdir(parents=True)
for file in sorted(source.iterdir()):
    if file.suffix.lower() in ('.png','.webp','.jpg','.jpeg'):
        with Image.open(file) as original:
            size=192 if not file.name.startswith('club-') else 144
            image=original.convert('RGBA')
            image.thumbnail((size,size),Image.Resampling.LANCZOS)
            image.save(output/(file.stem+'.webp'),'WEBP',quality=88,method=6)
    elif file.suffix.lower() in ('.txt','.md'):
        shutil.copyfile(file,output/file.name)

font=output/'InterVariable.woff2'
subprocess.run([sys.executable,'-m','fontTools.subset',str(source/font.name),
                '--unicodes=U+0020-024F,U+0300-036F,U+1E00-1EFF,U+2000-206F,U+20A0-20CF,U+2190-21FF,U+2212,U+2304',
                f'--output-file={font}','--flavor=woff2'],check=True)
cmap=TTFont(font).getBestCmap()
if any(ord(char) not in cmap for char in 'Đđấằểễệưộỷ'):
    raise ValueError('Font thiếu ký tự tiếng Việt.')
if 0x2304 not in cmap:
    raise ValueError('Font web thiếu dấu mũi tên của nút Đổi giải.')

for size in (180,192,512):
    icon=Image.new('RGB',(size,size),'#172b49')
    draw=ImageDraw.Draw(icon)
    scale=size/192
    draw.rounded_rectangle((28*scale,28*scale,164*scale,164*scale),radius=28*scale,
                           fill='#244776',outline='#c2d7f4',width=round(2*scale))
    title=ImageFont.load_default(size=round(44*scale))
    draw.text((size/2,size/2),'VPF',font=title,fill='#ffffff',anchor='mm')
    icon.save(output/f'app-{size}.png',optimize=True)
