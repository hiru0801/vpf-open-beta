"""Verify a built web directory against its manifest and published data."""

import argparse
import gzip
import json
from pathlib import Path
import subprocess

from release_inputs import APP, verify_bundle


def check(directory):
    latest=verify_bundle(directory)
    files={p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
    assert all(not set(Path(name).parts).intersection(
        {'tools','updates.json','data-published.js','data.js','README.md'}) for name in files)
    root=directory/latest['root']
    boot=root/'index-data.js'
    n=boot.stat().st_size
    assert n<=120000
    verify="""
const fs=require('node:fs');
const [dir,app]=process.argv.slice(1);
const {compile,goalCounts,scorerTables,clubStatTables}=require(app+'/data-update.js');
global.window={};
require(app+'/data.js');
const base=window.VPF_DATA, update=compile(base,require(app+'/updates.json'));
const expected={...base.matches,...update.matches};
require(dir+'/index-data.js');
const {VPF_DATA:data,VPF_WEB_RELEASE:release}=window;
for (const [id,match] of Object.entries(data.matches)) {
  if (match.hasDetail) {
    const detail=require(dir+'/matches/'+id+'.json');
    if(detail.releaseId!==release.releaseId||detail.id!==id) throw Error(id);
    Object.assign(match,detail.data);
  }
  const prior=expected[id];
  for (const key of ['date','time','venue','score','events','matchSquads','penalties','status','watchUrl','highlightUrl']) {
    if(JSON.stringify(match[key]??null)!==JSON.stringify(prior[key]??null)) throw Error(id+' '+key);
  }
  if(match.score && match.events && goalCounts(match.events).some((n,i)=>n!==match.score[i])) throw Error(id+' goals');
}
for (const [id,roster] of Object.entries(update.rosters)) {
  const body=require(dir+'/clubs/'+id+'.json');
  if(body.releaseId!==release.releaseId || JSON.stringify(roster)!==JSON.stringify(body.data)) throw Error(id);
  if (data.clubs[id].coach!==roster.coach||data.clubs[id].stadium!==roster.stadium||data.clubs[id].roster.length!==0) throw Error(id+' profile');
}
if (JSON.stringify(data.scorers)!==JSON.stringify(scorerTables(base.ties,expected,update.rosters))) throw Error('Scorers mismatch');
if (JSON.stringify(data.clubStats)!==JSON.stringify(clubStatTables(base.leagues,base.ties,expected))) throw Error('Club stats mismatch');
if (Object.keys(expected).length!==Object.keys(data.matches).length) throw Error('Missing matches');
"""
    subprocess.run(['node','-e',verify,str(root.resolve()),str(APP)],check=True)
    for path in (directory/'calendars').glob('*.ics'):
        assert path.read_bytes()==(APP/'calendars'/path.name).read_bytes(),path
    assert len(list((directory/'calendars').glob('*.ics')))==28
    print(f'PASS · {latest["releaseId"]} · {len(files)} tệp · dữ liệu mở {n:,} B ({len(gzip.compress(boot.read_bytes())):,} B gzip) · 28 lịch.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    check(parser.parse_args().directory.resolve())
