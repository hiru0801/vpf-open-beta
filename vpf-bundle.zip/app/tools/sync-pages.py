"""Refresh the published GitHub Pages bundle and its Git-backed checkpoint."""

import argparse
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from release_inputs import APP, verify_bundle


def command(*args, check=True):
    return subprocess.run(args, cwd=APP, check=check).returncode


def copy_immutable_assets(source, target):
    for directory in (source/'releases').iterdir():
        shutil.copytree(directory, target/directory.name)


def run(state, output, seed, force_vpf):
    sync = runpy.run_path(str(APP/'tools/sync-vpf.py'))
    read, now, public_health = (sync[key] for key in ('read', 'now', 'public_health'))
    expires = sync['expired']
    state.mkdir(parents=True, exist_ok=True)
    work = state/'vpf'
    sealed = state/'sealed'
    previous_assets = state/'previous-assets'
    data = state/'updates.json'
    status = state/'data-status.json'
    news = state/'news-feed.json'

    if not sealed.exists():
        shutil.copytree(seed,sealed)
        shutil.copy2(APP/'updates.json',data)
        shutil.copy2(seed/'data-status.json',status)
        shutil.copy2(seed/'news-feed.json',news)
    metadata = verify_bundle(sealed)
    assert read(data)['revision'] == metadata['revision'], 'Bản phát hành lệch mã dữ liệu đã lưu.'
    shutil.copyfile(data, APP/'updates.json')

    news_error = command(sys.executable,'tools/sync-news.py','--output',str(news),check=False)
    if not read(news).get('lastSuccessfulCheckAt'):
        shutil.copyfile(seed/'news-feed.json',news)

    health_path = work/'sync-status.json'
    health = read(health_path) if health_path.exists() else {}
    vpf_error = False
    if force_vpf or expires(health.get('startedAt'),now(),55/60):
        draft = work/'draft.json'
        draft.unlink(missing_ok=True)
        vpf_error = command(sys.executable,'tools/sync-vpf.py','--state',str(work),check=False)
        latest_health = read(health_path) if health_path.exists() else {**health,'status':'error'}
        if not vpf_error:
            if draft.exists():
                with TemporaryDirectory(prefix='new-release-',dir=state) as temp:
                    temp=Path(temp)
                    rebuilt=temp/'web'
                    command(sys.executable,'tools/audit.py','--db',str(temp/'review.sqlite'),'record',str(draft))
                    command(sys.executable,'tools/release.py','--db',str(temp/'review.sqlite'),'--draft',str(draft),'--out',str(rebuilt))
                    command('node','tools/publish.cjs',str(draft))
                    command(sys.executable,'tools/check-release.py',str(rebuilt))
                    if previous_assets.exists():
                        shutil.rmtree(previous_assets)
                    previous_assets.mkdir()
                    copy_immutable_assets(sealed, previous_assets)
                    shutil.rmtree(sealed)
                    rebuilt.rename(sealed)
                    shutil.copyfile(draft,data)
            public_health(status,latest_health)
        elif latest_health.get('lastSuccessfulCheckAt'):
            public_health(status,{**latest_health,'status':'error'})
        draft.unlink(missing_ok=True)
        for scratch in ('lock.sqlite','latest-check.json','highlight-check.json'):
            (work/scratch).unlink(missing_ok=True)
    elif health.get('status')!='ok':
        vpf_error=True

    verify_bundle(sealed)
    shutil.copytree(sealed,output)
    if previous_assets.exists():
        for asset in previous_assets.iterdir():
            dest=output/'releases'/asset.name
            if not dest.exists():
                shutil.copytree(asset,dest)
    shutil.copyfile(news,output/'news-feed.json')
    shutil.copyfile(status,output/'data-status.json')
    # This manifest authenticates the sealed bundle in the checkpoint. The
    # published tree additionally contains mutable status, news and old assets.
    (output/'release-files.json').unlink()
    print(json.dumps({'news_ok':not news_error,'vpf_ok':not vpf_error}))
    return not (news_error or vpf_error)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state',type=Path,required=True)
    parser.add_argument('--seed',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--force-vpf',action='store_true')
    args=parser.parse_args()
    ok=run(args.state.resolve(),args.output.resolve(),args.seed.resolve(),args.force_vpf)
    raise SystemExit(0 if ok else 2)
