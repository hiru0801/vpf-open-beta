'use strict';

// Exercise the real static server locally, never send a load test to a hosted URL.
const http=require('node:http');
const https=require('node:https');
const {performance}=require('node:perf_hooks');

const origin=new URL(process.argv[2]||'http://127.0.0.1:8975');
const total=Number(process.argv[3]||30000), clients=Number(process.argv[4]||256);
if (!['127.0.0.1','[::1]'].includes(origin.hostname) ||
    !Number.isInteger(total) || total<1 || total>100000 ||
    !Number.isInteger(clients) || clients<1 || clients>1024) {
  throw Error('Chỉ chạy trên máy cục bộ với tối đa 100.000 yêu cầu và 1.024 kết nối.');
}
const transport=origin.protocol==='https:'?https:http;
const agent=new transport.Agent({keepAlive:true,maxSockets:clients});
function request(path, keep=false) {
  return new Promise((resolve,reject)=>{
    const started=performance.now();
    const req=transport.get(new URL(path,origin),{
      agent,headers:keep?{}:{'accept-encoding':'gzip'}
    },res=>{
      const chunks=[];
      let size=0;
      res.on('data',chunk=>{size+=chunk.length;if (keep) chunks.push(chunk);});
      res.on('error',reject);
      res.on('end',()=>resolve({ms:performance.now()-started,status:res.statusCode,body:Buffer.concat(chunks),size}));
    });
    req.setTimeout(5000,()=>req.destroy(new Error('timeout')));
    req.on('error',reject);
  });
}

async function main() {
  const metadata=await request('/release-info.json',true);
  if (metadata.status!==200) throw Error('Không lấy được mã release.');
  const {root}=JSON.parse(metadata.body);
  const index='/'+root+'index-data.js';
  const detail='/'+root+'matches/vl1-1-DNC-TCV.json';
  const paths=['/release-info.json','/data-status.json','/news-feed.json','/index.html',
    index,detail,'/calendars/SLN.ics','/news-feed.json',detail,'/release-info.json'];
  // One controlled warm-up per endpoint before concurrent measurement.
  for (const path of new Set(paths)) if ((await request(path)).status!==200) throw Error(path);
  const times=[], counts={};
  let sent=0, failures=0, bytes=0;
  const started=performance.now();
  async function reader() {
    while (sent<total) {
      const path=paths[sent++%paths.length];
      try {
        const result=await request(path);
        counts[path]=(counts[path]||0)+1;
        if (result.status!==200 || !result.size) failures++;
        else {
          times.push(result.ms);
          bytes+=result.size;
        }
      } catch {
        failures++;
      }
    }
  }
  await Promise.all(Array.from({length:clients},reader));
  const seconds=(performance.now()-started)/1000;
  times.sort((a,b)=>a-b);
  const quantile=p=>Math.round(times[Math.max(0,Math.ceil(times.length*p)-1)]*10)/10;
  console.log(JSON.stringify({total,clients,seconds:Math.round(seconds*100)/100,failures,
    requestsPerSecond:Math.round(total/seconds),p50ms:quantile(.50),p95ms:quantile(.95),p99ms:quantile(.99),bytes,counts},null,2));
  if (failures) process.exitCode=1;
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>agent.destroy());
