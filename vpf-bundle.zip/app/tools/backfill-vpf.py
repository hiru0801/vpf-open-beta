"""Prepare a reviewed data draft from VPF calendars, match pages and club profiles."""

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import json
from pathlib import Path
import runpy
import re
import subprocess
from urllib.parse import parse_qs, urlsplit

from vpf_clubs import club_links, profile
from vpf_highlights import discover

source = runpy.run_path(str(Path(__file__).with_name('import-vpf.py')))
APP = source['APP']
CALENDARS = {
    'vl1': ('V.League 1', '154439', source['CALENDAR']),
    'vl2': ('Hạng Nhất', '154445', 'https://vpf.vn/season/hang-nhat-quoc-gia-2027/?action=calendar&pagejs=1'),
    'nc': ('Cúp Quốc gia', '154454', 'https://vpf.vn/season/cup-quoc-gia-2027/?action=calendar&pagejs=1'),
}
TEXT = source['text']
FOLD = source['club_key']


def club_aliases(club):
    return {FOLD(name) for name in [club['name'], *club.get('aliases', [])]}


def snapshot(candidate=None):
    script = """
const {compile,sideId}=require('./data-update.js');
global.window={}; require('./data.js');
const input=require('node:fs').readFileSync(0,'utf8');
const base=window.VPF_DATA, update=compile(base,input?JSON.parse(input):require('./updates.json'));
const matches={...base.matches,...update.matches};
for (const m of Object.values(matches)) {
  m.homeClub=sideId(base.ties,matches,m.home);
  m.awayClub=sideId(base.ties,matches,m.away);
}
console.log(JSON.stringify({...base,matches}));
"""
    return json.loads(subprocess.check_output(['node','-e',script],cwd=APP,
                                             input=json.dumps(candidate).encode() if candidate else b''))


def official_standings(cache, data, league, at, prior):
    link=data['sources'][league+'table']
    page=source['cached_page'](link[1],cache,league+'-table.html')
    table=source['one'](page,'//table[.//th[contains(.,"Điểm")]]')
    club_ids=data['leagues'][league]['clubs']
    rows=[]
    for row in table.xpath('.//tbody/tr[td]'):
        rank,name,played,wins,draws,losses,goals,diff,*_,points=map(TEXT,row.xpath('./td'))
        matches=[key for key in club_ids if FOLD(name) in club_aliases(data['clubs'][key])]
        if len(matches)!=1:
            raise ValueError('Không khớp CLB trong bảng VPF: '+name)
        numbers=[int(value) for value in (rank,played,wins,draws,losses,*goals.split(' - '),diff,points)]
        rows.append([numbers[0],matches[0],*numbers[1:]])
    if len(rows)!=len(club_ids):
        raise ValueError('Bảng VPF chưa đủ số đội '+league)
    value=dict(at=at,source=link,rows=rows)
    if prior.get('adjustments'):
        value['adjustments']=prior['adjustments']
    return value


def cross_check(match_id, patch):
    # Sampled public pages are consulted only to compare their published facts.
    links = {
        'vl2-6-XPT-BEC': ['Sofascore · Kết quả trận', 'https://www.sofascore.com/football/match/xuan-thien-phu-tho-becamex-ho-chi-minh-city-fc/umnsAECc'],
        'nc-11': ['DBscore · Kết quả trận', 'https://dbscore.com/fixture/20210704/hoang-anh-gia-lai-hung-yen'],
    }
    observed = {'vl2-6-XPT-BEC':['2026-10-31',[1,2]], 'nc-11':['2026-09-20',[2,3]]}
    if match_id not in links or observed[match_id] != [patch.get('date'),patch.get('score')]:
        return []
    return [dict(source=links[match_id],fields=['date','score'],outcome='agrees')]


def schedule_entry(match, row, league_name, calendar, now):
    # A kickoff in a season overview does not by itself confirm a provisional slot.
    if row.postponed:
        values = dict(status='postponed', date=None, time=None, window=None, scheduleNote=None)
    elif row.url and row.kickoff and match['status'] in ('scheduled', 'postponed'):
        values = dict(status='scheduled', date=row.date, time=row.kickoff, window=None)
        if match['status']=='postponed':
            values['scheduleNote'] = None
        venue_key=FOLD(row.venue)
        if venue_key not in ('','thongbaosau','chuaxacdinh','dangcapnhat','tbd') and venue_key!=FOLD(match.get('venue') or ''):
            values['venue'] = row.venue
    else:
        return None
    patch = {field:value for field,value in values.items() if value!=match.get(field)}
    if not patch:
        return None
    return dict(id=match['id'], at=now, source=[f'VPF · Lịch {league_name}', calendar], patch=patch)


def prepare(cache, now, selected=tuple(CALENDARS), include_results=False, recent_days=None):
    data=snapshot()
    feed=json.loads((APP/'updates.json').read_text(encoding='utf-8'))
    if data['season']!='2026/27':
        raise ValueError('Cần khai báo lịch và mã mùa VPF trước khi nhập mùa mới.')
    reports, jobs, club_jobs, entries = {}, [], {}, []
    for league in selected:
        league_name,sid,calendar = CALENDARS[league]
        doc=source['cached_page'](calendar,cache,('cup' if league=='nc' else league)+'.html')
        official=list(source['calendar_rows'](doc))
        if not official:
            raise ValueError('Không đọc được lịch VPF của '+league_name+'. Giữ bản đang phục vụ.')
        for m in data['matches'].values():
            if m['league']!=league or (not m.get('score') and not include_results):
                continue
            if not m.get('homeClub') or not m.get('awayClub'):
                continue
            aliases=[club_aliases(data['clubs'][m[key]]) for key in ('homeClub','awayClub')]
            candidates=[row for row in official if all(FOLD(n) in a for n,a in zip(row.teams,aliases))]
            if league=='nc':
                # The official pair number separates recurring club pairings.
                candidates=[row for row in candidates if row.number==str(m['tie']) or not row.number]
            same_day=[row for row in candidates if row.date==m.get('date')]
            hits=same_day or candidates
            if not hits and m['status'] not in ('final','scheduled','postponed'):
                continue
            if len(hits)!=1:
                reports[m['id']]=dict(source=calendar,pendingReview=True,issues=['Chưa ghép được duy nhất trận trong lịch VPF.'])
                continue
            row=hits[0]
            if row.score is None:
                if m.get('score'):
                    reports[m['id']]=dict(source=calendar,pendingReview=True,issues=['Lịch VPF thiếu tỷ số đã duyệt.'])
                else:
                    entry=schedule_entry(m,row,league_name,calendar,now)
                    if entry:
                        entries.append(entry)
                        reports[m['id']]=dict(source=calendar,schedule=entry['patch'],issues=[])
                continue
            if not row.url or not row.kickoff:
                reports[m['id']]=dict(source=calendar,pendingReview=True,issues=['Thiếu trang trận hoặc giờ thi đấu để kiểm tra tỷ số.'])
                continue
            if m.get('score') and recent_days is not None and m['score']==row.score and m.get('date')==row.date:
                cutoff=(datetime.fromisoformat(now).date()-timedelta(days=recent_days)).isoformat()
                if m['date']<cutoff:
                    continue
            jobs.append((m,row,league_name,sid,calendar))
        if league in ('vl1','vl2'):
            clubs={key:data['clubs'][key] for key in data['leagues'][league]['clubs']}
            located=club_links(doc,clubs,sid,TEXT,club_aliases,FOLD)
            club_jobs.update(located)
            for key in clubs.keys()-located.keys():
                reports['club-'+key]=dict(issues=['Chưa có liên kết hồ sơ duy nhất trong lịch VPF.'])
    def one_match(job):
        m,row,league_name,sid,calendar=job
        day,names,score,url,kickoff,penalties,*_=row
        mid=m['id']
        try:
            page=source['cached_page'](url,cache,mid+'.html')
            expected={**m,'date':day,'time':kickoff,'score':None,'penalties':penalties}
            patch,notes=source['parse_match'](page,expected,names,score,sid,verify_penalties=m['league']=='nc')
            if kickoff!=m.get('time'):
                patch['time']=kickoff
            if m.get('window'):
                patch['window']=None
            if m['score']!=score and m.get('goals'):
                patch['goals']=None
        except (ValueError, OSError, subprocess.CalledProcessError) as error:
            return None,(mid,dict(source=url,pendingReview=True,issues=[str(error)]))
        protected = set()
        pending_review = False
        for published in feed['matches']:
            if published['id']!=mid:
                continue
            for check in published.get('checks',[]):
                if check['outcome']=='differs' or (
                    published['source'][0].startswith('VPF · Báo cáo trận') and check['source'][1]==url
                ):
                    fields=check['fields'] if check['outcome']=='differs' else published['patch']
                    protected.update({'events','matchSquads'}.intersection(fields))
        for key in protected:
            if key in patch and patch[key]!=m.get(key):
                patch.pop(key)
                pending_review = True
                notes.append(f'Giữ quyết định đã duyệt cho {key}; thay đổi mới cần đối chiếu thủ công.')
        original=m.get('events') or []
        def identity(events):
            return [(e['side'],e['type'],e['minute'],e['number'],e.get('playerId') or FOLD(e['name'])) for e in events]
        if 'events' in patch and identity(patch['events'])==identity(original):
            patch.pop('events')
        if 'matchSquads' in patch and m.get('matchSquads') and not all(patch['matchSquads']):
            patch.pop('matchSquads')
        events=patch.get('events',original)
        squads=patch.get('matchSquads',m.get('matchSquads') or [])
        goals=Counter(e['side'] for e in events if e['type'] in ('goal','penalty','ownGoal'))
        def listed(event,squad):
            if not squad:
                return False
            for player in squad['starters']+squad['substitutes']:
                if event.get('playerId') and player.get('playerId'):
                    if event['playerId']==player['playerId']:
                        return True
                elif FOLD(event['name'])==FOLD(player['name']) and (
                    player['number'] is None or event['number'] in (None,player['number'])):
                    return True
            return False

        previous_squads=m.get('matchSquads') or [None,None]
        original_ids=set(identity(original))
        for e in events:
            side = 1-e['side'] if e['type']=='ownGoal' else e['side']
            squad = squads[side] if squads else None
            if listed(e,squad):
                continue
            scoring = e['type'] in ('goal','penalty','ownGoal')
            if not scoring and (not squad or e['number'] is None):
                continue
            notes.append(f'{e["name"]} ({e["minute"]}′): chưa khớp danh sách thi đấu.')
            prior = identity([e])[0] in original_ids
            if scoring and (not prior or bool(squad) and listed(e,previous_squads[side])):
                return None,(mid,dict(source=url,pendingReview=True,issues=notes))
        counts = dict(source=url,events=len(events),goals=[goals[0],goals[1]],score=score,
                      starters=[len(t['starters']) if t else 0 for t in squads],
                      substitutes=[len(t['substitutes']) if t else 0 for t in squads],issues=notes)
        if pending_review:
            counts['pendingReview'] = True
        if [goals[0],goals[1]]!=score:
            counts['pendingReview'] = True
            notes.append('Chờ duyệt: số bàn trong diễn biến chưa khớp tỷ số.')
            return None,(mid,counts)
        if not any(value!=m.get(key) for key,value in patch.items()):
            return None,(mid,counts)
        verified=['date','score']+[key for key in ('time','penalties') if key in patch]
        checks=[dict(source=[f'VPF · Lịch và kết quả {league_name}',calendar],fields=verified,outcome='agrees')]
        checks+=cross_check(mid,patch)
        note=' '.join(notes)
        return dict(id=mid,at=now,source=['VPF · Trang trận '+' – '.join(names),url],
                    patch=patch,checks=checks,**({'note':note[:550]} if note else {})),(mid,counts)

    def one_club(job):
        k,url=job
        try:
            doc=source['cached_page'](url,cache,'club-'+k+'.html')
            fields=profile(doc,k,data['clubs'][k],TEXT,FOLD,club_aliases)
            return k,dict(at=now,source=['VPF · Hồ sơ '+data['clubs'][k]['name'],url],**fields),[]
        except (ValueError, OSError, subprocess.CalledProcessError) as error:
            return k,None,[str(error)]

    rosters = dict(feed.get('rosters',{}))
    with ThreadPoolExecutor(max_workers=5) as pool:
        for entry,(key,report) in pool.map(one_match,jobs):
            reports[key]=report
            if entry: entries.append(entry)
        for key,roster,issues in pool.map(one_club,club_jobs.items()):
            reports['club-'+key]=dict(players=len(roster['players']) if roster else 0,issues=issues)
            if roster:
                previous=rosters.get(key,{})
                for field in ('year','yearSource'):
                    if field not in roster and field in previous:
                        roster[field]=previous[field]
                if {f:v for f,v in roster.items() if f!='at'}!={f:v for f,v in previous.items() if f!='at'}:
                    rosters[key]=roster
    if not entries and rosters==feed.get('rosters',{}):
        return None,reports
    standings=dict(feed.get('standings',{}))
    updated_ids={item['id'] for item in entries if 'score' in item['patch'] and
                 data['matches'][item['id']].get('score')!=item['patch']['score']}
    for league in {data['matches'][mid]['league'] for mid in updated_ids}-{'nc'}:
        standings[league]=official_standings(cache,data,league,now,standings.get(league,{}))
    return {**feed,'revision':feed['revision']+1,'publishedAt':now,
            'matches':feed['matches']+entries,'rosters':rosters,'standings':standings}, reports


def add_highlights(cache, now, candidate=None, recent_days=None):
    data=snapshot(candidate)
    video_cache=cache/'highlights'
    video_cache.mkdir(exist_ok=True)
    winners,report=discover(source['cached_page'],video_cache,data,now,recent_days)
    # Video provenance is separate from the match result, even on the same sync run.
    stamp=(datetime.fromisoformat(now)+timedelta(milliseconds=1)).isoformat(timespec='milliseconds')
    new=[dict(id=id,at=stamp,source=['VPF · Video tổng hợp',link],patch={'highlightUrl':link})
         for id,link in sorted(winners.items()) if data['matches'][id].get('highlightUrl')!=link]
    report['changed']=len(new)
    if not new:
        return candidate,report
    if not candidate:
        feed=json.loads((APP/'updates.json').read_text(encoding='utf-8'))
        candidate={**feed,'revision':feed['revision']+1}
    return {**candidate,'publishedAt':stamp,'matches':candidate['matches']+new},report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--league', choices=CALENDARS, action='append')
    parser.add_argument('--include-new-results',action='store_true',help='Đưa kết quả vừa công bố vào bản nháp để đối chiếu BXH và luân lưu')
    parser.add_argument('--recent-days',type=int,help='Chỉ tải lại trang trận đã qua trong số ngày này; vẫn phát hiện tỷ số hoặc ngày thay đổi')
    args=parser.parse_args()
    if args.out.exists() or args.report.exists():
        parser.error('Chọn đường dẫn mới cho bản nháp và báo cáo.')
    args.cache.mkdir(parents=True,exist_ok=True)
    draft,reports=prepare(args.cache,datetime.now(source['VN']).isoformat(timespec='milliseconds'),args.league or tuple(CALENDARS),args.include_new_results,args.recent_days)
    args.report.write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if draft:
        payload=json.dumps(draft,ensure_ascii=False,indent=2)+'\n'
        subprocess.run(['node',str(APP/'tools/publish.cjs'),'--check','-'],input=payload.encode(),check=True)
        with args.out.open('x',encoding='utf-8') as output:
            output.write(payload)
    print(f'Đã kiểm tra {len(reports)} hồ sơ trận và CLB. {"Có bản nháp mới." if draft else "Chưa có thay đổi."}')


if __name__=='__main__':
    main()
