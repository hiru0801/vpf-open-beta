'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {compile,goalCounts,scorerTables,timelineCards,matchCards,clubStatTables} = require('../data-update.js');
const root = path.resolve(__dirname,'..');
const read = file => fs.readFileSync(path.join(root,file),'utf8');
const feed = JSON.parse(read('updates.json'));
const baseContext = {window:{}};
vm.runInNewContext(read('data.js'),baseContext);
const data = baseContext.window.VPF_DATA;
const release = compile(data,feed);
const matches = {...data.matches,...release.matches};
const finished = Object.values(matches).filter(m=>m.score);
const firstEight = finished.filter(m=>m.league==='vl1' && m.round<=8);
const media = Object.values(matches).filter(m=>m.highlightUrl);

assert.equal(finished.length,122);
assert.equal(firstEight.length,55);
assert.equal(firstEight.filter(m=>m.matchSquads.every(s=>s.starters.length===11)).length,52);
assert.equal(firstEight.reduce((sum,m)=>sum+goalCounts(m.events).reduce((a,b)=>a+b),0),146);
for (const m of firstEight) {
  assert.deepEqual(goalCounts(m.events),Array.from(m.score),m.id);
  assert.match(release.sources[m.eventsSource][1],/^https:\/\/vpf\.vn\/match\//);
}
const imported=finished.filter(m=>m.league!=='vl1');
assert.equal(imported.filter(m=>m.league==='vl2').length,56);
assert.equal(imported.filter(m=>m.league==='nc').length,11);
for (const m of imported) {
  assert.deepEqual(goalCounts(m.events),Array.from(m.score),m.id);
  assert.deepEqual(m.matchSquads.map(side=>side.starters.length),[11,11],m.id);
}
assert.equal(Object.keys(release.rosters).length,28);
assert.equal(release.rosters.BEC.players.length,27);
assert.equal(release.rosters.VHI.stadium,'SVĐ Thống Nhất');
assert.equal(release.rosters.VHI.coach,'Nguyễn Đình Hưng');
assert.equal(release.rosters.BNI.year,2024);
assert.equal(release.rosters.BNI.coach,'Paulo Foiani');
assert.ok(Object.values(release.rosters).every(r=>r.coach && r.stadium && !r.staff));
const stats=scorerTables(data.ties,matches,release.rosters);
assert.deepEqual(Object.values(stats).map(t=>[t.finished,t.covered,t.rows.length,t.rows.reduce((n,r)=>n+r.goals,0)]),
  [[55,55,73,141],[56,56,83,152],[11,11,28,33]]);
assert.deepEqual(Object.values(stats).map(t=>t.rows[0].goals),[8,11,3]);

const synthetic=(id,home,away,events,penalties)=>({id,home,away,league:'nc',status:'final',date:'2026-11-26',
  score:goalCounts(events),events,penalties});
const goal=(name,side,type,playerId)=>({name,side,type,playerId});
const transfer={
  x:synthetic('x','BNI','KKH',[goal('A',0,'penalty','a'),goal('Own',0,'ownGoal','other')],[3,1]),
  y:synthetic('y','DNC','HPH',[goal('A',0,'goal','a'),goal('A',1,'goal','different'),goal('Miss',0,'missedPenalty','miss')]),
};
assert.deepEqual(scorerTables({},transfer,{}).nc.rows.map(r=>[r.clubs,r.goals,r.rank]),[[['BNI','DNC'],2,1],[['HPH'],1,2]]);
const amended={...transfer,y:synthetic('y','DNC','HPH',[goal('A',1,'goal','different')])};
assert.deepEqual(scorerTables({},amended,{}).nc.rows.map(r=>[r.goals,r.rank]),[[1,1],[1,1]]);
assert.equal(matches['vl2-6-XPT-BEC'].events.find(e=>e.minute==='67').name,'Nguyễn Trần Việt Cường');
assert.equal(matches['vl2-2-HYE-XPT'].matchSquads[1].substitutes.find(p=>p.number===18).exitMinute,'86');
assert.equal(matches['nc-11'].events.filter(e=>e.type==='goal').length,5);
assert.deepEqual(stats.vl2.disputes,['vl2-6-XPT-BEC']);
assert.equal(media.length,99);
assert.match(matches['vl1-1-DNC-TCV'].highlightUrl,/thanh-pho-dong-nai-vs-the-cong-viettel/);
const cupCards=finished.filter(match=>match.league==='nc').map(matchCards);
assert.equal(cupCards.length,11);
assert.ok(cupCards.every(line=>line.derived && line.yellow.length===2 && line.red.length===2));
assert.deepEqual(matchCards(matches['nc-7']),{yellow:[2,4],red:[0,0],derived:true});
assert.deepEqual(timelineCards([{side:0,type:'yellow'},{side:0,type:'secondYellow'},{side:1,type:'red'}]),
  {yellow:[1,0],red:[1,1]});
const clubStats=clubStatTables(data.leagues,data.ties,matches);
assert.deepEqual(Object.values(clubStats).map(({played,yellowMatches,redMatches,rows})=>
  [played,yellowMatches,redMatches,Object.keys(rows).length]),[[55,55,55,14],[56,56,56,14],[11,11,11,27]]);
assert.deepEqual(Object.values(clubStats.nc.rows).reduce(([gf,ga,y,r],row)=>
  [gf+row.goalsFor,ga+row.goalsAgainst,y+row.yellow,r+row.red],[0,0,0,0]),[33,33,49,2]);
assert.equal(finished.filter(m=>m.league==='nc'&&m.highlightUrl).length,7);
assert.equal(Object.values(matches).filter(m=>m.watchUrl).length,3);
assert.deepEqual(JSON.parse(read('release-info.json')),{
  season:feed.season,revision:feed.revision,publishedAt:feed.publishedAt
});
const packaged = {window:{}};
vm.runInNewContext(read('data-published.js'),packaged);
assert.equal(JSON.stringify(packaged.window.VPF_RELEASE),JSON.stringify(feed));
assert.equal(fs.readdirSync(path.join(root,'calendars')).filter(name=>name.endsWith('.ics')).length,28);

const at='2027-01-01T00:00:00+07:00';
const edit=(id,patch)=>({...feed,revision:feed.revision+1,publishedAt:at,matches:[
  ...feed.matches,{id,patch,at,source:['Kiểm thử','https://example.com/test']}
]});
assert.throws(()=>compile(data,{...feed,season:'2025/26'}),/thuộc mùa giải khác/);
const wrongPlayer=structuredClone(matches['nc-11'].events);
Object.assign(wrongPlayer.find(e=>e.type==='goal'),{name:'Cầu thủ QA',number:88,playerId:'qa-player'});
assert.throws(()=>compile(data,edit('nc-11',{events:wrongPlayer})),/Người ghi bàn chưa khớp/);
assert.throws(()=>compile(data,edit('nc-11',{events:wrongPlayer,matchSquads:null})),/Người ghi bàn chưa khớp/);
assert.throws(()=>compile(data,edit('vl1-8-THA-HAG',{score:[0,1]})),/vượt tỷ số/);
assert.throws(()=>compile(data,edit('vl1-8-THA-HAG',{score:[3,1]})),/Cần kiểm tra/);
assert.doesNotThrow(()=>compile(data,edit('vl1-8-THA-HAG',{score:[3,1],events:null,goals:null})));
assert.throws(()=>compile(data,edit('vl1-9-HNO-HLH',{status:'provisional'})),/khung ngày/);
const correctTable=JSON.parse(JSON.stringify(data.standings.vl1));
const tableCandidate=rows=>({...feed,standings:{
  vl1:{at:feed.publishedAt,source:data.sources.vl1table,rows}
}});
assert.doesNotThrow(()=>compile(data,tableCandidate(correctTable)));
const reversed=correctTable.slice().reverse().map((row,i)=>[i+1,...row.slice(1)]);
assert.throws(()=>compile(data,tableCandidate(reversed)),/sai thứ tự điểm/);
const tiedRows=structuredClone(correctTable);
[tiedRows[2],tiedRows[3]]=[tiedRows[3],tiedRows[2]];
assert.throws(()=>compile(data,tableCandidate(tiedRows.map((row,i)=>[i+1,...row.slice(1)]))),/sai thứ tự khi bằng điểm/);
assert.throws(()=>compile(data,edit('nc-3',{penalties:[2,2]})),/Luân lưu/);
assert.throws(()=>compile(data,edit('nc-3',{penalties:null})),/Luân lưu/);
assert.throws(()=>compile(data,edit('nc-4',{penalties:[4,5]})),/Luân lưu/);

const testCup={
  season:data.season,clubs:data.clubs,leagues:data.leagues,sources:data.sources,standings:{},
  matches:{
    'nc-24-1':{id:'nc-24-1',league:'nc',home:'KKH',away:'VHI',score:[2,0],status:'final'},
    'nc-24-2':{id:'nc-24-2',league:'nc',home:'VHI',away:'KKH',score:[3,1],status:'final',penalties:[2,4]}
  },ties:{24:{legs:2}}
};
const twoLegs={...feed,matches:[]};
assert.doesNotThrow(()=>compile(testCup,twoLegs));
assert.throws(()=>compile({...testCup,matches:{...testCup.matches,'nc-24-1':{...testCup.matches['nc-24-1'],penalties:[2,1]}}},twoLegs),/Lượt đi/);
const tiedAway=testCup.matches['nc-24-2'];
assert.throws(()=>compile({...testCup,matches:{...testCup.matches,'nc-24-2':{...tiedAway,score:[4,1]}}},twoLegs),/Luân lưu/);
const wrongTable=structuredClone(correctTable);
wrongTable[0][9]+=99;
assert.throws(()=>compile(data,tableCandidate(wrongTable)),/Điểm BXH không khớp/);
wrongTable[0][2]++;
wrongTable[0][4]++;
wrongTable[0][9]=correctTable[0][9]+1;
assert.throws(()=>compile(data,tableCandidate(wrongTable)),/BXH chưa khớp kết quả/);

function simulate({hash='',broken=false,host=false}={}) {
  const elements=new Map();
  function element() {
    return {innerHTML:'',textContent:'',dataset:{},classList:{toggle(){},add(){},remove(){}},
      setAttribute(){},addEventListener(){},focus(){},querySelector(){return element();}};
  }
  const requests=[];
  let offered={...feed};
  const context=vm.createContext({
    URL,URLSearchParams,structuredClone,TextEncoder,AbortController,
    window:{addEventListener(){},scrollTo(){},matchMedia(){return {matches:false};}},
    navigator:{},
    location:{hash,protocol:host?'https:':'file:',pathname:'/index.html',href:'https://example.com/index.html'},
    history:{pushState(){},replaceState(){},state:null},
    document:{activeElement:element(),documentElement:element(),addEventListener(){},getElementById(id){
      if(!elements.has(id)) elements.set(id,element());
      return elements.get(id);
    }},
    localStorage:{getItem(){return null;},setItem(){}},
    setTimeout(){},clearTimeout(){},setInterval(){},
    async fetch(file) {
      requests.push(file);
      return {ok:true,async json(){
        if(file==='release-info.json') {
          const {season,revision,publishedAt}=offered;
          return {season,revision,publishedAt};
        }
        return offered;
      }};
    }
  });
  for (const file of ['data.js','data-update.js','data-published.js','calendar.js','competition-view.js','match-view.js','web-data.js','news-view.js','app.js']) {
    if (broken && file==='app.js') context.window.VPF_RELEASE.season='2025/26';
    vm.runInContext(read(file),context);
  }
  return {elements,requests,setFeed(next){offered=next;},run(source){return vm.runInContext(source,context);}};
}

async function uiChecks() {
  const qa=simulate({hash:'#vl2/fixtures?scope=all&period=week&match=vl1-8-DNA-NBI'});
  assert.equal(qa.elements.get('league-name').textContent,'V.League 1');
  assert.equal(qa.run('state.league'),'vl2');
  assert.match(qa.run("clubDetail('VHI')"),/HLV trưởng[\s\S]*Nguyễn Đình Hưng[\s\S]*Danh sách đăng ký cầu thủ/);
  assert.doesNotMatch(qa.run("clubDetail('BEC')"),/Ban huấn luyện và nhân sự/);
  assert.equal(qa.run("cupBracket('26').columns.map(c=>c.length).join(',')"),'4,2,1,1,1,2,4');
  assert.equal(qa.run("cupBracket('26').branches.flat(2).length"),25);
  const old=qa.run("matchDetail(matches['vl1-7-NBI-BNI'])");
  const newMatch=qa.elements.get('content').innerHTML;
  for (const view of [old,newMatch]) {
    for (const label of ['Diễn biến trận đấu','Đội hình và thay người','Dự bị','Nguồn và đối chiếu'])
      assert.ok(view.includes(label),label);
  }
  assert.match(newMatch,/Nguyễn Hoàng Đức/);
  assert.match(newMatch,/24′/);
  assert.match(newMatch,/Thẻ đỏ/);
  assert.match(old,/Phản lưới nhà/);
  const missing=simulate({hash:'#vl2/fixtures?match=invalid'});
  assert.match(missing.elements.get('content').innerHTML,/Không tìm thấy trận/);
  assert.match(qa.run("matchDetail(matches['nc-3'])"),/Luân lưu.*Xem video tổng hợp/);
  assert.match(qa.run("matchDetail(matches['vl1-9-NDI-CAH'])"),/Mở trang phát sóng/);
  qa.run("favorites.add('HYE'); favorites.add('CAH'); matchFavorites.add('nc-11'); matchFavorites.add('vl2-6-XPT-BEC')");
  const following=qa.run('followingView()');
  assert.match(following,/Đội của tôi[\s\S]*Trận đã lưu/);
  assert.doesNotMatch(following,/Mới cập nhật|data-follow-club="CAH"/);
  assert.match(following,/data-follow-club="HYE"/);
  assert.doesNotMatch(qa.run('savedMatchesView()'),/data-match="nc-11"/);
  assert.ok(qa.run("followedClubMatches('HYE').recent.length<=5"));
  const vl1=simulate({hash:'#vl1/competition'});
  assert.match(vl1.elements.get('content').innerHTML,/Bàn thắng[\s\S]*Bàn thua/);
  assert.match(vl1.run('rankingLegend()'),/AFC Champions League Two và Shopee Cup/);
  assert.equal((vl1.run('rankingTable(data.standings.vl1.slice(0,2).map(row=>[1,...row.slice(1)]),false,"full",true)').match(/zone-regional/g)||[]).length,2);
  const vl2=simulate({hash:'#vl2/competition'});
  assert.match(vl2.run('rankingLegend()'),/Xuống hạng Nhì Quốc gia/);
  assert.doesNotMatch(vl2.run('rankingLegend()'),/Shopee Cup/);
  const fallback=simulate({broken:true,hash:'#vl2/stats'});
  assert.match(fallback.elements.get('snapshot-label').textContent,/Đang dùng dữ liệu gốc/);
  assert.match(fallback.elements.get('content').innerHTML,/Tệp cập nhật chưa sẵn có/);
  const online=simulate({host:true});
  // Wait for the initialization fetch before changing its mocked response.
  await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(online.requests,['release-info.json']);
  online.setFeed({...feed,revision:feed.revision-1});
  await online.run('refreshFeed()');
  assert.deepEqual(online.requests,['release-info.json']);
  await online.run('refreshFeed(true)');
  assert.match(online.elements.get('snapshot-label').textContent,/Đang dùng dữ liệu đã lưu/);
  assert.equal(online.run('appliedFeed.revision'),feed.revision);
  online.setFeed(edit('vl1-9-NDI-CAH',{time:'18:15'}));
  await online.run('refreshFeed(true)');
  assert.equal(online.run("matches['vl1-9-NDI-CAH'].time"),'18:15');
  const valid=edit('vl1-9-NDI-CAH',{time:'18:30'});
  online.setFeed({...valid,revision:feed.revision+2,matches:[...valid.matches.slice(0,-1),{
    ...valid.matches.at(-1),patch:{time:'invalid'}
  }]});
  await online.run('refreshFeed(true)');
  assert.equal(online.run("matches['vl1-9-NDI-CAH'].time"),'18:15');
  console.log('PASS: 122 trận · 28 hồ sơ · Vua phá lưới 3 giải · nhánh Cúp và lịch CLB.');
}

uiChecks().catch(error=>{console.error(error);process.exitCode=1;});
