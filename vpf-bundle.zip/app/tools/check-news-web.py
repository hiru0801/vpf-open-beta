import argparse
from datetime import datetime, timedelta
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from threading import Thread
from playwright.sync_api import sync_playwright, expect
parser=argparse.ArgumentParser(description='Exercise the packaged News view in Chromium.')
parser.add_argument('web',type=Path)
parser.add_argument('--chromium')
args=parser.parse_args()
web=args.web.resolve()
source=Path(__file__).resolve().parents[1]
seed=json.loads((web/'news-feed.json').read_text())
target=next(a for a in seed['articles'] if a['url'].endswith('-5301702611.html'))
class Server(SimpleHTTPRequestHandler):
    def log_message(self,*_): pass
handler=partial(Server,directory=web)
server=ThreadingHTTPServer(('127.0.0.1',0),handler)
Thread(target=server.serve_forever,daemon=True).start()
origin=f'http://127.0.0.1:{server.server_port}/'
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=args.chromium)
    for width in (320,390,540,1280):
        c=b.new_context(viewport={'width':width,'height':820},color_scheme='dark')
        page=c.new_page()
        loads=[]
        errors=[]
        page.on('request',lambda r:loads.append(r.url))
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(origin)
        assert not any('news-feed.json' in u for u in loads)
        expect(page.get_by_role('heading',name='V.League 1',exact=True)).to_be_visible()
        page.get_by_role('button',name='Tin tức').click()
        expect(page.locator('.news-grid .news-entry')).to_have_count(6)
        expect(page.locator('.news-entry')).to_have_count(12)
        assert page.locator('#news-club option').count()==29
        assert page.locator('#news-league option').count()==4
        assert page.locator('#news-rail button').count()==7
        expect(page.get_by_role('button',name='Lao Động',exact=True)).to_have_count(0)
        assert page.evaluate('document.documentElement.scrollWidth === innerWidth')
        first=page.locator('.news-grid a').first
        before=first.get_attribute('href')
        times=page.locator('.news-entry time').evaluate_all('(nodes)=>nodes.map(n=>Date.parse(n.dateTime))')
        assert times==sorted(times,reverse=True)
        page.get_by_role('button',name='Xem thêm tin').click()
        expect(page.locator('.news-entry')).to_have_count(24)
        page.get_by_label('Giải đấu',exact=True).select_option('nc')
        expect(page.locator('.news-entry')).to_have_count(min(12,sum('nc' in a['leagues'] for a in seed['articles'])))
        page.get_by_label('Giải đấu',exact=True).select_option('')
        page.get_by_label('Câu lạc bộ',exact=True).select_option('NDI')
        expect(page.locator('.news-entry').first).to_contain_text('Nam Định')
        page.get_by_label('Câu lạc bộ',exact=True).select_option('')
        page.get_by_role('button',name='Bóng Đá Plus',exact=True).click()
        page.get_by_label('Giải đấu',exact=True).select_option('vl2')
        story=page.locator('.news-entry').filter(has_text=target['title'])
        expect(story.locator('a')).to_have_attribute('href',target['url'])
        expect(story.locator('time')).to_have_text('11:39 27/11/2026')
        page.get_by_label('Giải đấu',exact=True).select_option('')
        page.get_by_role('button',name='VFF',exact=True).click()
        expect(page.locator('.news-entry .news-meta').first).to_contain_text('VFF')
        page.get_by_role('button',name='Tất cả nguồn').click()
        expect(first).to_have_attribute('href',before)
        rail=page.locator('#news-rail')
        if rail.evaluate('el=>el.scrollWidth>el.clientWidth'):
            page.get_by_role('button',name='Cuộn đến các nguồn tiếp theo').click()
            page.wait_for_function('() => document.querySelector("#news-rail").scrollLeft>0')
        assert not errors,errors
        print('PASS News Web',width,'px',flush=True)
        if width==390:
            page.evaluate('navigator.serviceWorker.ready')
            page.wait_for_function('() => Boolean(navigator.serviceWorker.controller)')
            c.set_offline(True)
            page.reload()
            expect(page.locator('.news-grid .news-entry')).to_have_count(6)
            expect(page.get_by_text('Đang dùng tin đã lưu',exact=False)).to_be_visible()
            c.set_offline(False)
        c.close()
    s=b.new_page(viewport={'width':390,'height':820})
    s.goto((source/'index.html').as_uri()+'#vl1/news')
    expect(s.locator('.news-grid .news-entry')).to_have_count(6)
    print('PASS Source file + Web offline',flush=True)
    c=b.new_context(service_workers='block')
    page=c.new_page()
    page.clock.install()
    page.goto(origin+'#vl1/news')
    expect(page.locator('.news-entry')).to_have_count(12)
    latest=datetime.fromisoformat(seed['checkedAt'])
    new=dict(seed['articles'][0],title='Tin QA: Nam Định chuẩn bị cho vòng mới',url='https://znews.vn/tin-v-league-post99999.html',
             source='znews',publishedAt=(latest+timedelta(minutes=1)).isoformat())
    seed['checkedAt']=(latest+timedelta(minutes=2)).isoformat()
    seed['articles']=[new,*seed['articles'][:119]]
    page.route('**/news-feed.json',lambda r:r.fulfill(json=seed))
    page.clock.fast_forward(316000)
    expect(page.locator('.news-grid h3').first).to_have_text(new['title'])
    print('PASS tự nhận JSON mới ở lần kiểm tra tiếp, giữ nguyên trang',flush=True)
    c.close()
    b.close()
server.shutdown()
