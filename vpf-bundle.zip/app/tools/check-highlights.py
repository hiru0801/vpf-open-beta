"""Regression cases for matching public VPF video posts to finished games."""
from datetime import date
from pathlib import Path
import runpy

from vpf_highlights import match_highlights, official_video

tool=runpy.run_path(str(Path(__file__).with_name('backfill-vpf.py')))
snapshot=tool['snapshot']()
video='https://vpf.vn/video-highlight/video-vleague/highlights-dong-nai-viettel/'
champ='[HIGHLIGHTS] Thành phố Đồng Nai vs Thể Công – Viettel | LPBank V.League 1 – 2026/27'
results,review=match_highlights(snapshot,[
    (date(2026,9,5),video,champ),
    (date(2026,9,5),video+'duplicate',champ),
    (date(2026,9,5),video+'past-season',champ.replace('2026/27','2025/26')),
])
assert list(results)==['vl1-1-DNC-TCV'] and results['vl1-1-DNC-TCV']==video and not review
assert official_video(video+'?campaign=1')==video
assert official_video('https://example.com/video-highlight/') is None

game=snapshot['matches']['vl1-9-SLN-NBI']
title='[HIGHLIGHTS] Sông Lam Nghệ An vs Ninh Bình | LPBank V.League 1 – 2026/27'
article=(date.fromisoformat(game['date']),video,title)
assert match_highlights(snapshot,[article])[0]=={}
game.update(score=[0,0],status='final')
assert match_highlights(snapshot,[article])[0]=={game['id']:video}
old=date.fromisoformat(game['date'].replace('11-','10-'))
assert match_highlights(snapshot,[(old,video,title)])[0]=={}
article=(article[0],video,title.replace('V.League 1','V.League 2'))
assert match_highlights(snapshot,[article])[0]=={}
print('PASS · ngày đăng, chưa đá/đã kết thúc, trùng bài, sai giải, sai mùa và đúng nguồn VPF.')
