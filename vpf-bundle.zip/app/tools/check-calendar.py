"""Check that updates preserve stable calendar identities and record schedule changes."""

from pathlib import Path
from tempfile import TemporaryDirectory
from shutil import copytree
import json
import re
import subprocess
import sys

root=Path(sys.argv[1]).resolve()
get=lambda obj:json.dumps(obj,ensure_ascii=False)
with TemporaryDirectory() as temp:
    work=Path(temp)/'app'
    copytree(root,work)
    seq=lambda file: {block.split('UID:',1)[1].splitlines()[0]:block for block in file.read_text().split('BEGIN:VEVENT')[1:]}
    target=work/'calendars'/'NDI.ics'
    originals=seq(target)
    id='vl1-9-NDI-CAH'
    uid=next(k for k in originals if k.startswith(id+'-'))
    def change(patch,at):
        feed=json.loads((work/'updates.json').read_text())
        feed['revision']+=1
        feed['publishedAt']=at
        feed['matches'].append(dict(id=id,at=at,source=['QA · Giả lập','https://example.com/vpf'],patch=patch))
        draft=work.parent/'draft.json'
        draft.write_text(get(feed))
        subprocess.run(['node','tools/publish.cjs',str(draft)],cwd=work,check=True)
        return seq(target)[uid]
    sequence=lambda event:int(re.search(r'SEQUENCE:(\d+)',event)[1])
    metadata=change({'watchUrl':'https://example.com/watch'},'2026-11-28T09:00:00+07:00')
    assert metadata==originals[uid]
    moved=change({'date':'2027-01-12','time':'19:00'},'2026-11-29T09:00:00+07:00')
    assert sequence(moved)==sequence(metadata)+1
    assert 'DTSTART:20270112T120000Z' in moved
    cancelled=change({'status':'postponed','date':None,'time':None},'2026-11-30T09:00:00+07:00')
    assert sequence(cancelled)==sequence(moved)+1 and 'STATUS:CANCELLED' in cancelled
    assert 'DTSTART:20270112T120000Z' in cancelled
    confirmed=change({'status':'scheduled','date':'2027-01-14','time':'18:00'},'2026-12-01T09:00:00+07:00')
    assert sequence(confirmed)==sequence(cancelled)+1 and 'STATUS:CONFIRMED' in confirmed
print('PASS · metadata giữ nguyên ICS · đổi lịch, hoãn và xếp lại giữ UID và tăng SEQUENCE.')
