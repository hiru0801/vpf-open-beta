"""Import V.League 1 match details from VPF into a review draft."""

import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import re
import subprocess
import tempfile
import unicodedata
from typing import NamedTuple
from urllib.parse import parse_qs, urlsplit

from lxml import html
from vpf_clubs import player_id

APP = Path(__file__).resolve().parents[1]
CALENDAR = 'https://vpf.vn/season/v-league-2027/?action=calendar'
SEASON = '2026/27'
VPF_SEASON_ID = '154439'
ICONS = {'goal.png':'goal','own_goal.png':'ownGoal','yellow_card.png':'yellow','red_card.png':'red'}
VN = timezone(timedelta(hours=7))


def cls(name):
    return f'contains(concat(" ",normalize-space(@class)," ")," {name} ")'

def text(element):
    return unicodedata.normalize('NFC',' '.join(element.text_content().split()))

def one(element, xpath):
    results=element.xpath(xpath)
    if len(results)!=1:
        raise ValueError(f'{xpath}: found {len(results)}')
    return results[0]

def minute(value):
    match=re.fullmatch(r"(\d{1,3})\s*['′]?\s*(?:\+\s*(\d{1,2})\s*['′]?)?",value)
    if not match:
        raise ValueError(f'Unexpected minute {value}')
    return str(int(match[1]))+('+'+str(int(match[2])) if match[2] else '')

def minute_key(value):
    main,_,extra=value.partition('+')
    return int(main),int(extra or '0')

def parse_events(view):
    tables=view.xpath(f'.//table[{cls("jsTblVerticalTimeLine")}]')
    if not tables:
        return None
    if len(tables)!=1:
        raise ValueError('Found multiple timeline tables')
    rows=[]
    for row in tables[0].xpath('.//tr[td]'):
        cells=row.xpath('./td')
        if len(cells)!=5:
            raise ValueError(f'Unexpected timeline row {len(cells)}')
        stamp=text(cells[2])
        stamp_match=re.fullmatch(r"(\d{1,3}\s*['′](?:\s*\+\s*\d{1,2})?)\s*(.*)",stamp)
        if not stamp_match:
            raise ValueError(f'Unexpected event minute {stamp}')
        time=minute(stamp_match[1])
        qualifier=stamp_match[2].strip('() ').upper()
        for side,i,j in [(0,0,1),(1,4,3)]:
            person=text(cells[i])
            images=cells[j].xpath('.//img')
            if not images and not person:
                continue
            if len(images)!=1 or not person:
                raise ValueError(f'Bad timeline event {side}: {person}')
            kind=ICONS[Path(urlsplit(images[0].get('src','')).path).name]
            if kind=='goal' and qualifier in ('P','PEN'):
                kind='penalty'
            elif kind=='red' and re.match(r'^\(?2?TV\b',qualifier):
                kind='secondYellow'
            elif qualifier not in ('','STĐ'):
                raise ValueError(f'Unexpected event qualifier: {qualifier}')
            found=re.match(r'^\[(\d+)\]\s*(.+)$',person)
            identity=player_id(cells[i].xpath('.//a/@href')) if kind in ('goal','penalty') else None
            rows.append(dict(side=side,type=kind,minute=time,number=int(found[1]) if found else None,
                             name=found[2] if found else person,**({'playerId':identity} if identity else {})))
    return sorted(rows,key=lambda item:minute_key(item['minute']))

def parse_players(table, direction, issues):
    rows=[]
    for row in table.xpath(f'./*[{cls("jstable-row")}]'):
        if len(row)!=5:
            raise ValueError('Unexpected lineup row')
        number=text(row[0])
        name=text(row[2])
        if not name:
            raise ValueError('Lineup player missing name')
        position=text(row[3]) or None
        if position not in [None,'Thủ môn','Hậu vệ','Tiền vệ','Tiền đạo']:
            raise ValueError(f'Unexpected position {position}')
        changes = {}
        for icon in row[4].xpath('.//img'):
            kind = Path(urlsplit(icon.get('src','')).path).name
            if kind not in ('in-new.png','out-new.png') or kind in changes:
                raise ValueError('Unexpected substitution direction')
            stamp=' '.join((icon.tail or '').split())
            normalized=minute(stamp)
            if minute_key(normalized)[0]>120:
                issues.append(f'{name}: trang VPF ghi phút {stamp}, cần đối chiếu.')
                normalized=None
            changes[kind]=normalized
        if text(row[4]) and direction+'-new.png' not in changes:
            raise ValueError('Wrong substitution direction')
        player=dict(number=int(number) if number else None,name=name,position=position,
                    changeMinute=changes.get(direction+'-new.png'))
        if direction=='in' and changes.get('out-new.png'):
            player['exitMinute']=changes['out-new.png']
        rows.append(player)
    return rows

def parse_squads(view, header_names, issues):
    teams=view.xpath(f'.//*[@id="stab_squad"]//*[{cls("jo-team-squad")}]')
    if len(teams)!=2:
        raise ValueError(f'Expected two lineups, found {len(teams)}')
    squads=[]
    for side,team in enumerate(teams):
        heading=one(team,f'./*[{cls("jo-squad-header")}]//h3')
        if text(heading)=='Đang cập nhật' and not team.xpath(f'.//*[{cls("jstable-row")}]'):
            issues.append(f'{header_names[side]}: trang trận chưa công bố đội hình.')
            squads.append(None)
            continue
        if text(heading)!=header_names[side]:
            raise ValueError(f'Lineup team is not on the expected side {side}')
        tables=team.xpath(f'./*[{cls("jstable")}]')
        if len(tables)!=2:
            raise ValueError(f'Expected starters and substitutes, found {len(tables)} tables')
        starters,subs=parse_players(tables[0],'out',issues),parse_players(tables[1],'in',issues)
        if not 1<=len(starters)<=11:
            raise ValueError(f'Invalid starters: {len(starters)} for side {side}')
        squads.append(dict(starters=starters,substitutes=subs))
    return squads if any(squads) else None

def club_key(value):
    normalized = unicodedata.normalize('NFD', value.lower().replace('đ', 'd'))
    return re.sub(r'[^a-z0-9]+', '', normalized)


def cached_page(url, cache, name):
    location = urlsplit(url)
    if location.scheme != 'https' or location.netloc != 'vpf.vn':
        raise ValueError('URL nguồn phải thuộc https://vpf.vn.')
    filename = cache / name
    if filename.is_file():
        return html.fromstring(filename.read_text(encoding='utf-8'))
    result = subprocess.run(
        ['curl','-fsS','--max-time','20','--proto','=https',url],
        check=True, capture_output=True, text=True, encoding='utf-8',
    )
    page = html.fromstring(result.stdout)
    filename.write_text(result.stdout, encoding='utf-8')
    return page


class CalendarRow(NamedTuple):
    date: str
    teams: list[str]
    score: list[int] | None
    url: str | None
    kickoff: str | None
    penalties: list[int] | None
    venue: str
    number: str
    postponed: bool


def calendar_rows(doc):
    def cell(row, name):
        nodes = row.xpath(f'./*[{cls(name)}]')
        return text(nodes[0]) if nodes else ''

    for day in doc.xpath(f'//*[{cls("js-matchday-wrapper")}]'):
        found = re.search(r'(\d{2})\s+Tháng\s+(\d+),\s*(\d{4})', text(day[0]), re.I)
        if not found:
            continue
        number, month, year = found.groups()
        date = f'{year}-{int(month):02d}-{number}'
        for row in day.xpath(f'.//*[{cls("js-matchday-matches")}]/*[{cls("jstable-row")}]'):
            teams = [cell(row, 'jsMatchDiv'+side) for side in ('Home', 'Away')]
            if not all(teams):
                continue
            links = row.xpath(f'./*[{cls("jsMatchDivScore")}]//a[contains(@href,"/match/")]')
            url = links[0].get('href') if len(links) == 1 else None
            kickoff = cell(row, 'jsMatchDivTime')
            score_cell = cell(row, 'jsMatchDivScore')
            # A blank or missing clock does not establish that a match was postponed.
            postponed = any(re.fullmatch(r'(?:trận đấu )?(?:tạm )?hoãn(?: thi đấu)?|postponed',
                                         value.strip(' .()'), re.I) for value in (kickoff, score_cell))
            score = re.fullmatch(r'(\d+)\s*-\s*(\d+)', text(links[0])) if url and not postponed else None
            stamp = kickoff if re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', kickoff) else None
            penalties = re.search(r'Pen:\s*(\d+)\s*-\s*(\d+)', score_cell, re.I)
            venue = re.sub(r'^SVĐ\s+|^Sân vận động\s+', '', cell(row, 'jsMatchDivVenue'), flags=re.I)
            yield CalendarRow(date, teams, list(map(int, score.groups())) if score else None,
                              url, stamp, list(map(int, penalties.groups())) if penalties else None,
                              venue, cell(row, 'js-ma-tran'), postponed)


def calendar_results(doc):
    for row in calendar_rows(doc):
        if row.score is not None:
            yield row.date, row.teams, row.score, row.url


def parse_match(doc, match, names, score, vpf_season_id=VPF_SEASON_ID, *, verify_penalties=False):
    view = one(doc, '//*[@id="jsMatchViewID"]')
    teams = view.xpath(f'.//*[{cls("jsMatchPartName")}]//a')
    if [text(link) for link in teams] != names or any(
        parse_qs(urlsplit(link.get('href','')).query).get('sid') != [vpf_season_id] for link in teams
    ):
        raise ValueError('Sai đội hoặc mùa giải trên trang trận.')
    match_time = re.search(r'(\d{2}) tháng (\d+), (\d{4})\s*-\s*(\d{2}:\d{2})',
                           text(one(view, f'.//*[{cls("matchdtime")}]')), re.I)
    if not match_time or f'{match_time[3]}-{int(match_time[2]):02d}-{match_time[1]}' != match['date'] or match_time[4] != match['time']:
        raise ValueError('Ngày hoặc giờ trên trang trận khác lịch đang lưu.')
    actual = [int(text(one(view, f'.//*[{cls(f"BigMScore{side}")}]'))) for side in (1, 2)]
    if actual != score or match.get('score') not in (None, score):
        raise ValueError('Tỷ số nguồn khác dữ liệu đã lưu. Cần duyệt riêng.')
    patch = {'score': actual, 'date': match['date']}
    if match['status'] != 'final':
        patch['status'] = 'final'
    if verify_penalties:
        penalty_score=re.search(r'Pen:\s*(\d+)\s*-\s*(\d+)',
                                text(one(view,f'.//*[{cls("mainScoreDiv")}]')),re.I)
        kicks=list(map(int,penalty_score.groups())) if penalty_score else None
        if kicks!=match.get('penalties'):
            raise ValueError('Hai trang VPF chưa khớp tỷ số luân lưu.')
        patch['penalties']=kicks
    notes = []
    try:
        events = parse_events(view)
        if events is not None:
            goals = Counter(e['side'] for e in events if e['type'] in ('goal','penalty','ownGoal'))
            if any(goals[side] > actual[side] for side in (0,1)):
                raise ValueError('Số bàn trong diễn biến vượt tỷ số.')
            if any(goals[side] < actual[side] for side in (0,1)):
                notes.append('Số bàn có tên chưa đủ so với tỷ số.')
            patch['events'] = events
    except (ValueError, KeyError) as error:
        notes.append('Cần kiểm tra diễn biến. '+str(error))
    try:
        squads = parse_squads(view, names, notes)
        for side, team in enumerate(squads or []):
            if team is None:
                continue
            if len(team['starters']) < 11:
                notes.append(f'{names[side]} có {len(team["starters"])}/11 cầu thủ xuất phát trên nguồn.')
            incoming = Counter(p['changeMinute'] for p in team['substitutes'] if p['changeMinute'])
            outgoing = Counter(p['changeMinute'] for p in team['starters'] if p['changeMinute'])
            outgoing.update(p['exitMinute'] for p in team['substitutes'] if p.get('exitMinute'))
            if incoming != outgoing:
                notes.append(f'Mốc thay người của {names[side]} chưa khớp.')
        if squads:
            patch['matchSquads'] = squads
    except ValueError:
        notes.append('Cần kiểm tra cấu trúc đội hình trên VPF.')
    return patch, notes


def read_build():
    script = '''
const fs=require('node:fs'),vm=require('node:vm');
const {compile}=require('./data-update.js');
const context={window:{}};
vm.runInNewContext(fs.readFileSync('data.js','utf8'),context);
const base=context.window.VPF_DATA;
const feed=JSON.parse(fs.readFileSync('updates.json','utf8'));
const published=compile(base,feed);
console.log(JSON.stringify({season:base.season,clubs:base.clubs,
matches:Object.values({...base.matches,...published.matches}).filter(m=>m.league==='vl1')}));
'''
    done = subprocess.run(['node','-e',script], cwd=APP, check=True, capture_output=True, encoding='utf-8')
    return json.loads(done.stdout)


def prepare(round_number, cache):
    base = read_build()
    if base['season'] != SEASON:
        raise ValueError('Cần cấu hình nguồn VPF cho mùa mới trước khi nhập.')
    calendar = list(calendar_results(cached_page(CALENDAR, cache, 'calendar.html')))
    feed = json.loads((APP / 'updates.json').read_text(encoding='utf-8'))
    now = datetime.now(VN).isoformat(timespec='milliseconds')
    added = []
    for match in (m for m in base['matches'] if m['round'] == round_number and m.get('date')):
        aliases = []
        for side in ('home','away'):
            club = base['clubs'][match[side]]
            aliases.append({club_key(n) for n in [club['name'],*club.get('aliases',[])]})
        found = [row for row in calendar if row[0] == match['date'] and
                 all(club_key(team) in a for team,a in zip(row[1],aliases))]
        if len(found) != 1:
            print(f'{match["id"]}: chưa có đúng một trận đã có tỷ số trong lịch VPF.')
            continue
        _, names, score, url = found[0]
        try:
            page = cached_page(url,cache,match['id']+'.html')
            patch, notes = parse_match(page, match, names, score)
        except (ValueError, OSError, subprocess.CalledProcessError) as error:
            print(f'{match["id"]}: {error}')
            continue
        published_entry = next((item for item in reversed(feed['matches']) if item['id']==match['id'] and
                                'events' in item['patch']),None)
        for field in ('events','matchSquads'):
            if field not in patch or patch[field] == match.get(field):
                patch.pop(field,None)
            elif published_entry and published_entry.get('checks') and any(
                field in check['fields'] for check in published_entry['checks']
                if check['source'][1] != CALENDAR
            ):
                # Keep fields explicitly resolved with a second source for manual review.
                patch.pop(field,None)
                print(f'{match["id"]}: {field} đã đối chiếu nguồn khác. Cần xem lại thủ công.')
        if not {'events','matchSquads','status'}.intersection(patch):
            continue
        entry = dict(id=match['id'], at=now, source=['VPF · Trang trận '+ ' – '.join(names),url],patch=patch,
                     checks=[dict(source=['VPF · Lịch thi đấu và kết quả V.League 1 2026/27',CALENDAR],
                                  fields=['date','score'],outcome='agrees')])
        if notes:
            entry['note'] = ' '.join(notes)[:550]
        added.append(entry)
    if not added:
        return None, 0
    draft = {**feed, 'schema':2, 'season':SEASON, 'revision':feed['revision']+1, 'publishedAt':now,
             'matches':feed['matches']+added}
    return draft,len(added)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round',type=int,choices=range(1,27),required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--cache',type=Path,help='Thư mục ảnh chụp HTML để đối chiếu lại cùng một nguồn')
    args = parser.parse_args()
    if args.out.exists():
        parser.error('Chọn đường dẫn mới cho bản nháp.')
    with tempfile.TemporaryDirectory(prefix='vpf-source-') as tmp:
        cache = args.cache or Path(tmp)
        cache.mkdir(parents=True,exist_ok=True)
        draft,count = prepare(args.round,cache)
    if not draft:
        print('Không có thay đổi đủ điều kiện để tạo bản nháp.')
        return
    with tempfile.TemporaryDirectory(prefix='vpf-draft-') as tmp:
        provisional = Path(tmp) / 'draft.json'
        provisional.write_text(json.dumps(draft,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        subprocess.run(['node',str(APP/'tools/publish.cjs'),'--verify-next',str(provisional)],check=True)
        with args.out.open('xb') as output:
            output.write(provisional.read_bytes())
    print(f'Đã tạo bản nháp {count} trận tại {args.out}. Kiểm tra nguồn trước khi duyệt.')


if __name__ == '__main__':
    main()
