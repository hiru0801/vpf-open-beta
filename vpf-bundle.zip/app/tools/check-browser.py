"""Smoke and regression tests for a built VPF App web directory."""
from datetime import datetime, timezone
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
import argparse
import re

from playwright.sync_api import sync_playwright, expect


class QuietServer(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def run(directory, executable):
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietServer,directory=str(directory)))
    Thread(target=server.serve_forever,daemon=True).start()
    origin=f'http://127.0.0.1:{server.server_port}/'
    champ='#vl2/fixtures?period=results&match=vl2-6-XPT-BEC'
    cup='#nc/fixtures?period=results&match=nc-11'
    with sync_playwright() as driver:
        browser=driver.chromium.launch(executable_path=executable)
        for width in (320,390,540,1280):
            context=browser.new_context(viewport={'width':width,'height':844},service_workers='block',locale='vi-VN')
            page=context.new_page()
            errors=[]
            seen=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            page.on('response',lambda response:seen.append((response.url,response.status)))
            page.goto(origin)
            expect(page.get_by_role('heading',name='V.League 1',exact=True)).to_be_visible()
            assert not any('/matches/' in url or '/clubs/' in url for url,_ in seen)
            assert not any(url.endswith(('/updates.json','/data-published.js')) for url,_ in seen)
            page.goto(origin+champ)
            expect(page.get_by_role('heading',name='Diễn biến trận đấu')).to_be_visible()
            expect(page.get_by_text('Nguyễn Trần Việt Cường',exact=True).first).to_be_visible()
            assert page.locator('.score-status .status-tag').evaluate('(el)=>getComputedStyle(el).whiteSpace')=='nowrap'
            page.get_by_text('Đội hình và thay người',exact=True).click()
            expect(page.get_by_role('heading',name='Dự bị')).to_be_visible()
            expect(page.get_by_text('Vào sân 23′',exact=False).first).to_be_visible()
            page.get_by_text('Nguồn và đối chiếu',exact=True).click()
            expect(page.get_by_text('Báo cáo trận của VPF ghi',exact=False)).to_be_visible()
            page.get_by_role('button',name='Becamex TP. Hồ Chí Minh',exact=True).first.click()
            expect(page.get_by_text('Danh sách đăng ký cầu thủ · 27 cầu thủ',exact=True)).to_be_visible()
            page.get_by_text('Danh sách đăng ký cầu thủ · 27 cầu thủ',exact=True).click()
            expect(page.get_by_role('dialog').get_by_text('Ngô Tùng Quốc',exact=True)).to_be_visible()
            page.keyboard.press('Escape')
            expect(page.get_by_role('dialog')).not_to_be_visible()
            page.goto(origin+cup)
            expect(page.get_by_text('Joseph Shaqkeem Jaylon Khalio',exact=True).first).to_be_visible()
            expect(page.get_by_text('74′',exact=True).first).to_be_visible()
            expect(page.get_by_text('77′',exact=True).first).to_be_visible()
            expect(page.get_by_text('94′',exact=True)).to_be_visible()
            page.get_by_text('Đội hình và thay người',exact=True).click()
            expect(page.get_by_text('Huỳnh Tuấn Linh',exact=True)).to_be_visible()
            assert page.evaluate('document.documentElement.scrollWidth === document.documentElement.clientWidth')
            page.goto(origin+'#vl2/fixtures?period=all&scope=all&club=BEC')
            page.get_by_role('button',name=re.compile(r'^Lọc')).click()
            expect(page.get_by_text('Bỏ lọc CLB và giải',exact=True)).to_be_visible()
            page.get_by_text('Bỏ lọc CLB và giải',exact=True).click()
            assert 'period=all' in page.url
            assert 'club=' not in page.url
            assert page.locator('#fixture-results button[data-match]').count()==48
            page.get_by_text('Hiện thêm trận',exact=True).click()
            assert page.locator('#fixture-results button[data-match]').count()==96
            row=page.locator('#fixture-results button[data-match]').nth(65)
            row_id=row.get_attribute('data-match')
            row.click()
            page.get_by_role('button',name='Quay lại',exact=True).click()
            expect(page.locator(f'button[data-match="{row_id}"]')).to_be_focused()
            assert page.locator('#fixture-results button[data-match]').count()==96
            page.goto(origin+'#vl2/fixtures?match=missing')
            expect(page.get_by_role('heading',name='Không tìm thấy trận')).to_be_visible()
            page.get_by_role('button',name='Về lịch đấu',exact=True).click()
            expect(page.get_by_role('heading',name='Lịch đấu')).to_be_visible()
            page.get_by_role('button',name='CLB · Câu lạc bộ').click()
            page.get_by_role('searchbox').fill('becamex')
            expect(page.get_by_role('button',name='Becamex TP. Hồ Chí Minh')).to_be_visible()
            for league,players,leader in (('vl1',73,'Milan Makaric'),('vl2',83,'Mansaray Victor Nabay'),('nc',28,'Brenner Marlos Varanda De Oliveira')):
                page.goto(origin+f'#{league}/stats')
                expect(page.get_by_role('heading',name='Vua phá lưới')).to_be_visible()
                expect(page.locator('.scorer-cards li')).to_have_count(15)
                expect(page.get_by_text(leader,exact=True)).to_be_visible()
                page.get_by_role('button',name='Đầy đủ',exact=True).click()
                expect(page.locator('.scorer-table tbody tr')).to_have_count(players)
                assert page.evaluate('document.documentElement.scrollWidth === document.documentElement.clientWidth')
                page.get_by_role('button',name='Thu gọn',exact=True).click()
            for league,team_count in (('vl1',14),('vl2',14),('nc',27)):
                page.goto(origin+f'#{league}/stats')
                page.locator('[data-stats="teams"]').click()
                expect(page.get_by_role('heading',name='Thống kê câu lạc bộ')).to_be_visible()
                expect(page.locator('#stats-results .scorer-cards li')).to_have_count(7)
                for metric,label in (('goalsFor','Bàn thắng'),('goalsAgainst','Bàn thua'),('yellow','Thẻ vàng'),('red','Thẻ đỏ')):
                    page.get_by_label('Chỉ số',exact=True).select_option(metric)
                    expect(page.locator('#club-stat-filter')).to_have_value(metric)
                    page.get_by_role('button',name='Đầy đủ',exact=True).click()
                    expect(page.locator('#stats-results table tbody tr')).to_have_count(team_count)
                    expect(page.get_by_role('columnheader',name=label,exact=True)).to_be_visible()
                    tied=page.locator('.club-stats-table tbody tr').evaluate_all("""rows => {
                        const byPoints=new Map();
                        return rows.every(row=>{
                            const score=row.cells[2].textContent, rank=row.cells[0].textContent;
                            if (byPoints.has(score)) return byPoints.get(score)===rank;
                            byPoints.set(score,rank);
                            return true;
                        });
                    }""")
                    assert tied
                    page.get_by_role('button',name='Thu gọn',exact=True).click()
            page.goto(origin+'#nc/fixtures?match=nc-7')
            page.get_by_text('Thống kê trận đấu',exact=True).click()
            expect(page.locator('dl.detail-facts').filter(has_text='Thẻ vàng')).to_contain_text('2 – 4')
            expect(page.locator('dl.detail-facts').filter(has_text='Thẻ đỏ')).to_contain_text('0 – 0')
            page.goto(origin+'#vl1/fixtures?match=vl1-1-DNC-TCV')
            expect(page.get_by_role('link',name='Xem video tổng hợp')).to_have_attribute('href',re.compile(r'vpf\.vn/.+thanh-pho-dong-nai-vs-the-cong-viettel'))
            toggle=page.get_by_role('button',name='Giao diện tối')
            expect(toggle).to_be_visible()
            if page.locator('html').get_attribute('data-theme')=='light':
                toggle.click()
            expect(toggle).to_have_attribute('aria-pressed','true')
            page.reload()
            expect(page.locator('html')).to_have_attribute('data-theme','dark')
            page.goto(origin+'#vl1/fixtures?match=vl1-9-SLN-NBI')
            expect(page.get_by_text('Chi tiết trận',exact=True)).to_be_visible()
            expect(page.get_by_role('link',name='Xem video tổng hợp')).to_have_count(0)
            assert page.evaluate('document.documentElement.scrollWidth === document.documentElement.clientWidth')
            toggle.click()
            expect(page.locator('html')).to_have_attribute('data-theme','light')

            page.goto(origin+'#vl2/clubs')
            page.get_by_role('searchbox').fill('van hien')
            page.get_by_role('button',name=re.compile('Đại [Hh]ọc Văn Hiến')).click()
            expect(page.get_by_text('Nguyễn Đình Hưng',exact=True)).to_be_visible()
            expect(page.get_by_text('SVĐ Thống Nhất',exact=True)).to_be_visible()
            page.get_by_text('Danh sách đăng ký cầu thủ · 25 cầu thủ',exact=True).click()
            expect(page.locator('.roster-list li')).to_have_count(25)
            expect(page.get_by_text('Ban huấn luyện và nhân sự')).not_to_be_visible()
            page.keyboard.press('Escape')
            page.goto(origin+'#nc/competition')
            page.get_by_role('button',name='Sơ đồ',exact=True).click()
            if width>1000:
                expect(page.locator('.cup-column')).to_have_count(7)
                expect(page.locator('.cup-connections path')).to_have_count(14)
                expect(page.locator('.cup-overview [data-match="nc-26-1"]')).to_be_visible()
            else:
                page.get_by_role('button',name='Nhánh phải',exact=True).click()
                expect(page.locator('.cup-mobile [data-match="nc-25-1"]')).to_be_visible()
                page.get_by_role('button',name='Chung kết',exact=True).click()
                expect(page.locator('.cup-mobile [data-match="nc-26-1"]')).to_be_visible()
            page.get_by_text('Vòng loại · 11 cặp',exact=True).click()
            expect(page.locator('.cup-qualifiers .cup-pair')).to_have_count(11)
            assert page.evaluate('document.documentElement.scrollWidth === document.documentElement.clientWidth')
            page.goto(origin+'#vl2/following')
            expect(page.get_by_text('Chưa theo dõi đội nào ở V.League 2.')).to_be_visible()
            assert not page.get_by_text('Mới cập nhật',exact=True).count()
            page.evaluate("""() => {
              for (const id of Object.keys(clubs)) favorites.add(id);
              for (const m of Object.values(matches)) if (m.score) matchFavorites.add(m.id);
              save();
              render();
            }""")
            expect(page.locator('#follow-strip button')).to_have_count(14)
            expect(page.locator('.follow-games').last.locator('button[data-match]')).to_have_count(5)
            assert page.locator('.follow-games').first.locator('button[data-match]').count()<=5
            first=page.locator('#follow-strip .selected').get_attribute('data-follow-club')
            page.get_by_role('button',name='Đội tiếp theo',exact=True).click()
            current=page.locator('#follow-strip .selected').get_attribute('data-follow-club')
            assert current!=first
            page.reload()
            assert page.locator('#follow-strip .selected').get_attribute('data-follow-club')==current
            page.clock.set_fixed_time(datetime(2027,1,1,2,tzinfo=timezone.utc))
            page.locator('[data-follow-club="VHI"]').click()
            expect(page.locator('.follow-games').first.locator('[data-match="nc-13"]')).to_be_visible()
            if width<=760:
                page.locator('[data-follow-panel="saved"]').click()
                expect(page.locator('.follow-teams')).not_to_be_visible()
            else:
                assert page.locator('.follow-teams').bounding_box()['x']<page.locator('.follow-saved').bounding_box()['x']
            saved=page.locator('#saved-matches')
            expect(saved).to_be_visible()
            expect(saved.locator('button[data-match]')).to_have_count(56)
            assert saved.evaluate('(el)=>el.scrollHeight>el.clientHeight')
            assert saved.locator('button[data-match]').evaluate_all('(nodes)=>nodes.every(node=>node.dataset.match.startsWith("vl2-"))')
            saved_row=saved.locator('button[data-match]').nth(20)
            saved_row.click()
            old_saved_scroll=page.evaluate('history.state.fromList')
            assert old_saved_scroll
            page.get_by_role('button',name='Quay lại',exact=True).click()
            expect(saved_row).to_be_focused()
            assert saved.evaluate('(el)=>el.scrollTop')>0
            page.goto(origin+'#vl1/following')
            expect(page.locator('#saved-matches button[data-match]')).to_have_count(55)
            if width<=760:
                page.locator('[data-follow-panel="teams"]').click()
            expect(page.locator('#follow-strip button')).to_have_count(14)
            assert page.locator('#follow-strip button').evaluate_all('(nodes)=>nodes.every(node=>clubs[node.dataset.followClub].league==="vl1")')

            for league, classes in (('vl1',{'regional':1,'continental':1,'relegation':2}),
                                    ('vl2',{'promotion':2,'relegation':2})):
                page.goto(origin+f'#{league}/competition')
                page.get_by_role('button',name='Đầy đủ',exact=True).click()
                headers=page.locator('.ranking thead th')
                expect(headers).to_have_text(['Hạng','Đội','Số trận','Thắng','Hòa','Thua','Bàn thắng','Bàn thua','Hiệu số','Điểm'])
                for key,count in classes.items():
                    expect(page.locator(f'.ranking tr.zone-{key}')).to_have_count(count)
                if width<=540:
                    assert page.locator('.table-full').evaluate('(el)=>el.scrollWidth>el.clientWidth')
                assert page.evaluate('document.documentElement.scrollWidth === document.documentElement.clientWidth')
            page.goto(origin+'#vl1/archive')
            expect(page.get_by_role('heading',name='V.League 1',exact=True)).to_be_visible()
            assert not page.get_by_text('Lịch sử giải đấu',exact=True).count()
            sizes=page.locator('#nav button').evaluate_all('(nodes)=>nodes.map(node=>node.getBoundingClientRect().width)')
            assert max(sizes)-min(sizes)<.1
            if width>760:
                assert page.locator('.league-brand').evaluate('(el)=>{ const box=el.getBoundingClientRect(); return Math.abs((box.left+box.right)/2-innerWidth/2)<1; }')
            assert not errors,errors
            assert not [x for x in seen if x[1]>=400],seen
            print(f'PASS Chromium {width} px · lịch, màn trận, CLB, Theo dõi, bảng xếp hạng và bố cục',flush=True)
            context.close()

        context=browser.new_context(viewport={'width':390,'height':844},service_workers='block')
        page=context.new_page()
        page.clock.set_fixed_time(datetime(2026,11,27,5,tzinfo=timezone.utc))
        page.goto(origin)
        expect(page.get_by_text('Chưa có đồng bộ lịch và kết quả tự động.',exact=False)).to_be_visible()
        current={'schema':1,'mode':'sync','state':'ok','lastSuccessfulCheckAt':'2026-11-27T04:55:00Z'}
        page.route('**/data-status.json',lambda route:route.fulfill(json=current))
        page.get_by_role('button',name='Kiểm tra cập nhật').click()
        expect(page.locator('#data-health')).to_be_hidden()
        current['state']='delayed'
        page.get_by_role('button',name='Kiểm tra cập nhật').click()
        expect(page.get_by_text('Lần đọc nguồn thành công gần nhất:',exact=False)).to_be_visible()
        current.update(state='ok',lastSuccessfulCheckAt='2026-11-26T05:00:00Z')
        page.get_by_role('button',name='Kiểm tra cập nhật').click()
        expect(page.get_by_text('Chưa xác nhận được dữ liệu mới từ nguồn.',exact=False)).to_be_visible()
        print('PASS · trạng thái nguồn phân biệt bản chụp, đồng bộ thật, lỗi và dữ liệu cũ',flush=True)
        context.close()
        context=browser.new_context(viewport={'width':390,'height':844},service_workers='block')
        page=context.new_page()
        page.add_init_script('delete URLSearchParams.prototype.size')
        page.goto(origin+'#vl1/fixtures?period=results&scope=league&view=compact')
        match=page.locator('#fixture-results button[data-match]').first
        match_id=match.get_attribute('data-match')
        match.click()
        assert 'period=results' in page.url and 'match='+match_id in page.url
        page.reload()
        expect(page.get_by_role('heading',name='Chi tiết trận')).to_be_visible()
        expect(page.get_by_role('heading',name='Diễn biến trận đấu')).to_be_visible()
        print('PASS · giữ bộ lọc và mã trận khi trình duyệt thiếu URLSearchParams.size',flush=True)
        context.close()
        context=browser.new_context(viewport={'width':390,'height':844},service_workers='block')
        page=context.new_page()
        page.route('**/matches/vl2-6-XPT-BEC.json',lambda route:route.abort())
        page.goto(origin+champ)
        expect(page.get_by_text('Chưa tải được chi tiết trận.',exact=True)).to_be_visible()
        expect(page.get_by_text('Việt Trì',exact=True)).to_be_visible()
        page.unroute('**/matches/vl2-6-XPT-BEC.json')
        page.get_by_text('Thử lại',exact=True).click()
        expect(page.get_by_role('heading',name='Diễn biến trận đấu')).to_be_visible()
        context.close()
        context=browser.new_context(viewport={'width':390,'height':844})
        page=context.new_page()
        page.goto(origin+champ)
        page.evaluate('navigator.serviceWorker.ready')
        page.wait_for_function('() => Boolean(navigator.serviceWorker.controller)')
        page.reload()
        expect(page.get_by_role('heading',name='Diễn biến trận đấu')).to_be_visible()
        context.set_offline(True)
        page.reload()
        expect(page.get_by_role('heading',name='Diễn biến trận đấu')).to_be_visible()
        page.goto(origin+cup)
        expect(page.get_by_text('Chưa tải được chi tiết trận.',exact=True)).to_be_visible()
        context.set_offline(False)
        print('PASS · thử lại khi lỗi mạng và mở lại trận đã xem khi mất mạng',flush=True)
        browser.close()
    server.shutdown()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder',type=Path)
    parser.add_argument('--chromium',default=None)
    args=parser.parse_args()
    run(args.folder,args.chromium)
