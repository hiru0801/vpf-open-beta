"""Check VPF and optionally publish a verified static site on a symlink-capable host."""

import argparse
from contextlib import closing
from datetime import datetime, timedelta
import json
import os
from pathlib import Path
import runpy
import shutil
import sqlite3
import subprocess
import tempfile
import sys

from release_inputs import APP, verify_bundle
from vpf_highlights import ARCHIVES

importer=runpy.run_path(str(Path(__file__).with_name('backfill-vpf.py')))
VN=importer['source']['VN']
HEALTH='sync-status.json'


def atomic_json(path, value, mode=0o600):
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,delete=False) as output:
        json.dump(value,output,ensure_ascii=False,indent=2)
        output.write('\n')
        os.fchmod(output.fileno(),mode)
    Path(output.name).replace(path)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def now():
    return datetime.now(VN).isoformat(timespec='milliseconds')


def expired(stamp, at, hours):
    return not stamp or datetime.fromisoformat(stamp)+timedelta(hours=hours)<=datetime.fromisoformat(at)


def activate(state, stage, metadata, former):
    live=state/'site'/'current'
    views=state/'deployments'
    views.mkdir(exist_ok=True)
    view=Path(tempfile.mkdtemp(prefix=f'rev-{metadata["revision"]}-',dir=views))
    # Honor shared, setgid deployments without opening up a private state directory.
    if views.stat().st_mode & 0o2000:
        view.chmod(0o2750)
    try:
        # Keep the sealed bundle intact. The view serves its latest files and the
        # previous version's immutable assets for tabs that are still open.
        for file in stage.iterdir():
            if file.name!='releases':
                if file.is_file():
                    shutil.copy2(file,view/file.name)
                else:
                    (view/file.name).symlink_to(file,target_is_directory=True)
        (view/'releases').mkdir()
        (view/metadata['root']).symlink_to(stage/metadata['root'],target_is_directory=True)
        if former and former[1]['releaseId']!=metadata['releaseId']:
            (view/former[1]['root']).symlink_to(former[0]/former[1]['root'],target_is_directory=True)
        live.parent.mkdir(parents=True,exist_ok=True)
        pointer=live.with_name('.next-release')
        if pointer.is_symlink():
            pointer.unlink()
        pointer.symlink_to(view,target_is_directory=True)
        pointer.replace(live)
    except BaseException:
        if live.resolve()!=view:
            shutil.rmtree(view)
        raise
    return live


def public_health(path, health):
    payload={'schema':1,'mode':'sync','state':'ok' if health['status']=='ok' else 'delayed'}
    for key in ('lastSuccessfulCheckAt','lastHighlightCheckAt'):
        if health.get(key):
            payload[key]=health[key]
    if 'pendingReview' in health:
        payload['pendingReview']=health['pendingReview']
    atomic_json(path,payload,0o644)


def publish(state,pending):
    candidate=read(pending)
    current=read(APP/'updates.json')
    revision=candidate['revision']
    database=state/'review.sqlite'
    versions=state/'versions'
    stage=versions/f'rev-{revision}'
    live=state/'site'/'current'
    previous=None
    if live.exists() or live.is_symlink():
        previous=live.resolve()
        if not live.is_symlink() or not any(previous.is_relative_to(path) for path in (versions,state/'deployments')):
            raise ValueError('Đường dẫn công bố không thuộc quy trình phát hành này.')
    if candidate!=current:
        subprocess.run(['node','tools/publish.cjs','--verify-next',str(pending)],cwd=APP,check=True)
    subprocess.run([sys.executable,'tools/audit.py','--db',str(database),'record',str(pending)],cwd=APP,check=True)
    if not stage.exists():
        subprocess.run([sys.executable,'tools/release.py','--db',str(database),'--draft',str(pending),'--out',str(stage)],cwd=APP,check=True)
    with closing(sqlite3.connect(database)) as connection:
        expected=connection.execute('SELECT artifact_digest FROM release WHERE revision=?',(revision,)).fetchone()[0]
        if not expected:
            raise ValueError('Bản phát hành đang chờ chưa được niêm phong.')
        metadata=verify_bundle(stage,expected)
        if metadata['revision']!=revision or metadata['publishedAt']!=candidate['publishedAt']:
            raise ValueError('Tệp phát hành đang chờ khác bản nháp đã ghi.')
        former=None
        already_live=False
        if previous:
            previous_info=read(previous/'release-info.json')
            if previous_info['releaseId']!=metadata['releaseId']:
                prior_revision=previous_info['revision']
                if type(prior_revision) is not int or prior_revision>=revision:
                    raise ValueError('Bản đang phục vụ không đứng trước bản mới.')
                prior=connection.execute('SELECT artifact_digest FROM release WHERE revision=?',(prior_revision,)).fetchone()
                if not prior or not prior[0]:
                    raise ValueError('Không tìm thấy bản đã niêm phong đang phục vụ.')
                archive=versions/f'rev-{prior_revision}'
                former=(archive,verify_bundle(archive,prior[0],allow_retained=True))

            elif previous.is_relative_to(state/'deployments'):
                # The previous attempt may already have committed the switch.
                already_live=(previous/metadata['root']).resolve()==stage/metadata['root']
                already_live=already_live and all(
                    (previous/file.name).read_bytes()==file.read_bytes() if file.is_file()
                    else (previous/file.name).resolve()==file
                    for file in stage.iterdir() if file.name!='releases')
                if not already_live:
                    raise ValueError('Thư mục đang phục vụ khác gói cùng revision đã niêm phong.')

    # Regenerate the local outputs on a resume too, in case the last write was interrupted.
    command=['node','tools/publish.cjs']
    subprocess.run(command+([str(pending)] if candidate!=current else []),cwd=APP,check=True)
    if not already_live:
        activate(state,stage,metadata,former)
    pending.unlink()
    return live


def sync(state, cache, recent, publish_now, health):
    pending=state/'pending.json'
    if publish_now and pending.exists():
        print('Tiếp tục bản đã có ·',publish(state,pending))
        return
    at=now()
    full=recent is None or expired(health.get('lastFullRecheckAt'),at,24)
    candidate,report=importer['prepare'](cache,at,include_results=True,recent_days=None if full else recent)
    candidate,highlights=importer['add_highlights'](cache,at,candidate,None if full else recent)
    atomic_json(state/'highlight-check.json',highlights)
    health['highlightSourcesFailed']=len(highlights['errors'])
    if health['highlightSourcesFailed']<len(ARCHIVES)+1:
        health['lastHighlightCheckAt']=at
    if highlights['errors']:
        print('Một số nguồn video VPF chưa truy cập được. Xem highlight-check.json.',file=sys.stderr)
    atomic_json(state/'latest-check.json',report)
    queue_path=state/'review-queue.json'
    queue=read(queue_path) if queue_path.is_file() else {}
    for match,entry in report.items():
        if entry.get('pendingReview'):
            queue[match]=entry
        else:
            queue.pop(match,None)
    atomic_json(queue_path,queue)
    health['pendingReview']=len(queue)
    if candidate is not None:
        # Verify append-only history and the candidate before marking a full scan as complete.
        draft=state/'draft.json'
        atomic_json(draft,candidate)
        subprocess.run(['node','tools/publish.cjs','--verify-next',str(draft)],cwd=APP,check=True)
    health['lastSuccessfulCheckAt']=at
    if full:
        health['lastFullRecheckAt']=at
    if not publish_now:
        print('Bản nháp hợp lệ: '+str(state/'draft.json') if candidate else 'Chưa có thay đổi đủ điều kiện.')
        return
    if candidate is None:
        if (state/'site'/'current').exists():
            print('Kiểm tra VPF hoàn tất. Chưa có thay đổi đủ điều kiện.')
            return
        candidate=read(APP/'updates.json')
    atomic_json(pending,candidate)
    print('Bản web đã sẵn sàng ·',publish(state,pending))


def check_health(state, age):
    path=state/HEALTH
    if not path.is_file():
        raise ValueError('Chưa có nhật ký đồng bộ.')
    health=read(path)
    if health.get('status')!='ok':
        raise ValueError('Lần đồng bộ gần nhất bị lỗi. Xem '+str(path))
    if expired(health.get('lastSuccessfulCheckAt'),now(),age):
        raise ValueError('Đã quá thời hạn kiểm tra nguồn VPF. Xem '+str(path))
    if expired(health.get('lastHighlightCheckAt'),now(),age):
        raise ValueError('Chưa kiểm tra được kho video VPF trong thời hạn. Xem highlight-check.json.')
    print('Đồng bộ bình thường ·',health['lastSuccessfulCheckAt'],
          '· Hồ sơ chờ đối chiếu:',health.get('pendingReview',0),
          '· Nguồn video lỗi:',health.get('highlightSourcesFailed',0))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state',required=True,type=Path,help='Thư mục lưu trữ ngoài mã nguồn và web root')
    parser.add_argument('--cache',type=Path,help='Đọc lại bản sao HTML để kiểm thử')
    parser.add_argument('--recent-days',type=int,default=10)
    parser.add_argument('--all',action='store_true',help='Đối chiếu lại toàn bộ trận đã kết thúc')
    parser.add_argument('--publish',action='store_true',help='Phát hành vào site/current bên dưới state (máy chủ hỗ trợ symlink)')
    parser.add_argument('--public-status',type=Path,help='Ghi data-status.json vào thư mục dữ liệu động ngoài bản niêm phong')
    parser.add_argument('--check-health',action='store_true',help='Trả mã lỗi nếu lần chạy cuối lỗi hoặc dữ liệu kiểm tra đã cũ')
    parser.add_argument('--max-age-hours',type=int,default=3,help='Số giờ tối đa kể từ lần đọc nguồn thành công')
    args=parser.parse_args()
    state=args.state.resolve()
    if state.is_relative_to(APP) or min(args.recent_days,args.max_age_hours)<1:
        parser.error('Đặt thư mục trạng thái ngoài mã nguồn và dùng thời hạn lớn hơn 0.')
    public_path=args.public_status.resolve() if args.public_status else None
    if public_path and (
        not args.publish or args.cache or public_path.name!='data-status.json' or
        public_path.is_relative_to(state) or public_path.is_relative_to(APP)
    ):
        parser.error('Chỉ ghi data-status.json ngoài thư mục bản phát hành khi đồng bộ và công bố từ nguồn thật.')
    try:
        if args.check_health:
            check_health(state,args.max_age_hours)
            return
        state.mkdir(mode=0o700,parents=True,exist_ok=True)
        with closing(sqlite3.connect(state/'lock.sqlite',timeout=2)) as lock:
            lock.execute('BEGIN IMMEDIATE')
            path=state/HEALTH
            health=read(path) if path.is_file() else {}
            health['startedAt']=now()
            try:
                with tempfile.TemporaryDirectory(prefix='vpf-sync-') as tmp:
                    cache=args.cache or Path(tmp)
                    cache.mkdir(parents=True,exist_ok=True)
                    sync(state,cache,None if args.all else args.recent_days,args.publish,health)
            except (OSError,sqlite3.Error,ValueError,subprocess.CalledProcessError,KeyError,TypeError) as error:
                failed={**health,'status':'error','finishedAt':now(),'error':str(error)}
                atomic_json(path,failed)
                if public_path:
                    public_health(public_path,failed)
                raise
            health.pop('error',None)
            atomic_json(path,{**health,'status':'ok','finishedAt':now()})
            if public_path:
                public_health(public_path,health)
    except (OSError,sqlite3.Error,ValueError,subprocess.CalledProcessError,KeyError,TypeError) as error:
        parser.exit(1,str(error)+'\n')


if __name__=='__main__':
    main()
