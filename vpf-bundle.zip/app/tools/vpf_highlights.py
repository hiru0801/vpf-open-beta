"""Find single-match highlight pages published in the official VPF video archives."""

from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta
from html import unescape
import json
import re
import subprocess
import unicodedata
from urllib.parse import urlencode, urljoin, urlsplit, urlunsplit

ROOT = 'https://vpf.vn/category/video-highlight/'
API = 'https://vpf.vn/wp-json/wp/v2/posts'
# VPF WordPress category IDs for the three video archives, their highlight subcategories and featured videos.
VIDEO_CATEGORIES = '75,87,88,89,91,123,754,755'
ARCHIVES = {
    'all': ROOT,
    'vl1': ROOT+'video-vleague/highlights-khoanh-khac/',
    'vl2': ROOT+'video-hang-nhat/highlights-khoanh-khac-video-hang-nhat/',
    'nc': ROOT+'video-cup-quoc-gia/highlights-khoanh-khac-video-cup-quoc-gia/',
}
NAMES = {
    'CAH': ('CA Hà Nội','CAHN'),
    'DNC': ('Trường Tươi Đồng Nai','Trường Tươi Bình Phước'),
    'DNA': ('Đà Nẵng',),
    'HAG': ('HAGL',),
    'HCM': ('CA TP. Hồ Chí Minh','CA TP.HCM','Công An Thành phố Hồ Chí Minh'),
    'HNO': ('Hà Nội',),
    'HPH': ('Hải Phòng',),
    'KKH': ('Khánh Hòa',),
    'NDI': ('Nam Định',),
    'SLN': ('SLNA',),
    'TCT': ('Cần Thơ',),
    'TCV': ('Thể Công',),
    'TPH': ('TPHCM','Thành phố Hồ Chí Minh'),
    'VHI': ('ĐH Văn Hiến','Văn Hiến'),
    'XPT': ('Phú Thọ',),
}
SEASON = re.compile(r'\b(20\d{2})\s*[/–-]\s*((?:20)?\d{2})\b')
HEAD = re.compile(r'^\s*\[?highlights?\]?\s*[:|–—-]*\s*', re.I)
VERSUS = re.compile(r'\s+(?:vs\.?|gặp)\s+', re.I)
DASH = re.compile(r'\s+[–—-]\s+')
LEAGUE = {
    'nc':re.compile(r'cúp\s*(?:quốc\s*gia|qg)',re.I),
    'vl2':re.compile(r'(?:v[.\s]*league\s*2(?!\d)|hạng\s*nhất|hnqg)',re.I),
    'vl1':re.compile(r'(?:v[.\s]*league\s*1(?!\d)|vđqg)',re.I),
}


def normalized(text):
    text = unicodedata.normalize('NFD', text.casefold().replace('đ','d'))
    return re.sub(r'[^a-z0-9]+', '', text)


def official_video(url):
    target=urlsplit(urljoin(ROOT,url))
    if target.scheme=='https' and target.netloc=='vpf.vn' and target.path.startswith('/video-highlight/'):
        return urlunsplit((target.scheme,target.netloc,target.path,'',''))
    return None


def api_articles(cache,cutoff):
    page,total=1,1
    while page<=total:
        path=cache/f'api-{cutoff.isoformat()}-{page}.json'
        if path.is_file():
            batch=json.loads(path.read_text(encoding='utf-8'))
        else:
            params=dict(categories=VIDEO_CATEGORIES,after=cutoff.isoformat()+'T00:00:00',per_page=100,page=page,
                        _fields='date,title,link')
            result=subprocess.run(['curl','-fsS','--max-time','20','--proto','=https','-D','-',
                                   API+'?'+urlencode(params)],check=True,capture_output=True)
            headers,_,body=result.stdout.rpartition(b'\r\n\r\n')
            pages=re.search(rb'(?im)^x-wp-totalpages:\s*(\d+)',headers)
            if not pages:
                raise ValueError('Nguồn video VPF thiếu số trang.')
            batch=dict(total=int(pages[1]),posts=json.loads(body))
            path.write_text(json.dumps(batch,ensure_ascii=False),encoding='utf-8')
        total=batch['total']
        if not isinstance(total,int) or not 0<=total<=65:
            raise ValueError('Số trang video VPF không hợp lệ.')
        for post in batch['posts']:
            target=official_video(post['link'])
            if target:
                yield date.fromisoformat(post['date'][:10]),target,unescape(post['title']['rendered'])
        page+=1


def archive_articles(doc):
    for link in doc.xpath('//div[contains(concat(" ",normalize-space(@class)," ")," td-main-content ")]'
                          '//h3[contains(@class,"entry-title")]/a'):
        target=official_video(link.get('href',''))
        if not target:
            continue
        times=link.xpath('../../*//time/@datetime')
        try:
            day = date.fromisoformat(times[0][:10])
        except (IndexError,ValueError):
            continue
        yield (day, target,
               ' '.join((link.get('title') or link.text_content()).split()))


def scan_archive(load, cache, label, url, cutoff):
    posts = {}
    for page in range(1,65):
        pointer = f'{url}page/{page}/' if page>1 else url
        doc = load(pointer,cache,f'{label}-{page}.html')
        articles = list(archive_articles(doc))
        if not articles:
            raise ValueError(f'Trang {page} của kho video VPF không có bài đọc được.')
        posts.update({item[1]:item for item in articles if item[0]>=cutoff})
        next_url = f'{url}page/{page+1}/'
        if min(item[0] for item in articles)<cutoff or not doc.xpath('//a[@href=$url]',url=next_url):
            return list(posts.values())
    raise ValueError('Kho video VPF vượt giới hạn phân trang, cần đối chiếu.')


def match_highlights(data, articles):
    season = data['season']
    start = min(date.fromisoformat(league['start']) for league in data['leagues'].values() if league.get('start'))
    aliases = defaultdict(set)
    for id,club in data['clubs'].items():
        for name in (club['name'],id,*club.get('aliases',[]),*NAMES.get(id,())):
            aliases[normalized(name)].add(id)
    by_pair = defaultdict(list)
    for match in data['matches'].values():
        if match.get('score') and match.get('date') and match.get('homeClub') and match.get('awayClub'):
            by_pair[match['homeClub'],match['awayClub']].append(match)
    found = defaultdict(dict)
    unresolved = {}
    for day,url,title in sorted(set(articles)):
        if day<start or not HEAD.match(title):
            continue
        years = SEASON.findall(title)
        if years and season not in {f'{a}/{b[-2:]}' for a,b in years}:
            continue
        content = HEAD.sub('', title, count=1)
        matchup = re.split(r'[|/:]',content,maxsplit=1)[0]
        teams = VERSUS.split(matchup,maxsplit=1) if VERSUS.search(matchup) else DASH.split(matchup,maxsplit=1)
        if len(teams)!=2:
            unresolved[url]=title
            continue
        league = next((key for key,pattern in LEAGUE.items() if pattern.search(content)),None)
        if not league:
            path = urlsplit(url).path
            league = next((key for key,part in (('nc','video-cup-quoc-gia'),('vl2','video-hang-nhat'),
                                                ('vl1','video-vleague')) if f'/{part}/' in path),None)
        teams = [normalized(re.sub(r'^CLB\s+','',name.strip(),flags=re.I)) for name in teams]
        max_lag = None if years and league else 14
        candidates = []
        for home in aliases[teams[0]]:
            for away in aliases[teams[1]]:
                for match in by_pair[home,away]:
                    if league and match['league']!=league:
                        continue
                    lag=(day-date.fromisoformat(match['date'])).days
                    if lag>=0 and (max_lag is None or lag<=max_lag):
                        candidates.append((lag,match['id']))
        if len(candidates)!=1:
            unresolved[url]=title
            continue
        lag,id=candidates[0]
        found[id][url]=(lag,day,title)
    winners = {}
    for id, options in found.items():
        existing = data['matches'][id].get('highlightUrl')
        # Keep the existing official match page where duplicate posts show the same match.
        winners[id]=existing if existing in options else min(options,key=lambda url:(options[url][:2],len(url),url))
    return winners,unresolved


def discover(load,cache,data,at,recent_days=None):
    start=min(date.fromisoformat(v['start']) for v in data['leagues'].values() if v.get('start'))
    cutoff=max(start,datetime.fromisoformat(at).date()-timedelta(days=recent_days)) if recent_days else start
    def collect(item):
        label,url=item
        try:
            return label,scan_archive(load,cache,label,url,cutoff),None
        except (ValueError,OSError,subprocess.CalledProcessError) as error:
            return label,[],str(error)
    articles, failures = [], {}
    try:
        articles.extend(api_articles(cache,cutoff))
    except (ValueError,OSError,subprocess.CalledProcessError,KeyError,TypeError) as error:
        failures['api']=str(error)
    if recent_days is None or failures:
        with ThreadPoolExecutor(max_workers=len(ARCHIVES)) as pool:
            for label,posts,error in pool.map(collect,ARCHIVES.items()):
                articles.extend(posts)
                if error:
                    failures[label]=error
    day=datetime.fromisoformat(at).date()
    winners,unresolved=match_highlights(data,[post for post in articles if post[0]<=day])
    return winners,dict(matched=len(winners),review=unresolved,errors=failures)
