"""Regression checks for the fixed sources, classification and partial failures."""
from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import runpy
import subprocess
from tempfile import TemporaryDirectory

tool=runpy.run_path(str(Path(__file__).with_name('sync-news.py')))
logic=tool['run'].__globals__
app=tool['APP']
publishers={source for source,_,_ in tool['SOURCES']}
base=json.loads(subprocess.check_output(['node','-e',"global.window={};require('./data.js');console.log(JSON.stringify(window.VPF_DATA.clubs))"],cwd=app))
classify=lambda title,section=None: tool['classify'](title,'',section,base,tool['club_patterns'](base))
assert classify('Nam Định vs CAHN tại vòng 9 V-League')==(['vl1'],['CAH','NDI'])
assert classify('Becamex TP.HCM đá vòng 9 V.League 2')==(['vl2'],['BEC'])
assert classify('Cúp Quốc gia: Đồng Nai gặp Bình Minh Sài Gòn')==(['nc'],['DNC','BMS'])
assert classify('CLB Công An TP.HCM thua trên sân nhà')==(['vl1'],['HCM'])
assert classify('Viettel tăng vùng phủ sóng tại Hà Nội')==([],[])
assert classify('U17 Việt Nam đặt mục tiêu dự World Cup và đá V.League')==([],[])
assert classify('CLB CAHN gặp Vissel Kobe ở Cúp C1 châu Á')==([],[])
assert classify('Hạng nhất Anh: Derby County thắng trận')==([],[])
assert not tool['article_url']('vtc','https://evil.example/lich-ar100.html','https://vtcnews.vn')
assert tool['parse_date']('29/11/2026 - 19:15').hour==19
assert tool['parse_date']('32/11/2026 - 19:15') is None
assert tool['parse_date']('Fri, 27 Nov 2026 04:00:00 +0000').hour==11
assert tool['parse_date']('2026-11-27T11:39+7:00').isoformat()=='2026-11-27T11:39:00+07:00'

stub=app/'news-snapshot.js'
payload=json.loads(stub.read_text().split('window.VPF_NEWS=',1)[1].rstrip().removesuffix(';'))
assert set(payload['sources'])==publishers and len(publishers)==6 and len(payload['articles'])<=120
assert set(l for a in payload['articles'] for l in a['leagues'])=={'vl1','vl2','nc'}
assert max(Counter(a['source'] for a in payload['articles']).values())<=20
assert all(tool['article_url'](a['source'],a['url'],a['url'])==a['url'] for a in payload['articles'])

url='https://znews.vn/bong-da-viet-nam.html'
domestic='https://bongdaplus.vn/bong-da-viet-nam'
second='https://bongdaplus.vn/hang-nhat-quoc-gia'
headline='Trước vòng 9 giải hạng Nhất Sacombank 2026/27: Đại chiến ở sân Thái Nguyên'
link=next(a['url'] for a in payload['articles'] if a['title']==headline)
logic['SOURCES']=(('znews',url,None),('vtc','https://vtcnews.vn/bong-da-viet-nam-115.html',None),
                  ('bongdaplus',second,'vl2'),('bongdaplus',domestic,None))
html='<article><h3 class="article-title"><a href="/tin-v-league-post123.html">Nam Định vs CAHN ở V.League</a></h3><time>27/11/2026 - 10:00</time></article>'
detail='<html><script type="application/ld+json">{"datePublished":"2026-11-27T11:39:22+07:00"}</script><meta name="description" content="Thái Nguyên và Hưng Yên"></html>'
def fake(address,cache):
    if address==url:
        return html.encode()
    if address==domestic:
        return (f'<a class="title" href="{link}">{headline}</a>'
                '<a class="title" href="/doi-tuyen-quoc-gia/doi-tuyen-viet-nam-123.html">Đội tuyển Việt Nam</a>').encode()
    if address==link:
        return detail.encode()
    raise OSError('Nguồn tạm gián đoạn')
logic['fetch']=fake
with TemporaryDirectory() as tmp:
    p=Path(tmp)/'news-feed.json'
    now=datetime.fromisoformat('2026-11-27T12:00:00+07:00')
    p.write_text(json.dumps({'articles':[{'source':'laodong','url':'https://laodong.vn/test.html',
                                         'publishedAt':now.isoformat()}],'sources':{'laodong':{'status':'ok'}}}))
    assert not tool['run'](p,None,now)
    previous=json.loads(p.read_text())
    assert [a['source'] for a in previous['articles']]==['bongdaplus','znews']
    item=previous['articles'][0]
    assert item['url']==link and item['publishedAt']=='2026-11-27T11:39:22+07:00'
    assert item['leagues']==['vl2'] and set(item['clubs'])=={'TNG','HYE'}
    assert previous['sources']['bongdaplus']['status']=='partial'
    assert previous['sources']['vtc']['status']=='unavailable' and 'laodong' not in previous['sources']
    logic['fetch']=lambda *_: (_ for _ in ()).throw(OSError('Mất mạng'))
    assert not tool['run'](p,None,now)
    kept=json.loads(p.read_text())
    assert kept['articles']==previous['articles'] and kept['sources']['znews']['status']=='unavailable'
print('PASS · lọc nguồn, lịch đăng, giải/CLB, giữ tin khi nguồn lỗi.')
