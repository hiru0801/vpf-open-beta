'use strict';

const {readFileSync,writeFileSync,renameSync,mkdirSync,existsSync} = require('node:fs');
const {join,resolve} = require('node:path');
const {isDeepStrictEqual} = require('node:util');
const vm = require('node:vm');
const {compile,sideId} = require('../data-update.js');
const calendar = require('../calendar.js');

function readJson(path) {
  return JSON.parse(readFileSync(path,'utf8'));
}
function writeFile(path,contents) {
  const temp=path+'.'+process.pid+'.tmp';
  writeFileSync(temp,contents);
  renameSync(temp,path);
}

const folder=resolve(__dirname,'..');
const feedPath=join(folder,'updates.json');
const checkOnly=process.argv[2]==='--check';
const verifyNext=process.argv[2]==='--verify-next';
const input=process.argv[checkOnly||verifyNext?3:2];
const calendarFolder=join(folder,'calendars');

try {
  const env={window:{}};
  vm.runInNewContext(readFileSync(join(folder,'data.js'),'utf8'),env);
  const base=env.window.VPF_DATA;
  const current=readJson(feedPath);
  if (verifyNext && !input) throw new Error('Cần đường dẫn đến bản nháp.');
  const candidate=checkOnly&&input==='-'?JSON.parse(readFileSync(0,'utf8')):input?readJson(resolve(input)):current;
  const update=compile(base,candidate);
  if (checkOnly) {
    console.log('Dữ liệu hợp lệ · bản '+update.revision+' · '+Object.keys(update.matches).length+' trận được cập nhật.');
    process.exit(0);
  }
  if (input && (update.revision<=current.revision || Date.parse(update.publishedAt)<Date.parse(current.publishedAt))) {
    throw new Error('Bản mới cần tăng revision và có publishedAt bằng hoặc sau bản đã phát hành.');
  }
  if (input && !isDeepStrictEqual(candidate.matches.slice(0,current.matches.length),current.matches)) {
    throw new Error('Giữ nguyên lịch sử đã xuất bản và thêm mục điều chỉnh vào cuối danh sách.');
  }
  if (verifyNext) {
    console.log('Bản nháp hợp lệ và nối tiếp bản '+current.revision+'.');
    process.exit(0);
  }
  const matches={...base.matches,...update.matches};
  const data={...base,sources:{...base.sources,...update.sources}};

  const events=Object.fromEntries(Object.keys(base.clubs).map(id=>[id,[]]));
  for (const m of Object.values(matches).sort((a,b)=>(a.date||'').localeCompare(b.date||'')||(a.time||'').localeCompare(b.time||''))) {
    const home=sideId(base.ties,matches,m.home),away=sideId(base.ties,matches,m.away);
    if (!home || !away) continue;
    const before=m.history?.slice().reverse().find(entry=>entry.before?.status==='scheduled' && entry.before.date && entry.before.time)?.before;
    const cancelled=['postponed','tbd','provisional'].includes(m.status)&&Boolean(before);
    if (m.status!=='scheduled' && !cancelled) continue;
    const slot=cancelled?{...m,date:before.date,time:before.time,venue:before.venue}:m;
    const title=base.clubs[home].name+' – '+base.clubs[away].name;
    const event=calendar.event(data,slot,title,base.asOf+'T00:00:00+07:00','',cancelled);
    events[home].push(event);
    events[away].push(event);
  }

  if (!existsSync(calendarFolder)) mkdirSync(calendarFolder);
  for (const [id,list] of Object.entries(events)) writeFile(join(calendarFolder,id+'.ics'),calendar.render(list,'VPF · '+base.clubs[id].name));
  writeFile(join(folder,'data-published.js'),"'use strict';\nwindow.VPF_RELEASE = "+JSON.stringify(candidate).replaceAll('<','\\u003c')+';\n');
  if (input) writeFile(feedPath,JSON.stringify(candidate,null,2)+'\n');
  writeFile(join(folder,'release-info.json'),JSON.stringify({
    season:base.season,revision:candidate.revision,publishedAt:candidate.publishedAt
  })+'\n');
  console.log('Đã tạo '+Object.keys(events).length+' lịch CLB cho bản dữ liệu '+update.revision+'.');
} catch (error) {
  console.error(error.message);
  process.exitCode=1;
}
