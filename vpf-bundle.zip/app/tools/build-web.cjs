'use strict';

const fs=require('node:fs');
const path=require('node:path');
const {compile,scorerTables,clubStatTables}=require('../data-update.js');
const [releaseId,out]=process.argv.slice(2);
global.window={};
require('../data.js');
const base=window.VPF_DATA;
const feed=require('../updates.json');
const update=compile(base,feed);
const allMatches={...base.matches,...update.matches};
const allSources={...base.sources,...update.sources};
const folder='releases/'+releaseId+'/';
const release={season:base.season,revision:update.revision,publishedAt:update.publishedAt,releaseId,root:folder,assets:folder+'assets/'};
const output=path.join(out,folder);
const json=(target,data)=>fs.writeFileSync(target,JSON.stringify(data)+'\n');
const js=value=>JSON.stringify(value).replaceAll('<','\\u003c');
const supply=(keys)=>Object.fromEntries([...new Set(keys)].filter(key=>allSources[key]).map(key=>[key,allSources[key]]));
const print=(type,id,data,sources)=>json(path.join(output,type,id+'.json'),{releaseId,id,data,sources});
for (const type of ['matches','clubs']) fs.mkdirSync(path.join(output,type),{recursive:true});
const compact={...base,matches:{},clubs:{},standings:{...base.standings,...update.tables},scorers:scorerTables(base.ties,allMatches,update.rosters)};
compact.clubStats=clubStatTables(base.leagues,base.ties,allMatches);
const allCompactSources=new Set([
  ...Object.keys(base.sources),...Object.values(update.tableMeta).flatMap(m=>[m.source,...(m.adjustments||[]).map(a=>a.source)])
]);
const compactKeys=['id','league','round','tie','leg','home','away','score','date','time','venue','status',
  'window','month','makeup','changed','penalties','broadcast','scheduleNote'];
for (const m of Object.values(allMatches)) {
  const boot=Object.fromEntries(compactKeys.filter(key=>m[key]!==undefined).map(key=>[key,m[key]]));
  const history=m.history||[];
  const detailKeys=['events','matchSquads','goals','lineups','history','goalsSource','lineupsSource','eventsSource','squadsSource','pairSource',
    'source','timingSource','broadcast','scheduleNote','watchUrl','watchSource','highlightUrl','highlightSource','attendance','yellow','red',
    'sequence','scheduleModified','resultModified','resultSource','highlightAt'];
  const detail=Object.fromEntries(detailKeys.filter(key=>m[key]!==undefined).map(key=>[key,m[key]]));
  if (m.evidence?.length) {
    // Only the most recent relevant observations are public. SQLite keeps full review history.
    const fields=new Set();
    detail.evidence=m.evidence.slice().reverse().filter(item=>{
      if (item.fields.every(field=>fields.has(field))) return false;
      item.fields.forEach(field=>fields.add(field));
      return true;
    }).reverse();
  }
  if (Object.keys(detail).length) {
    boot.hasDetail=true;
    const sourceKeys=[...history.flatMap(h=>[h.source,h.beforeSource]),...detailKeys.filter(k=>k==='source'||k.endsWith('Source')).map(key=>detail[key])];
    for (const item of detail.evidence||[]) sourceKeys.push(item.source,...item.checks.map(c=>c.source));
    print('matches',m.id,detail,supply(sourceKeys));
  }
  compact.matches[m.id]=boot;
}
delete compact.goals;
for (const [id,club] of Object.entries(base.clubs)) {
  const roster=update.rosters[id];
  compact.clubs[id]={...club,logo:folder+club.logo.replace(/\.[^.]+$/,'.webp'),roster:[],
    hasRoster:Boolean(roster||club.roster.length),rosterCount:roster?.players.length||club.roster.length};
  if (roster) {
    const {players,...profile}=roster;
    Object.assign(compact.clubs[id],profile);
    allCompactSources.add(profile.source);
    allCompactSources.add(profile.yearSource);
    print('clubs',id,roster,supply([roster.source,roster.yearSource]));
  } else if (club.roster.length) {
    print('clubs',id,{legacy:club.roster},{});
  }
}
delete compact.archive;
compact.sources=supply(allCompactSources);
const fields=[...compactKeys,'hasDetail'];
const index=Object.values(compact.matches).map(m=>{
  const values=fields.map(key=>m[key]??null);
  while (values.length && values.at(-1)===null) values.pop();
  return values;
});
delete compact.matches;
const boot="'use strict';\nwindow.VPF_DATA="+js(compact)+";\n{ const fields="+js(fields)+";\nwindow.VPF_DATA.matches=Object.fromEntries("+js(index)+".map(row=>[row[0],Object.fromEntries(row.flatMap((value,i)=>value===null?[]:[[fields[i],value]]))])); }\nwindow.VPF_WEB_RELEASE="+js({...release,tableMeta:update.tableMeta,staleTables:update.staleTables})+";\n";
const size=Buffer.byteLength(boot);
if (size>120000) throw Error('Dữ liệu mở app vượt ngân sách 120 KB: '+size+' B');
fs.writeFileSync(path.join(output,'index-data.js'),boot);
for (const file of ['styles.css','theme.js','data-update.js','calendar.js','match-view.js','competition-view.js','web-data.js','news-view.js','news-snapshot.js','app.js']) fs.copyFileSync(path.join(__dirname,'..',file),path.join(output,file));
require('../news-snapshot.js');
json(path.join(out,'news-feed.json'),{...window.VPF_NEWS,mode:'snapshot'});
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8')
  .replace('</head>','  <link rel="manifest" href="manifest.webmanifest">\n'+
    '  <link rel="icon" type="image/png" href="'+folder+'assets/app-192.png">\n'+
    '  <link rel="apple-touch-icon" href="'+folder+'assets/app-180.png">\n</head>')
  .replace('src="data.js"','src="'+folder+'index-data.js"')
  .replace(/\sfile:(?=[; ])/g,'')
  .replace(/  <script src="data-published\.js" defer><\/script>\n/,'')
  .replace(/(src|href)="(styles\.css|theme\.js|data-update\.js|calendar\.js|match-view\.js|competition-view\.js|web-data\.js|news-view\.js|app\.js|assets\/vl1\.png)"/g,
    (_,type,url)=>type+'="'+folder+url.replace(/\.png$/,'.webp')+'"');
fs.writeFileSync(path.join(out,'index.html'),html);
json(path.join(out,'release-info.json'),release);
json(path.join(out,'data-status.json'),{schema:1,mode:'snapshot'});
json(path.join(out,'manifest.webmanifest'),{
  id:'./',name:'VPF App · Bóng đá Việt Nam',short_name:'VPF App',lang:'vi',
  start_url:'./',scope:'./',display:'standalone',theme_color:'#172b49',background_color:'#f5f7fa',
  icons:[192,512].map(size=>({src:folder+'assets/app-'+size+'.png',sizes:size+'x'+size,type:'image/png'}))
});
const worker=fs.readFileSync(path.join(__dirname,'../worker.js'),'utf8')
  .replace('__RELEASE__',releaseId).replace('__REVISION__',String(update.revision));
fs.writeFileSync(path.join(out,'worker.js'),worker);
console.log('Dữ liệu mở app: '+size+' B · '+index.length+' trận.');
