window.VPF_DATA = {
  "asOf": "2026-11-26",
  "season": "2026/27",
  "leagues": {
    "vl1": {
      "name": "V.League 1",
      "sponsor": "LPBank",
      "start": "2026-09-04",
      "end": "2027-05-09",
      "rounds": 26,
      "total": 182,
      "clubs": [
        "HNO",
        "CAH",
        "TCV",
        "NDI",
        "HPH",
        "THA",
        "SLN",
        "HAG",
        "HLH",
        "DNA",
        "HCM",
        "NBI",
        "BNI",
        "DNC"
      ],
      "calendar": "vl1cal"
    },
    "vl2": {
      "name": "V.League 2",
      "sponsor": "SACOMBANK",
      "start": "2026-09-11",
      "end": "2027-05-08",
      "rounds": 26,
      "total": 182,
      "clubs": [
        "BEC",
        "HYE",
        "TNG",
        "TPH",
        "BMS",
        "CND",
        "KKH",
        "VHI",
        "QNU",
        "TCT",
        "XPT",
        "HUE",
        "LAN",
        "LDO"
      ],
      "calendar": "vl2cal"
    },
    "nc": {
      "name": "Cúp Quốc gia",
      "sponsor": "SACOMBANK",
      "start": "2026-09-18",
      "end": "2027-05-16",
      "rounds": 5,
      "total": 29,
      "clubs": [
        "BEC",
        "BMS",
        "BNI",
        "CAH",
        "CND",
        "DNA",
        "DNC",
        "HAG",
        "HCM",
        "HLH",
        "HNO",
        "HPH",
        "HUE",
        "HYE",
        "KKH",
        "LAN",
        "LDO",
        "NBI",
        "NDI",
        "QNU",
        "SLN",
        "TCT",
        "TCV",
        "THA",
        "TPH",
        "VHI",
        "XPT"
      ],
      "calendar": "cupcal"
    }
  },
  "clubs": {
    "HNO": {
      "name": "Hà Nội FC",
      "league": "vl1",
      "logo": "assets/club-hno.webp",
      "year": "2006",
      "stadium": "Hàng Đẫy",
      "roster": [
        [
          "1",
          "Quan Văn Chuẩn",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "5",
          "Nguyễn Văn Hoàng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "66",
          "Phạm Đình Hải",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "3",
          "Lê Văn Hà",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "7",
          "Phạm Xuân Mạnh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "16",
          "Nguyễn Thành Chung",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "22",
          "Nguyễn Công Nhật",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "29",
          "Nguyễn Đức Anh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "33",
          "Nguyễn Anh Tiệp",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "35",
          "Ferreira Da Silva Adriel Tadeu",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "44",
          "Christie Cyrus Sylvester Frederick",
          "Jamaica",
          "Hậu vệ"
        ],
        [
          "86",
          "Trần Văn Thắng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Felida Kevin Antonio",
          "Curaçao",
          "Tiền vệ"
        ],
        [
          "8",
          "Nguyễn Văn Trường",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "11",
          "Đỗ Hoàng Hên",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Nguyễn Hai Long",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "15",
          "Phạm Đức Huy",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "18",
          "Bùi Ngọc Long",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Lê Xuân Tú",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "20",
          "Đậu Hồng Phong",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "21",
          "Vũ Đình Hai",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "24",
          "Chu Ngọc Nguyễn Lực",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "36",
          "Sade Iuval",
          "Israel",
          "Tiền vệ"
        ],
        [
          "88",
          "Đỗ Hùng Dũng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Faurand-Tournaire Aymeric",
          "Pháp",
          "Tiền đạo"
        ],
        [
          "10",
          "Nguyễn Văn Quyết",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "17",
          "Hồ Thanh Minh",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "23",
          "Nguyễn Văn Tùng",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "90",
          "Jung Andrew Patrick",
          "Pháp",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Hà Nội"
      ]
    },
    "CAH": {
      "name": "Công An Hà Nội",
      "league": "vl1",
      "logo": "assets/club-cah.webp",
      "year": "1956",
      "stadium": "Hàng Đẫy",
      "roster": [
        [
          "1",
          "Nguyễn Filip",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "23",
          "Vũ Thành Vinh",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "30",
          "Y Êli Niê",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Vũ Đức Huy",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "4",
          "Phan Ngọc Tín",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Đoàn Văn Hậu",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "7",
          "Cao Pendant Quang Vinh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "17",
          "Vũ Văn Thanh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "21",
          "Trần Đình Trọng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "38",
          "Nguyễn Adou Legley Minh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "55",
          "Frans Putros",
          "Indonesia",
          "Hậu vệ"
        ],
        [
          "68",
          "Bùi Hoàng Việt Anh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "93",
          "Kevin Pham Ba",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Stefan Mauk",
          "Australia",
          "Tiền vệ"
        ],
        [
          "11",
          "Lê Phạm Thành Long",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "12",
          "Hoàng Văn Toản",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Damià Sabater",
          "Tây Ban Nha",
          "Tiền vệ"
        ],
        [
          "15",
          "Bùi Xuân Thịnh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Nguyễn Quang Hải",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "26",
          "Hà Văn Phương",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "88",
          "Lê Văn Đô",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "David Henen",
          "Bỉ",
          "Tiền đạo"
        ],
        [
          "9",
          "Nguyễn Đình Bắc",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "10",
          "Léo Artur",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "18",
          "Đinh Thanh Bình",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "72",
          "Alan Grafite",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "90",
          "Brayan Perea",
          "Colombia",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "CAHN"
      ]
    },
    "TCV": {
      "name": "Thể Công–Viettel",
      "league": "vl1",
      "logo": "assets/club-tcv.webp",
      "year": "1954",
      "stadium": "Hàng Đẫy",
      "roster": [
        [
          "1",
          "Lawrence Robbie Caruso",
          "Australia",
          "Thủ môn"
        ],
        [
          "28",
          "Nguyễn Văn Việt",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "33",
          "Phí Minh Long",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Lương Chí Khải",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "4",
          "Bùi Tiến Dũng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "12",
          "Phan Tuấn Tài",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "15",
          "Lucas Alves de Araujo",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "16",
          "Phạm Trung Hiếu",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "18",
          "Đinh Viết Tú",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "20",
          "Đào Văn Nam",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "97",
          "Triệu Việt Hưng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Andre Luiz Guimares Siqueira Junior",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "7",
          "Wesley Nata Wachholz",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "8",
          "Nguyễn Hữu Thắng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "11",
          "Khuất Văn Khang",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Paulo Tapeu Viana Martins",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "17",
          "Nguyễn Đức Hoàng Minh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Đinh Xuân Tiến",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "22",
          "Nguyễn Hoàng Khanh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "34",
          "Doãn Ngọc Tân",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "86",
          "Nguyễn Hữu Nam",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "88",
          "Nguyễn Văn Tú",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "89",
          "Lê Quốc Nhật Nam",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "6",
          "Trần Danh Trung",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "9",
          "Lucas Ribamar Lopes dos Santos Bibiano",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "10",
          "Hernandes Rodrigues Da Silva",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "13",
          "Rimario Allando Gordon",
          "Jamaica",
          "Tiền đạo"
        ],
        [
          "23",
          "Nhâm Mạnh Dũng",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "95",
          "Brandao Goncalves Junior",
          "Brazil",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Thể Công Viettel",
        "TCVT"
      ]
    },
    "NDI": {
      "name": "Thép Xanh Nam Định",
      "league": "vl1",
      "logo": "assets/club-ndi.webp",
      "year": "1965",
      "stadium": "Thiên Trường",
      "roster": [
        [
          "23",
          "Lê Vũ Phong",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "26",
          "Trần Nguyên Mạnh",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "67",
          "Trịnh Xuân Hoàng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "4",
          "Đàm Tiến Dũng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Đặng Văn Tới",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "7",
          "Nguyễn Phong Hồng Duy",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "13",
          "Trần Văn Kiên",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "17",
          "Nguyễn Văn Vĩ",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "20",
          "Tyler James Thai Crawford",
          "Canada",
          "Hậu vệ"
        ],
        [
          "32",
          "Ngô Đức Huy",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "79",
          "Lê Văn Thành",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "93",
          "Felix Junior Gustave Eboa Eboa",
          "Cameroon",
          "Hậu vệ"
        ],
        [
          "98",
          "Giáp Tuấn Dương",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "A Mít",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "Ezequiel Santos Da Silva",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "10",
          "Caio César da Silva Silveira",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "11",
          "Nguyễn Tuấn Anh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Trần Văn Đạt",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "22",
          "Trần Mạnh Quỳnh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "28",
          "Tô Văn Vũ",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "34",
          "Nguyễn Công Sơn",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "39",
          "Lâm Ti Phông",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "72",
          "Romulo Da Silva Machado",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "77",
          "Van Alessandro Nguyen Skyriotis",
          "Áo",
          "Tiền vệ"
        ],
        [
          "88",
          "Lý Công Hoàng Anh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Nguyễn Xuân Son",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "27",
          "Trần Ngọc Sơn",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "90",
          "Phạm Tuấn Hải",
          "Việt Nam",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Nam Định",
        "TXND"
      ]
    },
    "HPH": {
      "name": "Hải Phòng FC",
      "league": "vl1",
      "logo": "assets/club-hph.webp",
      "year": "1952",
      "stadium": "Lạch Tray",
      "roster": [
        [
          "20",
          "Trần Đình Minh Hoàng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "30",
          "Nguyễn Văn Toản",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "32",
          "Phạm Thành Long",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Hứa Quốc Thắng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Đặng Tuấn Phong",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "28",
          "Huỳnh Tuấn Vũ",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "31",
          "Nguyễn Hữu Thái Bảo",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "35",
          "Vũ Quốc Anh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "39",
          "Nguyễn Vũ Tín",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "68",
          "Nguyễn Văn Minh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "97",
          "Esteban Orozco Fernández",
          "Tây Ban Nha",
          "Hậu vệ"
        ],
        [
          "7",
          "Hoàng Trọng Duy Khang",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "10",
          "Camilo Minh Vasconcelos",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "11",
          "Hồ Minh Dĩ",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Nguyễn Anh Tuấn",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "15",
          "Nguyễn Ngọc Tú",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "17",
          "Nguyễn Thái Học",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Lê Mạnh Dũng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "21",
          "Trần Gia Hưng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "27",
          "Hoàng Văn Tuyến",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "45",
          "Nguyễn Thành Đồng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "77",
          "Nguyễn Hữu Sơn",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "98",
          "Hoàng Thế Tài",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Milan Makaric",
          "Serbia",
          "Tiền đạo"
        ],
        [
          "36",
          "Nguyễn Công Phương",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "91",
          "Nguyễn Văn Anh",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "95",
          "Tagueu Tadjo Diederrick Joel",
          "Cameroon",
          "Tiền đạo"
        ],
        [
          "99",
          "Mpande Joseph Mbolimbo",
          "Uganda",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Hải Phòng"
      ]
    },
    "THA": {
      "name": "Thanh Hóa FC",
      "league": "vl1",
      "logo": "assets/club-tha.webp",
      "year": "1962",
      "stadium": "Thanh Hóa",
      "roster": [
        [
          "23",
          "Vũ Tuyên Quang",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Nguyễn Thanh Diệp",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "30",
          "Hồ Tùng Hân",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "93",
          "Lê Anh Tuấn",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "5",
          "Lục Xuân Hưng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "12",
          "Nguyễn Văn Dũng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "14",
          "Trương Thanh Nam",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "15",
          "Trịnh Văn Lợi",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "16",
          "Nguyễn Đình Huyên",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "20",
          "Lại Văn Tú",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "28",
          "Hà Văn Kiệt",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "2",
          "Nguyễn Hữu Dũng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "7",
          "Nguyễn Bá Tiến",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "Ngô Đức Hoàng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "10",
          "Lê Văn Thắng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "11",
          "Nguyễn Ngọc Tĩnh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Lê Bá Nam",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "21",
          "Trần Ngọc Quý",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "22",
          "Damoth ThongKhamsavath",
          "Lào",
          "Tiền vệ"
        ],
        [
          "26",
          "Hà Minh Đức",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "29",
          "Đoàn Ngọc Hà",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "35",
          "Di Mateo Lovric",
          "Croatia",
          "Tiền vệ"
        ],
        [
          "39",
          "Đoàn Tuấn Cảnh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "58",
          "Trương Đức Mạnh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "77",
          "Abdurakhmanov Odilzhon Alisherovich",
          "Uzbekistan",
          "Tiền vệ"
        ],
        [
          "89",
          "Nguyễn Trọng Phú",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "90",
          "Nguyễn Đức Tùng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Saliou Guindo",
          "Mali",
          "Tiền đạo"
        ],
        [
          "17",
          "Nguyễn Văn Tùng",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "75",
          "Lê Văn Hoàn",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "98",
          "Matheus Monteiro Martins",
          "Brazil",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Thanh Hóa",
        "Đông Á Thanh Hoá"
      ]
    },
    "SLN": {
      "name": "Sông Lam Nghệ An",
      "league": "vl1",
      "logo": "assets/club-sln.webp",
      "year": "1979",
      "stadium": "Vinh",
      "roster": [
        [
          "1",
          "Cao Văn Bình",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Nguyễn Bảo Ngọc",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "28",
          "Trần Văn Đạt",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Cittadini Roberto",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "3",
          "Nguyễn Mai Hoàng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Phan Văn Thành",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "7",
          "Hồ Văn Cường",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "12",
          "Bùi Thanh Đức",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "15",
          "Lê Nguyên Hoàng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "19",
          "Phan Bá Quyền",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "22",
          "Ngô Văn Bắc",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "23",
          "Hoàng Minh Hợi",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "24",
          "Trịnh Hoàng Cảnh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "33",
          "Jairo Rodrigues Peixoto Filho",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "55",
          "Hoàng Văn Khánh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Onoja Joseph",
          "Nigeria",
          "Tiền vệ"
        ],
        [
          "8",
          "Nguyễn Xuân Bình",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "10",
          "Karim Tran Phi Long",
          "Pháp",
          "Tiền vệ"
        ],
        [
          "16",
          "Nguyễn Quang Vinh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "20",
          "Lê Văn Quý",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "27",
          "Đặng Văn Lắm",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "29",
          "Đặng Quang Tú",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "32",
          "Hồ Khắc Ngọc",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "77",
          "Luiz Guilherme Vieira Da Silva",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "87",
          "Abdel-Amine Tran Duc Vinh",
          "Pháp",
          "Tiền vệ"
        ],
        [
          "18",
          "Lê Đình Long Vũ",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "21",
          "Phan Xuân Đại",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "83",
          "Bruno Pereira De Albuquerque",
          "Brazil",
          "Tiền đạo"
        ]
      ]
    },
    "HAG": {
      "name": "Hoàng Anh Gia Lai",
      "league": "vl1",
      "logo": "assets/club-hag.webp",
      "year": 1976,
      "stadium": "Pleiku",
      "roster": [
        [
          "1",
          "Huỳnh Trần Bảo Duy",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Trần Trung Kiên",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "39",
          "Nguyễn Thành Lợi",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "69",
          "Nguyễn Vũ Khang",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "3",
          "Hà Châu Phi",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "4",
          "Nguyễn Quốc Quang Huy",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Basilo Da Silva Julio Cesar",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "7",
          "Nguyễn Thanh Nhân",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "15",
          "Nguyễn Văn Triệu",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "21",
          "Nguyễn Chí Hướng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "28",
          "Nguyễn Hữu Anh Tài",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "33",
          "Robson Alves Reis",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "38",
          "Võ Phước Bảo",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "86",
          "Dụng Quang Vinh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Trần Thanh Sơn",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "Võ Đình Lâm",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "18",
          "Phan Trí Dũng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Nguyễn Duy Tâm",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "20",
          "Cao Hoàng Minh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "22",
          "Nay Di Đan",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "23",
          "Hoàng Vĩnh Nguyên",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "26",
          "Môi Sê",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "27",
          "Phan Nhật Thanh Long",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Jacintho Ferreira Matheus Lucas",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "10",
          "Luann Augusto Xavier Boy",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "12",
          "Nguyễn Minh Tâm",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "16",
          "Trần Gia Bảo",
          "Việt Nam",
          "Tiền đạo"
        ]
      ]
    },
    "HLH": {
      "name": "Hồng Lĩnh Hà Tĩnh",
      "league": "vl1",
      "logo": "assets/club-hlh.webp",
      "year": "2019",
      "stadium": "Hà Tĩnh",
      "roster": [
        [
          "1",
          "Nguyễn Thanh Tùng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Trần Văn Tiến",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "30",
          "Nguyễn Hữu Hậu",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Vương Văn Huy",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "3",
          "Thái Bá Sang",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "4",
          "Lê Quang Trường",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Vũ Viết Triều",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Helerson Mateus Do Nascimento",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "7",
          "Bùi Duy Thường",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "21",
          "Nguyễn Văn Huy",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "22",
          "Thoan Jacob Ian Mai",
          "Mỹ",
          "Hậu vệ"
        ],
        [
          "38",
          "Võ Quốc Dân",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "8",
          "Nguyễn Trọng Hoàng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "11",
          "Nguyễn Văn Hiệp",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "16",
          "Phạm Văn Long",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "17",
          "Trần Văn Bửu",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "20",
          "Huỳnh Tiến Đạt",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "24",
          "Nguyễn Hoàng Trung Nguyên",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "26",
          "Bùi Văn Đức",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "33",
          "Moreau Nguyen Ranhi Van Tam",
          "Pháp",
          "Tiền vệ"
        ],
        [
          "39",
          "Huỳnh Tấn Tài",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "87",
          "Nguyễn Văn Khánh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "88",
          "Luiz Antonio De Souza Soares",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "9",
          "Daniel Floro Da Silva",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "18",
          "Vũ Quang Nam",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "19",
          "Ngô Văn Lương",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "90",
          "Atshimene Charles",
          "Nigeria",
          "Tiền đạo"
        ]
      ]
    },
    "DNA": {
      "name": "SHB Đà Nẵng",
      "league": "vl1",
      "logo": "assets/club-dna.webp",
      "year": "1976",
      "stadium": "Chi Lăng",
      "roster": [
        [
          "33",
          "Đỗ Sỹ Huy",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "34",
          "Nguyễn Tiến Mạnh",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "91",
          "Bùi Tiến Dũng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Trần Ngọc Hiệp",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "3",
          "Matias Fracchia Moreira",
          "Uruguay",
          "Hậu vệ"
        ],
        [
          "8",
          "Quế Ngọc Hải",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "14",
          "Trần Văn Hòa",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "17",
          "Võ Hữu Việt Hoàng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "20",
          "Lương Duy Cương",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "23",
          "Nguyễn Hồng Phúc",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "37",
          "Vũ Văn Sơn",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "79",
          "Mai Sỹ Hoàng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "81",
          "Nguyễn Duy Thắng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Yvo Nahuel Calleros Rebori",
          "Uruguay",
          "Tiền vệ"
        ],
        [
          "16",
          "Phạm Văn Hữu",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Joel Brandon Lopez Pissano",
          "Argentina",
          "Tiền vệ"
        ],
        [
          "22",
          "Lê Vũ Quốc Nhật",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "26",
          "Võ Huy Toàn",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "27",
          "Bryan Ly",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "32",
          "Lê Văn Quang Duyệt",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "58",
          "Võ Văn Toàn",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "72",
          "Nguyễn Trung Nguyên",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Ivan Saponjic",
          "Serbia",
          "Tiền đạo"
        ],
        [
          "10",
          "Kalvin Luong",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "11",
          "Phan Văn Long",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "18",
          "Phạm Đình Duy",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "28",
          "Võ Nguyên Hoàng",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "36",
          "Nguyễn Minh Quang",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "67",
          "Ngô Hồng Phước",
          "Việt Nam",
          "Tiền đạo"
        ]
      ]
    },
    "HCM": {
      "name": "Công An TP.HCM",
      "league": "vl1",
      "logo": "assets/club-hcm.webp",
      "year": "1979",
      "stadium": "Thống Nhất / Gò Đậu",
      "roster": [
        [
          "32",
          "Phan Văn Biểu",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "56",
          "Hoa Xuân Tín",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "89",
          "Lê Giang Patrik",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Lenn-Minh Tran",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "4",
          "Dirk Abels",
          "Hà Lan",
          "Hậu vệ"
        ],
        [
          "5",
          "Đinh Quang Kiệt",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "13",
          "Khổng Minh Gia Bảo",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "16",
          "Nguyễn Hoàng Minh Nhật",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "17",
          "Võ Minh Trọng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "27",
          "Nguyễn Nhật Minh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "28",
          "Trần Hoàng Phúc",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "34",
          "Lê Quang Hùng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Đặng Văn Trâm",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "Juanjo Narváez",
          "Tây Ban Nha",
          "Tiền vệ"
        ],
        [
          "10",
          "Aldaír Ferreira",
          "Bồ Đào Nha",
          "Tiền vệ"
        ],
        [
          "11",
          "Nguyễn Phi Hoàng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "12",
          "Léo Gomes",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "19",
          "Nguyễn Thái Quốc Cường",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "21",
          "Đào Quốc Gia",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "39",
          "Nguyễn Đức Phú",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "58",
          "Arthur Yamga",
          "Cameroon",
          "Tiền vệ"
        ],
        [
          "7",
          "Olaha Mạnh Đức",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "9",
          "Jason Cummings",
          "Scotland",
          "Tiền đạo"
        ],
        [
          "20",
          "Phan Văn Đức",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "22",
          "Nguyễn Tiến Linh",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "26",
          "Ngô Đăng Khoa",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "33",
          "Williams Minh Hoàng",
          "Việt Nam",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Công an TP. Hồ Chí Minh",
        "Công an TP HCM",
        "Công an TPHCM"
      ]
    },
    "NBI": {
      "name": "Ninh Bình FC",
      "league": "vl1",
      "logo": "assets/club-nbi.webp",
      "year": "2015",
      "stadium": "Ninh Bình",
      "roster": [
        [
          "1",
          "Đặng Văn Lâm",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Quàng Thế Tài",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "88",
          "Nguyễn Minh Đức",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "4",
          "Hồ Tấn Tài",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Đỗ Thanh Thịnh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "17",
          "Lê Ngọc Bảo",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "26",
          "Lê Hải Đức",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "33",
          "Nguyễn Quốc Khánh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "86",
          "Dụng Quang Nho",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "96",
          "Lucas Henrique Turci",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "2",
          "Hoàng Thái Bình",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "7",
          "Nguyễn Đức Chiến",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "Trần Thành Trung",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "11",
          "Lê Văn Thuận",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Nguyễn Đức Việt",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "28",
          "Nguyễn Hoàng Đức",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "41",
          "Đỗ Văn Thuận",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "55",
          "Martins De Resende Romeu",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "66",
          "Trương Tiến Anh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "94",
          "Nguyễn Tài Lộc",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "5",
          "Imoh Fred Friday",
          "Nigeria",
          "Tiền đạo"
        ],
        [
          "9",
          "Goncalves Silva Lucas Vinicius",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "15",
          "Trần Bảo Toàn",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "16",
          "Nguyễn Lê Phát",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "18",
          "Phạm Gia Hưng",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "99",
          "Nguyễn Quốc Việt",
          "Việt Nam",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Ninh Bình"
      ]
    },
    "BNI": {
      "name": "Bắc Ninh FC",
      "league": "vl1",
      "logo": "assets/club-bni.webp",
      "year": "2024",
      "stadium": "Việt Yên",
      "roster": [
        [
          "1",
          "Nguyễn Văn Công",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Đoàn Huy Hoàng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "37",
          "Lê Văn Hùng",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Đinh Văn Trường",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "3",
          "Nguyễn Ngọc Thắng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "15",
          "Nguyễn Văn Việt",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "16",
          "Nguyễn Văn Đạt",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "21",
          "Phan Thế Hưng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "27",
          "Lê Thắng Long",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "43",
          "Nguyễn Trọng Kiệt",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "45",
          "Lê Văn Xuân",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "86",
          "Vũ Tiến Long",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "99",
          "Rafael Santos",
          "Brazil",
          "Hậu vệ"
        ],
        [
          "5",
          "Vũ Hồng Quân",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "8",
          "Vitão",
          "Brazil",
          "Tiền vệ"
        ],
        [
          "11",
          "Lê Tiến Anh",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Nguyễn Hải Huy",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "18",
          "Mai Xuân Quyết",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Reece Gaylor",
          "Anh",
          "Tiền vệ"
        ],
        [
          "30",
          "Lương Hoàng Nam",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "31",
          "Nguyễn Chính Đăng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "36",
          "Nguyễn Minh Tùng",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "68",
          "Trần Văn Trung",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "80",
          "Pierre Lamothe",
          "Pháp",
          "Tiền vệ"
        ],
        [
          "88",
          "Phạm Văn Thành",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Brenner",
          "Brazil",
          "Tiền đạo"
        ],
        [
          "10",
          "David Fisher",
          "Nigeria",
          "Tiền đạo"
        ],
        [
          "28",
          "Trần Văn Thành",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "29",
          "Ngân Văn Đại",
          "Việt Nam",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "Bắc Ninh"
      ]
    },
    "DNC": {
      "name": "Thành phố Đồng Nai",
      "league": "vl1",
      "logo": "assets/club-dnc.webp",
      "year": "2006",
      "stadium": "Bình Phước",
      "roster": [
        [
          "1",
          "Bùi Tấn Trường",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "17",
          "Phạm Văn Phong",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "25",
          "Phạm Hữu Nghĩa",
          "Việt Nam",
          "Thủ môn"
        ],
        [
          "2",
          "Dương Văn Khoa",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "3",
          "Huỳnh Tấn Sinh",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "5",
          "Nguyễn Thành Lộc",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "13",
          "Nguyễn Thanh Thảo",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "15",
          "Nguyễn Hữu Tuấn",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "16",
          "Lê Văn Sơn",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "18",
          "Nguyễn Văn Đức",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "22",
          "Jovic Filip",
          "Serbia",
          "Hậu vệ"
        ],
        [
          "23",
          "Trần Trọng Hiếu",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "68",
          "Bùi Tiến Dụng",
          "Việt Nam",
          "Hậu vệ"
        ],
        [
          "6",
          "Lương Xuân Trường",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "7",
          "Vulic Milos",
          "Serbia",
          "Tiền vệ"
        ],
        [
          "12",
          "Uông Ngọc Tiến",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "14",
          "Nguyễn Quốc Lộc",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "19",
          "Lương Thanh Ngọc Lâm",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "20",
          "Lưu Tự Nhân",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "21",
          "Chu Văn Kiên",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "24",
          "Phan Văn Hiếu",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "27",
          "Đoàn Hải Quân",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "30",
          "Nguyễn Đức Cường",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "77",
          "Sầm Ngọc Đức",
          "Việt Nam",
          "Tiền vệ"
        ],
        [
          "9",
          "Ivan Virgil Adrei",
          "Romania",
          "Tiền đạo"
        ],
        [
          "10",
          "Nguyễn Công Phượng",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "11",
          "Majdevac Andrija",
          "Serbia",
          "Tiền đạo"
        ],
        [
          "66",
          "Hồ Tuấn Tài",
          "Việt Nam",
          "Tiền đạo"
        ],
        [
          "91",
          "Lê Thanh Bình",
          "Việt Nam",
          "Tiền đạo"
        ]
      ],
      "aliases": [
        "TP Đồng Nai",
        "TP. Đồng Nai",
        "Đồng Nai"
      ]
    },
    "BEC": {
      "name": "Becamex TP. Hồ Chí Minh",
      "league": "vl2",
      "logo": "assets/club-bec.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Becamex TP.HCM",
        "Becamex HCMC",
        "BHCMC",
        "Becammex TP. Hồ Chí Minh"
      ]
    },
    "HYE": {
      "name": "Hưng Yên",
      "league": "vl2",
      "logo": "assets/club-hye.png",
      "year": null,
      "stadium": null,
      "roster": []
    },
    "TNG": {
      "name": "Thái Nguyên",
      "league": "vl2",
      "logo": "assets/club-tng.png",
      "year": null,
      "stadium": null,
      "roster": []
    },
    "TPH": {
      "name": "TP. Hồ Chí Minh",
      "league": "vl2",
      "logo": "assets/club-tph.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "TP. HCM",
        "Ho Chi Minh City",
        "HCMC"
      ]
    },
    "BMS": {
      "name": "Bình Minh Sài Gòn",
      "league": "vl2",
      "logo": "assets/club-bms.png",
      "year": 2026,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Aurora Saigon United",
        "ASU",
        "Bình Minh Sài Gòn United"
      ]
    },
    "CND": {
      "name": "Công An Nhân Dân",
      "league": "vl2",
      "logo": "assets/club-cnd.png",
      "year": 2023,
      "stadium": null,
      "roster": [],
      "aliases": [
        "PVF-CAND",
        "PVF Công An Nhân Dân",
        "CAND"
      ]
    },
    "KKH": {
      "name": "Khatoco Khánh Hòa",
      "league": "vl2",
      "logo": "assets/club-kkh.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Khánh Hòa"
      ]
    },
    "VHI": {
      "name": "Đại Học Văn Hiến",
      "league": "vl2",
      "logo": "assets/club-vhi.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Van Hien",
        "Đại học Văn Hiến",
        "VHU"
      ]
    },
    "QNU": {
      "name": "Quy Nhơn United",
      "league": "vl2",
      "logo": "assets/club-qnu.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Quy Nhơn"
      ]
    },
    "TCT": {
      "name": "Thép Cần Thơ",
      "league": "vl2",
      "logo": "assets/club-tct.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Cần Thơ",
        "CFC"
      ]
    },
    "XPT": {
      "name": "Xuân Thiện Phú Thọ",
      "league": "vl2",
      "logo": "assets/club-xpt.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "Phú Thọ"
      ]
    },
    "HUE": {
      "name": "Huế",
      "league": "vl2",
      "logo": "assets/club-hue.png",
      "year": null,
      "stadium": null,
      "roster": []
    },
    "LAN": {
      "name": "Long An",
      "league": "vl2",
      "logo": "assets/club-lan.png",
      "year": null,
      "stadium": null,
      "roster": []
    },
    "LDO": {
      "name": "Lâm Đồng",
      "league": "vl2",
      "logo": "assets/club-ldo.png",
      "year": null,
      "stadium": null,
      "roster": [],
      "aliases": [
        "LĐFC"
      ]
    }
  },
  "matches": {
    "vl1-1-DNC-TCV": {
      "id": "vl1-1-DNC-TCV",
      "league": "vl1",
      "round": 1,
      "home": "DNC",
      "away": "TCV",
      "score": [
        0,
        2
      ],
      "source": "vl1r1",
      "date": "2026-09-04",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "1",
      "venue": "Bình Phước",
      "broadcast": "FPT Play, HTV Thể thao",
      "attendance": 10000,
      "yellow": [
        0,
        3
      ],
      "red": [
        1,
        1
      ],
      "status": "final"
    },
    "vl1-1-HCM-HNO": {
      "id": "vl1-1-HCM-HNO",
      "league": "vl1",
      "round": 1,
      "home": "HCM",
      "away": "HNO",
      "score": [
        3,
        1
      ],
      "source": "vl1r1",
      "date": "2026-09-05",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "2",
      "venue": "Bình Dương",
      "broadcast": "FPT Play, HTV Thể thao",
      "attendance": 5000,
      "yellow": [
        2,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-1-HPH-NBI": {
      "id": "vl1-1-HPH-NBI",
      "league": "vl1",
      "round": 1,
      "home": "HPH",
      "away": "NBI",
      "score": [
        1,
        4
      ],
      "source": "vl1r1",
      "date": "2026-09-05",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "3",
      "venue": "Lạch Tray",
      "broadcast": "FPT Play",
      "attendance": 8000,
      "yellow": [
        0,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-1-CAH-HLH": {
      "id": "vl1-1-CAH-HLH",
      "league": "vl1",
      "round": 1,
      "home": "CAH",
      "away": "HLH",
      "score": [
        2,
        0
      ],
      "source": "vl1r1",
      "date": "2026-09-05",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "4",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, VTV6",
      "attendance": 9000,
      "yellow": [
        2,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-1-THA-DNA": {
      "id": "vl1-1-THA-DNA",
      "league": "vl1",
      "round": 1,
      "home": "THA",
      "away": "DNA",
      "score": [
        3,
        2
      ],
      "source": "vl1r1",
      "date": "2026-09-06",
      "time": "17:00",
      "timingSource": "vl1cal",
      "number": "5",
      "venue": "Thanh Hóa",
      "broadcast": "FPT Play",
      "attendance": 9000,
      "yellow": [
        1,
        4
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-1-NDI-HAG": {
      "id": "vl1-1-NDI-HAG",
      "league": "vl1",
      "round": 1,
      "home": "NDI",
      "away": "HAG",
      "score": [
        4,
        0
      ],
      "source": "vl1r1",
      "date": "2026-09-06",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "6",
      "venue": "Thiên Trường",
      "broadcast": "FPT Play",
      "attendance": 11000,
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-1-SLN-BNI": {
      "id": "vl1-1-SLN-BNI",
      "league": "vl1",
      "round": 1,
      "home": "SLN",
      "away": "BNI",
      "score": [
        1,
        0
      ],
      "source": "vl1r1",
      "date": "2026-09-06",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "7",
      "venue": "Vinh",
      "broadcast": "FPT Play",
      "attendance": 12000,
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-2-TCV-CAH": {
      "id": "vl1-2-TCV-CAH",
      "league": "vl1",
      "round": 2,
      "home": "TCV",
      "away": "CAH",
      "score": [
        0,
        1
      ],
      "source": "vl1r2",
      "date": "2026-09-10",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "8",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, HTV Thể thao, VTV6, MyTV, TV360",
      "attendance": 8000,
      "yellow": [
        2,
        3
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-2-NBI-THA": {
      "id": "vl1-2-NBI-THA",
      "league": "vl1",
      "round": 2,
      "home": "NBI",
      "away": "THA",
      "score": [
        2,
        1
      ],
      "source": "vl1r2",
      "date": "2026-09-11",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "9",
      "venue": "Ninh Bình",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 8000,
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-2-BNI-HCM": {
      "id": "vl1-2-BNI-HCM",
      "league": "vl1",
      "round": 2,
      "home": "BNI",
      "away": "HCM",
      "score": [
        1,
        0
      ],
      "source": "vl1r2",
      "date": "2026-09-11",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "10",
      "venue": "Việt Yên",
      "broadcast": "FPT Play, HTV 3, MyTV, TV360",
      "attendance": 10000,
      "yellow": [
        3,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-2-DNA-NDI": {
      "id": "vl1-2-DNA-NDI",
      "league": "vl1",
      "round": 2,
      "home": "DNA",
      "away": "NDI",
      "score": [
        3,
        0
      ],
      "source": "vl1r2",
      "date": "2026-09-11",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "11",
      "venue": "Chi Lăng",
      "broadcast": "FPT Play, TV360",
      "attendance": 7000,
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        2
      ],
      "status": "final"
    },
    "vl1-2-HNO-SLN": {
      "id": "vl1-2-HNO-SLN",
      "league": "vl1",
      "round": 2,
      "home": "HNO",
      "away": "SLN",
      "score": [
        1,
        4
      ],
      "source": "vl1r2",
      "date": "2026-09-12",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "12",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, TV360",
      "attendance": 8500,
      "yellow": [
        1,
        4
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-2-HAG-HPH": {
      "id": "vl1-2-HAG-HPH",
      "league": "vl1",
      "round": 2,
      "home": "HAG",
      "away": "HPH",
      "score": [
        1,
        3
      ],
      "source": "vl1r2",
      "date": "2026-09-13",
      "time": "17:00",
      "timingSource": "vl1cal",
      "number": "13",
      "venue": "Pleiku",
      "broadcast": "FPT Play, TV360",
      "attendance": 5000,
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-2-HLH-DNC": {
      "id": "vl1-2-HLH-DNC",
      "league": "vl1",
      "round": 2,
      "home": "HLH",
      "away": "DNC",
      "score": [
        1,
        0
      ],
      "source": "vl1r2",
      "date": "2026-09-13",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "14",
      "venue": "Hà Tĩnh",
      "broadcast": "FPT Play, TV360",
      "attendance": 2000,
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-3-DNC-CAH": {
      "id": "vl1-3-DNC-CAH",
      "league": "vl1",
      "round": 3,
      "home": "DNC",
      "away": "CAH",
      "score": [
        0,
        3
      ],
      "source": "vl1r3",
      "date": "2026-09-20",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Bình Phước",
      "broadcast": "FPT Play, TV360",
      "attendance": 10000,
      "yellow": [
        1,
        1
      ],
      "red": [
        1,
        0
      ],
      "status": "final"
    },
    "vl1-3-TCV-HLH": {
      "id": "vl1-3-TCV-HLH",
      "league": "vl1",
      "round": 3,
      "home": "TCV",
      "away": "HLH",
      "score": [
        1,
        3
      ],
      "source": "vl1r3",
      "date": "2026-10-08",
      "time": "19:15",
      "timingSource": "vl1cal",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, TV360",
      "attendance": 2500,
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-3-HAG-DNA": {
      "id": "vl1-3-HAG-DNA",
      "league": "vl1",
      "round": 3,
      "home": "HAG",
      "away": "DNA",
      "score": [
        3,
        0
      ],
      "source": "vl1r3",
      "date": "2026-10-10",
      "time": "17:00",
      "timingSource": "vl1cal",
      "venue": "Quy Nhơn",
      "broadcast": "FPT Play, TV360",
      "attendance": 2000,
      "yellow": [
        3,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-3-NDI-NBI": {
      "id": "vl1-3-NDI-NBI",
      "league": "vl1",
      "round": 3,
      "home": "NDI",
      "away": "NBI",
      "score": [
        1,
        1
      ],
      "source": "vl1r3",
      "date": "2026-10-10",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Thiên Trường",
      "broadcast": "FPT Play, HTV Thể thao, MyTV, TV360",
      "attendance": 7000,
      "yellow": [
        2,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-3-HPH-THA": {
      "id": "vl1-3-HPH-THA",
      "league": "vl1",
      "round": 3,
      "home": "HPH",
      "away": "THA",
      "score": [
        1,
        2
      ],
      "source": "vl1r3",
      "date": "2026-10-10",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Lạch Tray",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 4000,
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-3-SLN-HCM": {
      "id": "vl1-3-SLN-HCM",
      "league": "vl1",
      "round": 3,
      "home": "SLN",
      "away": "HCM",
      "score": [
        1,
        1
      ],
      "source": "vl1r3",
      "date": "2026-10-11",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "20",
      "venue": "Vinh",
      "broadcast": "FPT Play, HTV Thể thao, MyTV, TV360",
      "attendance": 11000,
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-3-HNO-BNI": {
      "id": "vl1-3-HNO-BNI",
      "league": "vl1",
      "round": 3,
      "home": "HNO",
      "away": "BNI",
      "score": [
        1,
        0
      ],
      "source": "vl1r3",
      "date": "2026-10-11",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "21",
      "venue": "Mỹ Đình",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 7000,
      "yellow": [
        3,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-4-THA-NDI": {
      "id": "vl1-4-THA-NDI",
      "league": "vl1",
      "round": 4,
      "home": "THA",
      "away": "NDI",
      "score": [
        0,
        2
      ],
      "source": "vl1r4",
      "date": "2026-10-17",
      "time": "17:00",
      "timingSource": "vl1cal",
      "venue": "Thanh Hóa",
      "broadcast": "FPT Play, TV360",
      "attendance": 6000,
      "yellow": [
        2,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-4-DNA-HPH": {
      "id": "vl1-4-DNA-HPH",
      "league": "vl1",
      "round": 4,
      "home": "DNA",
      "away": "HPH",
      "score": [
        1,
        5
      ],
      "source": "vl1r4",
      "date": "2026-10-17",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Chi Lăng",
      "broadcast": "FPT Play, HTV Thể thao, MyTV, TV360",
      "attendance": 4000,
      "yellow": [
        2,
        0
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-4-HLH-SLN": {
      "id": "vl1-4-HLH-SLN",
      "league": "vl1",
      "round": 4,
      "home": "HLH",
      "away": "SLN",
      "score": [
        2,
        2
      ],
      "source": "vl1r4",
      "date": "2026-10-17",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Hà Tĩnh",
      "broadcast": "FPT Play, TV360",
      "attendance": 6500,
      "yellow": [
        0,
        0
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-4-NBI-HAG": {
      "id": "vl1-4-NBI-HAG",
      "league": "vl1",
      "round": 4,
      "home": "NBI",
      "away": "HAG",
      "score": [
        4,
        3
      ],
      "source": "vl1r4",
      "date": "2026-10-18",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "25",
      "venue": "Ninh Bình",
      "broadcast": "FPT Play, TV360",
      "attendance": 8100,
      "yellow": [
        2,
        3
      ],
      "red": [
        1,
        1
      ],
      "status": "final"
    },
    "vl1-4-BNI-DNC": {
      "id": "vl1-4-BNI-DNC",
      "league": "vl1",
      "round": 4,
      "home": "BNI",
      "away": "DNC",
      "score": [
        0,
        0
      ],
      "source": "vl1r4",
      "date": "2026-10-18",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "26",
      "venue": "Việt Yên",
      "broadcast": "FPT Play, TV360",
      "attendance": 10000,
      "yellow": [
        4,
        5
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-4-CAH-HNO": {
      "id": "vl1-4-CAH-HNO",
      "league": "vl1",
      "round": 4,
      "home": "CAH",
      "away": "HNO",
      "score": [
        1,
        2
      ],
      "source": "vl1r4",
      "date": "2026-10-18",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "27",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 12000,
      "yellow": [
        1,
        4
      ],
      "red": [
        1,
        0
      ],
      "status": "final"
    },
    "vl1-4-HCM-TCV": {
      "id": "vl1-4-HCM-TCV",
      "league": "vl1",
      "round": 4,
      "home": "HCM",
      "away": "TCV",
      "score": [
        1,
        0
      ],
      "source": "vl1r4",
      "date": "2026-10-19",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "28",
      "venue": "Bình Dương",
      "broadcast": "FPT Play, VTV6, HTV Thể thao, MyTV, TV360",
      "attendance": 4000,
      "yellow": [
        1,
        2
      ],
      "red": [
        1,
        0
      ],
      "status": "final"
    },
    "vl1-5-CAH-THA": {
      "id": "vl1-5-CAH-THA",
      "league": "vl1",
      "round": 5,
      "home": "CAH",
      "away": "THA",
      "score": [
        1,
        1
      ],
      "source": "vl1r5",
      "date": "2026-10-22",
      "time": "19:15",
      "timingSource": "vl1cal",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 6000,
      "yellow": [
        0,
        0
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-5-HAG-SLN": {
      "id": "vl1-5-HAG-SLN",
      "league": "vl1",
      "round": 5,
      "home": "HAG",
      "away": "SLN",
      "score": [
        0,
        2
      ],
      "source": "vl1r5",
      "date": "2026-10-23",
      "time": "17:00",
      "timingSource": "vl1cal",
      "venue": "Pleiku",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 4000,
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-5-TCV-BNI": {
      "id": "vl1-5-TCV-BNI",
      "league": "vl1",
      "round": 5,
      "home": "TCV",
      "away": "BNI",
      "score": [
        2,
        2
      ],
      "source": "vl1r5",
      "date": "2026-10-23",
      "time": "19:15",
      "timingSource": "vl1cal",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, HTV 4, MyTV, TV360",
      "attendance": 7000,
      "yellow": [
        1,
        5
      ],
      "red": [
        0,
        3
      ],
      "status": "final"
    },
    "vl1-5-DNC-NDI": {
      "id": "vl1-5-DNC-NDI",
      "league": "vl1",
      "round": 5,
      "home": "DNC",
      "away": "NDI",
      "score": [
        0,
        4
      ],
      "source": "vl1r5",
      "date": "2026-10-24",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "32",
      "venue": "Bình Phước",
      "broadcast": "FPT Play, TV360",
      "attendance": 7000,
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-5-HLH-HPH": {
      "id": "vl1-5-HLH-HPH",
      "league": "vl1",
      "round": 5,
      "home": "HLH",
      "away": "HPH",
      "score": [
        2,
        1
      ],
      "source": "vl1r5",
      "date": "2026-10-24",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "33",
      "venue": "Hà Tĩnh",
      "broadcast": "FPT Play, TV360",
      "attendance": 3000,
      "yellow": [
        1,
        0
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-5-DNA-HNO": {
      "id": "vl1-5-DNA-HNO",
      "league": "vl1",
      "round": 5,
      "home": "DNA",
      "away": "HNO",
      "score": [
        1,
        0
      ],
      "source": "vl1r5",
      "date": "2026-10-25",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "34",
      "venue": "Chi Lăng",
      "broadcast": "FPT Play, HTV 4, MyTV, TV360",
      "attendance": 7000,
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-5-NBI-HCM": {
      "id": "vl1-5-NBI-HCM",
      "league": "vl1",
      "round": 5,
      "home": "NBI",
      "away": "HCM",
      "score": [
        0,
        1
      ],
      "source": "vl1r5",
      "date": "2026-10-25",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "35",
      "venue": "Ninh Bình",
      "broadcast": "FPT Play, TV360",
      "attendance": 9000,
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-6-THA-HLH": {
      "id": "vl1-6-THA-HLH",
      "league": "vl1",
      "round": 6,
      "home": "THA",
      "away": "HLH",
      "score": [
        1,
        1
      ],
      "source": "vl1r6",
      "date": "2026-10-30",
      "time": "17:00",
      "timingSource": "vl1cal",
      "venue": "Thanh Hóa",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 3000,
      "yellow": [
        3,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-6-BNI-HAG": {
      "id": "vl1-6-BNI-HAG",
      "league": "vl1",
      "round": 6,
      "home": "BNI",
      "away": "HAG",
      "score": [
        1,
        0
      ],
      "source": "vl1r6",
      "date": "2026-10-30",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Việt Yên",
      "broadcast": "FPT Play, TV360",
      "attendance": 9000,
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-6-HNO-NBI": {
      "id": "vl1-6-HNO-NBI",
      "league": "vl1",
      "round": 6,
      "home": "HNO",
      "away": "NBI",
      "score": [
        2,
        1
      ],
      "source": "vl1r6",
      "date": "2026-10-30",
      "time": "19:15",
      "timingSource": "vl1cal",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, TV360",
      "attendance": 9000,
      "yellow": [
        1,
        0
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-6-HPH-DNC": {
      "id": "vl1-6-HPH-DNC",
      "league": "vl1",
      "round": 6,
      "home": "HPH",
      "away": "DNC",
      "score": [
        1,
        0
      ],
      "source": "vl1r6",
      "date": "2026-10-31",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Lạch Tray",
      "broadcast": "FPT Play, TV360",
      "attendance": 4500,
      "yellow": [
        2,
        6
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-6-SLN-CAH": {
      "id": "vl1-6-SLN-CAH",
      "league": "vl1",
      "round": 6,
      "home": "SLN",
      "away": "CAH",
      "score": [
        1,
        1
      ],
      "source": "vl1r6",
      "date": "2026-10-31",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Vinh",
      "broadcast": "FPT Play, HTV Thể thao, MyTV, TV360",
      "attendance": 14000,
      "yellow": [
        1,
        2
      ],
      "red": [
        1,
        1
      ],
      "status": "final"
    },
    "vl1-6-NDI-TCV": {
      "id": "vl1-6-NDI-TCV",
      "league": "vl1",
      "round": 6,
      "home": "NDI",
      "away": "TCV",
      "score": [
        3,
        1
      ],
      "source": "vl1r6",
      "date": "2026-10-31",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Thiên Trường",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 12000,
      "yellow": [
        2,
        4
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-6-HCM-DNA": {
      "id": "vl1-6-HCM-DNA",
      "league": "vl1",
      "round": 6,
      "home": "HCM",
      "away": "DNA",
      "score": [
        0,
        1
      ],
      "source": "vl1r6",
      "date": "2026-11-01",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "41",
      "venue": "Bình Dương",
      "broadcast": "FPT Play, HTV Thể thao, MyTV, TV360",
      "attendance": 8500,
      "yellow": [
        3,
        5
      ],
      "red": [
        1,
        0
      ],
      "status": "final"
    },
    "vl1-7-DNC-DNA": {
      "id": "vl1-7-DNC-DNA",
      "league": "vl1",
      "round": 7,
      "home": "DNC",
      "away": "DNA",
      "score": [
        1,
        0
      ],
      "source": "vl1r7",
      "date": "2026-11-06",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Bình Phước",
      "broadcast": "FPT Play, TV360",
      "attendance": 4500,
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-7-HLH-NDI": {
      "id": "vl1-7-HLH-NDI",
      "league": "vl1",
      "round": 7,
      "home": "HLH",
      "away": "NDI",
      "score": [
        1,
        2
      ],
      "source": "vl1r7",
      "date": "2026-11-06",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Hà Tĩnh",
      "broadcast": "FPT Play, TV360",
      "attendance": 6500,
      "yellow": [
        3,
        1
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-7-HAG-HNO": {
      "id": "vl1-7-HAG-HNO",
      "league": "vl1",
      "round": 7,
      "home": "HAG",
      "away": "HNO",
      "score": [
        2,
        1
      ],
      "source": "vl1r7",
      "date": "2026-11-07",
      "time": "17:00",
      "timingSource": "vl1cal",
      "venue": "Pleiku",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 4000,
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-7-NBI-BNI": {
      "id": "vl1-7-NBI-BNI",
      "league": "vl1",
      "round": 7,
      "home": "NBI",
      "away": "BNI",
      "score": [
        2,
        1
      ],
      "source": "vl1r7",
      "date": "2026-11-07",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Ninh Bình",
      "broadcast": "FPT Play, HTV4, MyTV, TV360",
      "attendance": 6000,
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-7-HPH-SLN": {
      "id": "vl1-7-HPH-SLN",
      "league": "vl1",
      "round": 7,
      "home": "HPH",
      "away": "SLN",
      "score": [
        2,
        2
      ],
      "source": "vl1r7",
      "date": "2026-11-07",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Lạch Tray",
      "broadcast": "FPT Play, TV360",
      "attendance": 7000,
      "yellow": [
        2,
        6
      ],
      "red": [
        1,
        0
      ],
      "status": "final"
    },
    "vl1-7-CAH-HCM": {
      "id": "vl1-7-CAH-HCM",
      "league": "vl1",
      "round": 7,
      "home": "CAH",
      "away": "HCM",
      "score": [
        2,
        1
      ],
      "source": "vl1r7",
      "date": "2026-11-07",
      "time": "19:15",
      "timingSource": "vl1cal",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 9000,
      "yellow": [
        3,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-7-TCV-THA": {
      "id": "vl1-7-TCV-THA",
      "league": "vl1",
      "round": 7,
      "home": "TCV",
      "away": "THA",
      "score": [
        1,
        1
      ],
      "source": "vl1r7",
      "date": "2026-11-08",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "49",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, HTV4, MyTV, TV360",
      "attendance": 8200,
      "yellow": [
        1,
        0
      ],
      "red": [
        0,
        1
      ],
      "status": "final"
    },
    "vl1-8-THA-HAG": {
      "id": "vl1-8-THA-HAG",
      "league": "vl1",
      "round": 8,
      "home": "THA",
      "away": "HAG",
      "score": [
        2,
        1
      ],
      "source": "vl1r8",
      "date": "2026-11-20",
      "time": "17:00",
      "timingSource": "vl1cal",
      "number": "50",
      "venue": "Thanh Hóa",
      "broadcast": "FPT Play, TV360",
      "attendance": 5000,
      "yellow": [
        5,
        3
      ],
      "red": [
        0,
        0
      ],
      "goals": [
        [
          "Damoth Thongkhamsavath 25'",
          " Matheus Martins 60'"
        ],
        [
          "Matheus Lucas 45+1'"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "vl1-8-TCV-SLN": {
      "id": "vl1-8-TCV-SLN",
      "league": "vl1",
      "round": 8,
      "home": "TCV",
      "away": "SLN",
      "score": [
        0,
        0
      ],
      "source": "vl1r8",
      "date": "2026-11-20",
      "time": "19:15",
      "timingSource": "vl1cal",
      "number": "51",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "attendance": 5000,
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-8-NDI-HPH": {
      "id": "vl1-8-NDI-HPH",
      "league": "vl1",
      "round": 8,
      "home": "NDI",
      "away": "HPH",
      "score": [
        2,
        1
      ],
      "source": "vl1r8",
      "date": "2026-11-21",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "52",
      "venue": "Thiên Trường",
      "broadcast": "FPT Play, VTV7, MyTV, TV360",
      "attendance": 9000,
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        1
      ],
      "goals": [
        [
          "Caio 42' (P)",
          " Mạnh Quỳnh 57'"
        ],
        [
          "Makaric 78'"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "vl1-8-DNC-HNO": {
      "id": "vl1-8-DNC-HNO",
      "league": "vl1",
      "round": 8,
      "home": "DNC",
      "away": "HNO",
      "score": [
        1,
        3
      ],
      "source": "vl1r8",
      "date": "2026-11-21",
      "time": "18:00",
      "timingSource": "vl1cal",
      "number": "53",
      "venue": "Bình Phước",
      "broadcast": "FPT Play, Ứng dụng HTV",
      "attendance": 6000,
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-8-DNA-NBI": {
      "id": "vl1-8-DNA-NBI",
      "league": "vl1",
      "round": 8,
      "home": "DNA",
      "away": "NBI",
      "score": [
        0,
        1
      ],
      "source": "vl1r8",
      "date": "2026-11-22",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Chi Lăng",
      "broadcast": "FPT Play, TV360",
      "attendance": 9000,
      "yellow": [
        2,
        2
      ],
      "red": [
        1,
        0
      ],
      "goals": [
        [],
        [
          "Hoàng Đức"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "vl1-8-HLH-HCM": {
      "id": "vl1-8-HLH-HCM",
      "league": "vl1",
      "round": 8,
      "home": "HLH",
      "away": "HCM",
      "score": [
        2,
        1
      ],
      "source": "vl1r8",
      "date": "2026-11-22",
      "time": "18:00",
      "timingSource": "vl1cal",
      "venue": "Hà Tĩnh",
      "broadcast": "FPT Play, Ứng dụng HTV",
      "attendance": 4000,
      "yellow": [
        2,
        1
      ],
      "red": [
        0,
        0
      ],
      "status": "final"
    },
    "vl1-9-SLN-NBI": {
      "id": "vl1-9-SLN-NBI",
      "league": "vl1",
      "round": 9,
      "home": "SLN",
      "away": "NBI",
      "score": null,
      "source": "r9",
      "date": "2026-11-27",
      "time": "18:00",
      "venue": "Vinh",
      "broadcast": "FPT Play, Ứng dụng HTV, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-9-NDI-CAH": {
      "id": "vl1-9-NDI-CAH",
      "league": "vl1",
      "round": 9,
      "home": "NDI",
      "away": "CAH",
      "score": null,
      "source": "r9",
      "date": "2026-11-27",
      "time": "18:00",
      "venue": "Thiên Trường",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-9-HCM-HAG": {
      "id": "vl1-9-HCM-HAG",
      "league": "vl1",
      "round": 9,
      "home": "HCM",
      "away": "HAG",
      "score": null,
      "source": "r9",
      "date": "2026-11-28",
      "time": "18:00",
      "venue": "Bình Dương",
      "broadcast": "FPT Play, HTV4, MyTV, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-9-BNI-DNA": {
      "id": "vl1-9-BNI-DNA",
      "league": "vl1",
      "round": 9,
      "home": "BNI",
      "away": "DNA",
      "score": null,
      "source": "r9",
      "date": "2026-11-28",
      "time": "18:00",
      "venue": "Việt Yên",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-9-HNO-HLH": {
      "id": "vl1-9-HNO-HLH",
      "league": "vl1",
      "round": 9,
      "home": "HNO",
      "away": "HLH",
      "score": null,
      "source": "r9",
      "date": "2026-11-28",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-9-THA-DNC": {
      "id": "vl1-9-THA-DNC",
      "league": "vl1",
      "round": 9,
      "home": "THA",
      "away": "DNC",
      "score": null,
      "source": "r9",
      "date": "2026-11-29",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-9-HPH-TCV": {
      "id": "vl1-9-HPH-TCV",
      "league": "vl1",
      "round": 9,
      "home": "HPH",
      "away": "TCV",
      "score": null,
      "source": "r9",
      "date": "2026-11-29",
      "time": "18:00",
      "venue": "Lạch Tray",
      "broadcast": "FPT Play, VTV6, MyTV, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl1-10-HCM-NDI": {
      "id": "vl1-10-HCM-NDI",
      "league": "vl1",
      "round": 10,
      "home": "HCM",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-04",
      "time": "18:00",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-10-HAG-DNC": {
      "id": "vl1-10-HAG-DNC",
      "league": "vl1",
      "round": 10,
      "home": "HAG",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-05",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-10-BNI-HLH": {
      "id": "vl1-10-BNI-HLH",
      "league": "vl1",
      "round": 10,
      "home": "BNI",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-05",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-10-SLN-THA": {
      "id": "vl1-10-SLN-THA",
      "league": "vl1",
      "round": 10,
      "home": "SLN",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-06",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-10-NBI-CAH": {
      "id": "vl1-10-NBI-CAH",
      "league": "vl1",
      "round": 10,
      "home": "NBI",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-06",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-10-HNO-HPH": {
      "id": "vl1-10-HNO-HPH",
      "league": "vl1",
      "round": 10,
      "home": "HNO",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-06",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-10-DNA-TCV": {
      "id": "vl1-10-DNA-TCV",
      "league": "vl1",
      "round": 10,
      "home": "DNA",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-07",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-NDI-SLN": {
      "id": "vl1-11-NDI-SLN",
      "league": "vl1",
      "round": 11,
      "home": "NDI",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-11",
      "time": "18:00",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-TCV-HNO": {
      "id": "vl1-11-TCV-HNO",
      "league": "vl1",
      "round": 11,
      "home": "TCV",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-11",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-HPH-BNI": {
      "id": "vl1-11-HPH-BNI",
      "league": "vl1",
      "round": 11,
      "home": "HPH",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-12",
      "time": "18:00",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-HLH-DNA": {
      "id": "vl1-11-HLH-DNA",
      "league": "vl1",
      "round": 11,
      "home": "HLH",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-12",
      "time": "18:00",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-DNC-NBI": {
      "id": "vl1-11-DNC-NBI",
      "league": "vl1",
      "round": 11,
      "home": "DNC",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-12",
      "time": "18:00",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-THA-HCM": {
      "id": "vl1-11-THA-HCM",
      "league": "vl1",
      "round": 11,
      "home": "THA",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-13",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-11-CAH-HAG": {
      "id": "vl1-11-CAH-HAG",
      "league": "vl1",
      "round": 11,
      "home": "CAH",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-13",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-12-NDI-BNI": {
      "id": "vl1-12-NDI-BNI",
      "league": "vl1",
      "round": 12,
      "home": "NDI",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-16",
      "time": "18:00",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-12-SLN-DNA": {
      "id": "vl1-12-SLN-DNA",
      "league": "vl1",
      "round": 12,
      "home": "SLN",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-16",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-12-THA-HNO": {
      "id": "vl1-12-THA-HNO",
      "league": "vl1",
      "round": 12,
      "home": "THA",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-17",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-12-HLH-NBI": {
      "id": "vl1-12-HLH-NBI",
      "league": "vl1",
      "round": 12,
      "home": "HLH",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-17",
      "time": "18:00",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-12-CAH-HPH": {
      "id": "vl1-12-CAH-HPH",
      "league": "vl1",
      "round": 12,
      "home": "CAH",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-17",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-12-TCV-HAG": {
      "id": "vl1-12-TCV-HAG",
      "league": "vl1",
      "round": 12,
      "home": "TCV",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-18",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-13-DNC-SLN": {
      "id": "vl1-13-DNC-SLN",
      "league": "vl1",
      "round": 13,
      "home": "DNC",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-20",
      "time": "18:00",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-13-DNA-CAH": {
      "id": "vl1-13-DNA-CAH",
      "league": "vl1",
      "round": 13,
      "home": "DNA",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-21",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-13-HAG-HLH": {
      "id": "vl1-13-HAG-HLH",
      "league": "vl1",
      "round": 13,
      "home": "HAG",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-22",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-13-HPH-HCM": {
      "id": "vl1-13-HPH-HCM",
      "league": "vl1",
      "round": 13,
      "home": "HPH",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-21",
      "time": "18:00",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "scheduled",
      "changed": true
    },
    "vl1-13-BNI-THA": {
      "id": "vl1-13-BNI-THA",
      "league": "vl1",
      "round": 13,
      "home": "BNI",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-21",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "scheduled",
      "changed": true
    },
    "vl1-13-NBI-TCV": {
      "id": "vl1-13-NBI-TCV",
      "league": "vl1",
      "round": 13,
      "home": "NBI",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-22",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-13-HNO-NDI": {
      "id": "vl1-13-HNO-NDI",
      "league": "vl1",
      "round": 13,
      "home": "HNO",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-21",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled",
      "changed": true
    },
    "vl1-12-HCM-DNC": {
      "id": "vl1-12-HCM-DNC",
      "league": "vl1",
      "round": 12,
      "home": "HCM",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "date": "2026-12-25",
      "time": "18:00",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-8-CAH-BNI": {
      "id": "vl1-8-CAH-BNI",
      "league": "vl1",
      "round": 8,
      "home": "CAH",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "makeup": true,
      "date": "2026-12-25",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-TCV-HCM": {
      "id": "vl1-14-TCV-HCM",
      "league": "vl1",
      "round": 14,
      "home": "TCV",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "number": "92",
      "date": "2027-01-08",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-HAG-NBI": {
      "id": "vl1-14-HAG-NBI",
      "league": "vl1",
      "round": 14,
      "home": "HAG",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "number": "93",
      "date": "2027-01-09",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-DNC-BNI": {
      "id": "vl1-14-DNC-BNI",
      "league": "vl1",
      "round": 14,
      "home": "DNC",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "number": "95",
      "date": "2027-01-09",
      "time": "18:00",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-SLN-HLH": {
      "id": "vl1-14-SLN-HLH",
      "league": "vl1",
      "round": 14,
      "home": "SLN",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "number": "94",
      "date": "2027-01-09",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-HPH-DNA": {
      "id": "vl1-14-HPH-DNA",
      "league": "vl1",
      "round": 14,
      "home": "HPH",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "number": "96",
      "date": "2027-01-10",
      "time": "18:00",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-NDI-THA": {
      "id": "vl1-14-NDI-THA",
      "league": "vl1",
      "round": 14,
      "home": "NDI",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "number": "97",
      "date": "2027-01-10",
      "time": "18:00",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-14-HNO-CAH": {
      "id": "vl1-14-HNO-CAH",
      "league": "vl1",
      "round": 14,
      "home": "HNO",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "number": "98",
      "date": "2027-01-10",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-CAH-DNC": {
      "id": "vl1-15-CAH-DNC",
      "league": "vl1",
      "round": 15,
      "home": "CAH",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "number": "99",
      "date": "2027-01-15",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-THA-HPH": {
      "id": "vl1-15-THA-HPH",
      "league": "vl1",
      "round": 15,
      "home": "THA",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "number": "100",
      "date": "2027-01-16",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-HLH-TCV": {
      "id": "vl1-15-HLH-TCV",
      "league": "vl1",
      "round": 15,
      "home": "HLH",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "number": "103",
      "date": "2027-01-16",
      "time": "18:00",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-DNA-HAG": {
      "id": "vl1-15-DNA-HAG",
      "league": "vl1",
      "round": 15,
      "home": "DNA",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "number": "102",
      "date": "2027-01-16",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-BNI-HNO": {
      "id": "vl1-15-BNI-HNO",
      "league": "vl1",
      "round": 15,
      "home": "BNI",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "number": "101",
      "date": "2027-01-17",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-HCM-SLN": {
      "id": "vl1-15-HCM-SLN",
      "league": "vl1",
      "round": 15,
      "home": "HCM",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "number": "104",
      "date": "2027-01-17",
      "time": "18:00",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-15-NBI-NDI": {
      "id": "vl1-15-NBI-NDI",
      "league": "vl1",
      "round": 15,
      "home": "NBI",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "number": "105",
      "date": "2027-01-17",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-HAG-TCV": {
      "id": "vl1-16-HAG-TCV",
      "league": "vl1",
      "round": 16,
      "home": "HAG",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "number": "106",
      "date": "2027-01-22",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-BNI-NDI": {
      "id": "vl1-16-BNI-NDI",
      "league": "vl1",
      "round": 16,
      "home": "BNI",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "number": "107",
      "date": "2027-01-23",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-NBI-HLH": {
      "id": "vl1-16-NBI-HLH",
      "league": "vl1",
      "round": 16,
      "home": "NBI",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "number": "108",
      "date": "2027-01-23",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-HNO-THA": {
      "id": "vl1-16-HNO-THA",
      "league": "vl1",
      "round": 16,
      "home": "HNO",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "number": "109",
      "date": "2027-01-23",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-DNC-HCM": {
      "id": "vl1-16-DNC-HCM",
      "league": "vl1",
      "round": 16,
      "home": "DNC",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "number": "112",
      "date": "2027-01-24",
      "time": "18:00",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-HPH-CAH": {
      "id": "vl1-16-HPH-CAH",
      "league": "vl1",
      "round": 16,
      "home": "HPH",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "number": "110",
      "date": "2027-01-24",
      "time": "18:00",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-16-DNA-SLN": {
      "id": "vl1-16-DNA-SLN",
      "league": "vl1",
      "round": 16,
      "home": "DNA",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "number": "111",
      "date": "2027-01-24",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-HCM-HPH": {
      "id": "vl1-17-HCM-HPH",
      "league": "vl1",
      "round": 17,
      "home": "HCM",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "number": "113",
      "date": "2027-02-19",
      "time": "18:00",
      "venue": "Thống Nhất",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-THA-BNI": {
      "id": "vl1-17-THA-BNI",
      "league": "vl1",
      "round": 17,
      "home": "THA",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "number": "114",
      "date": "2027-02-20",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-HLH-HAG": {
      "id": "vl1-17-HLH-HAG",
      "league": "vl1",
      "round": 17,
      "home": "HLH",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "number": "115",
      "date": "2027-02-20",
      "time": "18:00",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-TCV-NBI": {
      "id": "vl1-17-TCV-NBI",
      "league": "vl1",
      "round": 17,
      "home": "TCV",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "number": "116",
      "date": "2027-02-20",
      "time": "19:15",
      "venue": "Mỹ Đình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-SLN-DNC": {
      "id": "vl1-17-SLN-DNC",
      "league": "vl1",
      "round": 17,
      "home": "SLN",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "number": "118",
      "date": "2027-02-21",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-NDI-HNO": {
      "id": "vl1-17-NDI-HNO",
      "league": "vl1",
      "round": 17,
      "home": "NDI",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "number": "118",
      "date": "2027-02-21",
      "time": "18:00",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-17-CAH-DNA": {
      "id": "vl1-17-CAH-DNA",
      "league": "vl1",
      "round": 17,
      "home": "CAH",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "number": "119",
      "date": "2027-02-21",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-DNA-BNI": {
      "id": "vl1-18-DNA-BNI",
      "league": "vl1",
      "round": 18,
      "home": "DNA",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "number": "120",
      "date": "2027-02-26",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-DNC-THA": {
      "id": "vl1-18-DNC-THA",
      "league": "vl1",
      "round": 18,
      "home": "DNC",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "number": "122",
      "date": "2027-02-27",
      "time": "18:00",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-HLH-HNO": {
      "id": "vl1-18-HLH-HNO",
      "league": "vl1",
      "round": 18,
      "home": "HLH",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "number": "121",
      "date": "2027-02-27",
      "time": "18:00",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-TCV-HPH": {
      "id": "vl1-18-TCV-HPH",
      "league": "vl1",
      "round": 18,
      "home": "TCV",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "number": "123",
      "date": "2027-02-27",
      "time": "19:15",
      "venue": "Mỹ Đình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-HAG-HCM": {
      "id": "vl1-18-HAG-HCM",
      "league": "vl1",
      "round": 18,
      "home": "HAG",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "number": "124",
      "date": "2027-02-28",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-NBI-SLN": {
      "id": "vl1-18-NBI-SLN",
      "league": "vl1",
      "round": 18,
      "home": "NBI",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "number": "125",
      "date": "2027-02-28",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-18-CAH-NDI": {
      "id": "vl1-18-CAH-NDI",
      "league": "vl1",
      "round": 18,
      "home": "CAH",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "number": "126",
      "date": "2027-02-28",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-HAG-THA": {
      "id": "vl1-19-HAG-THA",
      "league": "vl1",
      "round": 19,
      "home": "HAG",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "number": "127",
      "date": "2027-03-06",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-SLN-TCV": {
      "id": "vl1-19-SLN-TCV",
      "league": "vl1",
      "round": 19,
      "home": "SLN",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "number": "128",
      "date": "2027-03-06",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-HPH-NDI": {
      "id": "vl1-19-HPH-NDI",
      "league": "vl1",
      "round": 19,
      "home": "HPH",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "number": "129",
      "date": "2027-03-06",
      "time": "18:00",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-HCM-HLH": {
      "id": "vl1-19-HCM-HLH",
      "league": "vl1",
      "round": 19,
      "home": "HCM",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "number": "130",
      "date": "2027-03-07",
      "time": "18:00",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-NBI-DNA": {
      "id": "vl1-19-NBI-DNA",
      "league": "vl1",
      "round": 19,
      "home": "NBI",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "number": "131",
      "date": "2027-03-07",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-HNO-DNC": {
      "id": "vl1-19-HNO-DNC",
      "league": "vl1",
      "round": 19,
      "home": "HNO",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "number": "132",
      "date": "2027-03-07",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-19-BNI-CAH": {
      "id": "vl1-19-BNI-CAH",
      "league": "vl1",
      "round": 19,
      "home": "BNI",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "number": "133",
      "date": "2027-03-08",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-20-HNO-HAG": {
      "id": "vl1-20-HNO-HAG",
      "league": "vl1",
      "round": 20,
      "home": "HNO",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "number": "134",
      "date": "2027-03-12",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-20-THA-TCV": {
      "id": "vl1-20-THA-TCV",
      "league": "vl1",
      "round": 20,
      "home": "THA",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "number": "135",
      "date": "2027-03-13",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-20-BNI-NBI": {
      "id": "vl1-20-BNI-NBI",
      "league": "vl1",
      "round": 20,
      "home": "BNI",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "number": "136",
      "date": "2027-03-13",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-20-SLN-HPH": {
      "id": "vl1-20-SLN-HPH",
      "league": "vl1",
      "round": 20,
      "home": "SLN",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "number": "137",
      "date": "2027-03-13",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "scheduled",
      "changed": true
    },
    "vl1-20-HCM-CAH": {
      "id": "vl1-20-HCM-CAH",
      "league": "vl1",
      "round": 20,
      "home": "HCM",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "number": "140",
      "date": "2027-03-14",
      "time": "18:00",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-20-DNA-DNC": {
      "id": "vl1-20-DNA-DNC",
      "league": "vl1",
      "round": 20,
      "home": "DNA",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "number": "138",
      "date": "2027-03-14",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-20-NDI-HLH": {
      "id": "vl1-20-NDI-HLH",
      "league": "vl1",
      "round": 20,
      "home": "NDI",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "number": "139",
      "date": "2027-03-14",
      "time": "18:00",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-DNA-HCM": {
      "id": "vl1-21-DNA-HCM",
      "league": "vl1",
      "round": 21,
      "home": "DNA",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "number": "141",
      "date": "2027-03-19",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-DNC-HPH": {
      "id": "vl1-21-DNC-HPH",
      "league": "vl1",
      "round": 21,
      "home": "DNC",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "number": "142",
      "date": "2027-03-20",
      "time": "18:00",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-NBI-HNO": {
      "id": "vl1-21-NBI-HNO",
      "league": "vl1",
      "round": 21,
      "home": "NBI",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "number": "143",
      "date": "2027-03-20",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-CAH-SLN": {
      "id": "vl1-21-CAH-SLN",
      "league": "vl1",
      "round": 21,
      "home": "CAH",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "number": "144",
      "date": "2027-03-20",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-HAG-BNI": {
      "id": "vl1-21-HAG-BNI",
      "league": "vl1",
      "round": 21,
      "home": "HAG",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "number": "145",
      "date": "2027-03-21",
      "time": "17:00",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-HLH-THA": {
      "id": "vl1-21-HLH-THA",
      "league": "vl1",
      "round": 21,
      "home": "HLH",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "number": "146",
      "date": "2027-03-21",
      "time": "18:00",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-21-TCV-NDI": {
      "id": "vl1-21-TCV-NDI",
      "league": "vl1",
      "round": 21,
      "home": "TCV",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "number": "147",
      "date": "2027-03-21",
      "time": "19:15",
      "venue": "Mỹ Đình",
      "timingSource": "vl1cal",
      "status": "scheduled"
    },
    "vl1-22-THA-CAH": {
      "id": "vl1-22-THA-CAH",
      "league": "vl1",
      "round": 22,
      "home": "THA",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-22-BNI-TCV": {
      "id": "vl1-22-BNI-TCV",
      "league": "vl1",
      "round": 22,
      "home": "BNI",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-22-SLN-HAG": {
      "id": "vl1-22-SLN-HAG",
      "league": "vl1",
      "round": 22,
      "home": "SLN",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-22-HCM-NBI": {
      "id": "vl1-22-HCM-NBI",
      "league": "vl1",
      "round": 22,
      "home": "HCM",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-22-HPH-HLH": {
      "id": "vl1-22-HPH-HLH",
      "league": "vl1",
      "round": 22,
      "home": "HPH",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-22-NDI-DNC": {
      "id": "vl1-22-NDI-DNC",
      "league": "vl1",
      "round": 22,
      "home": "NDI",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-22-HNO-DNA": {
      "id": "vl1-22-HNO-DNA",
      "league": "vl1",
      "round": 22,
      "home": "HNO",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "month": "2027-04",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-THA-SLN": {
      "id": "vl1-23-THA-SLN",
      "league": "vl1",
      "round": 23,
      "home": "THA",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-DNC-HAG": {
      "id": "vl1-23-DNC-HAG",
      "league": "vl1",
      "round": 23,
      "home": "DNC",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-HLH-BNI": {
      "id": "vl1-23-HLH-BNI",
      "league": "vl1",
      "round": 23,
      "home": "HLH",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-HPH-HNO": {
      "id": "vl1-23-HPH-HNO",
      "league": "vl1",
      "round": 23,
      "home": "HPH",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-NDI-HCM": {
      "id": "vl1-23-NDI-HCM",
      "league": "vl1",
      "round": 23,
      "home": "NDI",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-CAH-NBI": {
      "id": "vl1-23-CAH-NBI",
      "league": "vl1",
      "round": 23,
      "home": "CAH",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-23-TCV-DNA": {
      "id": "vl1-23-TCV-DNA",
      "league": "vl1",
      "round": 23,
      "home": "TCV",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Mỹ Đình",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-HAG-CAH": {
      "id": "vl1-24-HAG-CAH",
      "league": "vl1",
      "round": 24,
      "home": "HAG",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-BNI-HPH": {
      "id": "vl1-24-BNI-HPH",
      "league": "vl1",
      "round": 24,
      "home": "BNI",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-SLN-NDI": {
      "id": "vl1-24-SLN-NDI",
      "league": "vl1",
      "round": 24,
      "home": "SLN",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-HCM-THA": {
      "id": "vl1-24-HCM-THA",
      "league": "vl1",
      "round": 24,
      "home": "HCM",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-DNA-HLH": {
      "id": "vl1-24-DNA-HLH",
      "league": "vl1",
      "round": 24,
      "home": "DNA",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-NBI-DNC": {
      "id": "vl1-24-NBI-DNC",
      "league": "vl1",
      "round": 24,
      "home": "NBI",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-24-HNO-TCV": {
      "id": "vl1-24-HNO-TCV",
      "league": "vl1",
      "round": 24,
      "home": "HNO",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-THA-NBI": {
      "id": "vl1-25-THA-NBI",
      "league": "vl1",
      "round": 25,
      "home": "THA",
      "away": "NBI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Thanh Hóa",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-DNC-HLH": {
      "id": "vl1-25-DNC-HLH",
      "league": "vl1",
      "round": 25,
      "home": "DNC",
      "away": "HLH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Bình Phước",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-SLN-HNO": {
      "id": "vl1-25-SLN-HNO",
      "league": "vl1",
      "round": 25,
      "home": "SLN",
      "away": "HNO",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Vinh",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-HCM-BNI": {
      "id": "vl1-25-HCM-BNI",
      "league": "vl1",
      "round": 25,
      "home": "HCM",
      "away": "BNI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Bình Dương",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-HPH-HAG": {
      "id": "vl1-25-HPH-HAG",
      "league": "vl1",
      "round": 25,
      "home": "HPH",
      "away": "HAG",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Lạch Tray",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-NDI-DNA": {
      "id": "vl1-25-NDI-DNA",
      "league": "vl1",
      "round": 25,
      "home": "NDI",
      "away": "DNA",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Thiên Trường",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-25-CAH-TCV": {
      "id": "vl1-25-CAH-TCV",
      "league": "vl1",
      "round": 25,
      "home": "CAH",
      "away": "TCV",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-HAG-NDI": {
      "id": "vl1-26-HAG-NDI",
      "league": "vl1",
      "round": 26,
      "home": "HAG",
      "away": "NDI",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Pleiku",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-BNI-SLN": {
      "id": "vl1-26-BNI-SLN",
      "league": "vl1",
      "round": 26,
      "home": "BNI",
      "away": "SLN",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Việt Yên",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-HLH-CAH": {
      "id": "vl1-26-HLH-CAH",
      "league": "vl1",
      "round": 26,
      "home": "HLH",
      "away": "CAH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Hà Tĩnh",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-DNA-THA": {
      "id": "vl1-26-DNA-THA",
      "league": "vl1",
      "round": 26,
      "home": "DNA",
      "away": "THA",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Chi Lăng",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-NBI-HPH": {
      "id": "vl1-26-NBI-HPH",
      "league": "vl1",
      "round": 26,
      "home": "NBI",
      "away": "HPH",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Ninh Bình",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-HNO-HCM": {
      "id": "vl1-26-HNO-HCM",
      "league": "vl1",
      "round": 26,
      "home": "HNO",
      "away": "HCM",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Hàng Đẫy",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl1-26-TCV-DNC": {
      "id": "vl1-26-TCV-DNC",
      "league": "vl1",
      "round": 26,
      "home": "TCV",
      "away": "DNC",
      "score": null,
      "source": "vl1cal",
      "month": "2027-05",
      "venue": "Mỹ Đình",
      "timingSource": "vl1cal",
      "status": "tbd"
    },
    "vl2-1-HUE-BMS": {
      "id": "vl2-1-HUE-BMS",
      "league": "vl2",
      "round": 1,
      "home": "HUE",
      "away": "BMS",
      "score": [
        0,
        2
      ],
      "source": "vl2r1",
      "date": "2026-09-11",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Tự Do",
      "attendance": 3000,
      "status": "final"
    },
    "vl2-1-CND-LAN": {
      "id": "vl2-1-CND-LAN",
      "league": "vl2",
      "round": 1,
      "home": "CND",
      "away": "LAN",
      "score": [
        2,
        1
      ],
      "source": "vl2r1",
      "date": "2026-09-11",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        4,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 1200,
      "status": "final"
    },
    "vl2-1-LDO-TPH": {
      "id": "vl2-1-LDO-TPH",
      "league": "vl2",
      "round": 1,
      "home": "LDO",
      "away": "TPH",
      "score": [
        0,
        1
      ],
      "source": "vl2r1",
      "date": "2026-09-12",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        2,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "Đà Lạt",
      "attendance": 6000,
      "status": "final"
    },
    "vl2-1-TCT-HYE": {
      "id": "vl2-1-TCT-HYE",
      "league": "vl2",
      "round": 1,
      "home": "TCT",
      "away": "HYE",
      "score": [
        0,
        3
      ],
      "source": "vl2r1",
      "date": "2026-09-12",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Cần Thơ",
      "attendance": 10000,
      "status": "final"
    },
    "vl2-1-VHI-BEC": {
      "id": "vl2-1-VHI-BEC",
      "league": "vl2",
      "round": 1,
      "home": "VHI",
      "away": "BEC",
      "score": [
        0,
        0
      ],
      "source": "vl2r1",
      "date": "2026-09-13",
      "time": "16:00",
      "timingSource": "archive",
      "yellow": [
        3,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 800,
      "status": "final"
    },
    "vl2-1-TNG-QNU": {
      "id": "vl2-1-TNG-QNU",
      "league": "vl2",
      "round": 1,
      "home": "TNG",
      "away": "QNU",
      "score": [
        2,
        1
      ],
      "source": "vl2r1",
      "date": "2026-09-13",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Thái Nguyên",
      "attendance": 8800,
      "status": "final"
    },
    "vl2-1-XPT-KKH": {
      "id": "vl2-1-XPT-KKH",
      "league": "vl2",
      "round": 1,
      "home": "XPT",
      "away": "KKH",
      "score": [
        1,
        1
      ],
      "source": "vl2r1",
      "date": "2026-09-13",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        2
      ],
      "red": [
        1,
        0
      ],
      "venue": "Việt Trì",
      "attendance": 600,
      "status": "final"
    },
    "vl2-2-TPH-VHI": {
      "id": "vl2-2-TPH-VHI",
      "league": "vl2",
      "round": 2,
      "home": "TPH",
      "away": "VHI",
      "score": [
        0,
        1
      ],
      "source": "vl2r2",
      "date": "2026-09-25",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 800,
      "status": "final"
    },
    "vl2-2-BMS-TNG": {
      "id": "vl2-2-BMS-TNG",
      "league": "vl2",
      "round": 2,
      "home": "BMS",
      "away": "TNG",
      "score": [
        0,
        3
      ],
      "source": "vl2r2",
      "date": "2026-09-27",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 800,
      "status": "final"
    },
    "vl2-2-LAN-TCT": {
      "id": "vl2-2-LAN-TCT",
      "league": "vl2",
      "round": 2,
      "home": "LAN",
      "away": "TCT",
      "score": [
        0,
        0
      ],
      "source": "vl2r2",
      "date": "2026-10-10",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        2,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "Long An",
      "attendance": 600,
      "status": "final"
    },
    "vl2-2-HYE-XPT": {
      "id": "vl2-2-HYE-XPT",
      "league": "vl2",
      "round": 2,
      "home": "HYE",
      "away": "XPT",
      "score": [
        8,
        1
      ],
      "source": "vl2r2",
      "date": "2026-10-10",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        4,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-2-BEC-LDO": {
      "id": "vl2-2-BEC-LDO",
      "league": "vl2",
      "round": 2,
      "home": "BEC",
      "away": "LDO",
      "score": [
        3,
        1
      ],
      "source": "vl2r2",
      "date": "2026-10-10",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        4,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bình Dương",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-2-KKH-CND": {
      "id": "vl2-2-KKH-CND",
      "league": "vl2",
      "round": 2,
      "home": "KKH",
      "away": "CND",
      "score": [
        4,
        1
      ],
      "source": "vl2r2",
      "date": "2026-10-11",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        3,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "19/8 Nha Trang",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-2-QNU-HUE": {
      "id": "vl2-2-QNU-HUE",
      "league": "vl2",
      "round": 2,
      "home": "QNU",
      "away": "HUE",
      "score": [
        1,
        1
      ],
      "source": "vl2r2",
      "date": "2026-10-11",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Quy Nhơn",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-3-BMS-QNU": {
      "id": "vl2-3-BMS-QNU",
      "league": "vl2",
      "round": 3,
      "home": "BMS",
      "away": "QNU",
      "score": [
        3,
        1
      ],
      "source": "vl2r3",
      "date": "2026-10-16",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 500,
      "status": "final"
    },
    "vl2-3-LDO-VHI": {
      "id": "vl2-3-LDO-VHI",
      "league": "vl2",
      "round": 3,
      "home": "LDO",
      "away": "VHI",
      "score": [
        3,
        0
      ],
      "source": "vl2r3",
      "date": "2026-10-17",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        1,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "Đà Lạt",
      "attendance": 5500,
      "status": "final"
    },
    "vl2-3-TCT-XPT": {
      "id": "vl2-3-TCT-XPT",
      "league": "vl2",
      "round": 3,
      "home": "TCT",
      "away": "XPT",
      "score": [
        2,
        0
      ],
      "source": "vl2r3",
      "date": "2026-10-17",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        0,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Cần Thơ",
      "attendance": 5000,
      "status": "final"
    },
    "vl2-3-CND-HYE": {
      "id": "vl2-3-CND-HYE",
      "league": "vl2",
      "round": 3,
      "home": "CND",
      "away": "HYE",
      "score": [
        1,
        1
      ],
      "source": "vl2r3",
      "date": "2026-10-17",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        2,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-3-LAN-KKH": {
      "id": "vl2-3-LAN-KKH",
      "league": "vl2",
      "round": 3,
      "home": "LAN",
      "away": "KKH",
      "score": [
        0,
        1
      ],
      "source": "vl2r3",
      "date": "2026-10-18",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        4,
        5
      ],
      "red": [
        0,
        0
      ],
      "venue": "Long An",
      "attendance": 700,
      "status": "final"
    },
    "vl2-3-TPH-BEC": {
      "id": "vl2-3-TPH-BEC",
      "league": "vl2",
      "round": 3,
      "home": "TPH",
      "away": "BEC",
      "score": [
        1,
        2
      ],
      "source": "vl2r3",
      "date": "2026-10-18",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        3,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-3-TNG-HUE": {
      "id": "vl2-3-TNG-HUE",
      "league": "vl2",
      "round": 3,
      "home": "TNG",
      "away": "HUE",
      "score": [
        4,
        1
      ],
      "source": "vl2r3",
      "date": "2026-10-18",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        5,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Thái Nguyên",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-4-VHI-BMS": {
      "id": "vl2-4-VHI-BMS",
      "league": "vl2",
      "round": 4,
      "home": "VHI",
      "away": "BMS",
      "score": [
        3,
        2
      ],
      "source": "vl2r4",
      "date": "2026-10-22",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 100,
      "status": "final"
    },
    "vl2-4-XPT-CND": {
      "id": "vl2-4-XPT-CND",
      "league": "vl2",
      "round": 4,
      "home": "XPT",
      "away": "CND",
      "score": [
        2,
        3
      ],
      "source": "vl2r4",
      "date": "2026-10-22",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Việt Trì",
      "attendance": 600,
      "status": "final"
    },
    "vl2-4-KKH-TCT": {
      "id": "vl2-4-KKH-TCT",
      "league": "vl2",
      "round": 4,
      "home": "KKH",
      "away": "TCT",
      "score": [
        1,
        1
      ],
      "source": "vl2r4",
      "date": "2026-10-23",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        0,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "19/8 Nha Trang",
      "attendance": 5000,
      "status": "final"
    },
    "vl2-4-BEC-TNG": {
      "id": "vl2-4-BEC-TNG",
      "league": "vl2",
      "round": 4,
      "home": "BEC",
      "away": "TNG",
      "score": [
        2,
        3
      ],
      "source": "vl2r4",
      "date": "2026-10-23",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        6
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bình Dương",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-4-QNU-LDO": {
      "id": "vl2-4-QNU-LDO",
      "league": "vl2",
      "round": 4,
      "home": "QNU",
      "away": "LDO",
      "score": [
        4,
        0
      ],
      "source": "vl2r4",
      "date": "2026-10-23",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Quy Nhơn",
      "attendance": 1500,
      "status": "final"
    },
    "vl2-4-HUE-TPH": {
      "id": "vl2-4-HUE-TPH",
      "league": "vl2",
      "round": 4,
      "home": "HUE",
      "away": "TPH",
      "score": [
        2,
        2
      ],
      "source": "vl2r4",
      "date": "2026-10-24",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        3,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "Tự Do",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-4-HYE-LAN": {
      "id": "vl2-4-HYE-LAN",
      "league": "vl2",
      "round": 4,
      "home": "HYE",
      "away": "LAN",
      "score": [
        3,
        1
      ],
      "source": "vl2r4",
      "date": "2026-10-24",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        2,
        3
      ],
      "red": [
        1,
        0
      ],
      "venue": "PVF",
      "attendance": 1500,
      "status": "final"
    },
    "vl2-5-LDO-CND": {
      "id": "vl2-5-LDO-CND",
      "league": "vl2",
      "round": 5,
      "home": "LDO",
      "away": "CND",
      "score": [
        1,
        2
      ],
      "source": "vl2r5",
      "date": "2026-10-27",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        1,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Đà Lạt",
      "attendance": 4500,
      "status": "final"
    },
    "vl2-5-VHI-XPT": {
      "id": "vl2-5-VHI-XPT",
      "league": "vl2",
      "round": 5,
      "home": "VHI",
      "away": "XPT",
      "score": [
        1,
        1
      ],
      "source": "vl2r5",
      "date": "2026-10-27",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-5-KKH-BMS": {
      "id": "vl2-5-KKH-BMS",
      "league": "vl2",
      "round": 5,
      "home": "KKH",
      "away": "BMS",
      "score": [
        0,
        1
      ],
      "source": "vl2r5",
      "date": "2026-10-27",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        0,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "19/8 Nha Trang",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-5-BEC-TCT": {
      "id": "vl2-5-BEC-TCT",
      "league": "vl2",
      "round": 5,
      "home": "BEC",
      "away": "TCT",
      "score": [
        4,
        0
      ],
      "source": "vl2r5",
      "date": "2026-10-27",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bình Dương",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-5-LAN-TNG": {
      "id": "vl2-5-LAN-TNG",
      "league": "vl2",
      "round": 5,
      "home": "LAN",
      "away": "TNG",
      "score": [
        1,
        1
      ],
      "source": "vl2r5",
      "date": "2026-10-28",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        3,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "Long An",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-5-TPH-QNU": {
      "id": "vl2-5-TPH-QNU",
      "league": "vl2",
      "round": 5,
      "home": "TPH",
      "away": "QNU",
      "score": [
        2,
        1
      ],
      "source": "vl2r5",
      "date": "2026-10-28",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-5-HYE-HUE": {
      "id": "vl2-5-HYE-HUE",
      "league": "vl2",
      "round": 5,
      "home": "HYE",
      "away": "HUE",
      "score": [
        4,
        1
      ],
      "source": "vl2r5",
      "date": "2026-10-28",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        0,
        0
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 2200,
      "status": "final"
    },
    "vl2-6-TCT-LDO": {
      "id": "vl2-6-TCT-LDO",
      "league": "vl2",
      "round": 6,
      "home": "TCT",
      "away": "LDO",
      "score": [
        2,
        0
      ],
      "source": "vl2r6",
      "date": "2026-10-31",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        4,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Cần Thơ",
      "attendance": 4000,
      "status": "final"
    },
    "vl2-6-XPT-BEC": {
      "id": "vl2-6-XPT-BEC",
      "league": "vl2",
      "round": 6,
      "home": "XPT",
      "away": "BEC",
      "score": [
        1,
        2
      ],
      "source": "vl2r6",
      "date": "2026-10-31",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Việt Trì",
      "attendance": 300,
      "status": "final"
    },
    "vl2-6-HUE-KKH": {
      "id": "vl2-6-HUE-KKH",
      "league": "vl2",
      "round": 6,
      "home": "HUE",
      "away": "KKH",
      "score": [
        1,
        2
      ],
      "source": "vl2r6",
      "date": "2026-11-01",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        0,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Huế",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-6-BMS-HYE": {
      "id": "vl2-6-BMS-HYE",
      "league": "vl2",
      "round": 6,
      "home": "BMS",
      "away": "HYE",
      "score": [
        2,
        1
      ],
      "source": "vl2r6",
      "date": "2026-11-01",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        1
      ],
      "venue": "Bà Rịa",
      "attendance": 400,
      "status": "final"
    },
    "vl2-6-TNG-VHI": {
      "id": "vl2-6-TNG-VHI",
      "league": "vl2",
      "round": 6,
      "home": "TNG",
      "away": "VHI",
      "score": [
        0,
        2
      ],
      "source": "vl2r6",
      "date": "2026-11-01",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        0,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Việt Yên",
      "attendance": 1500,
      "status": "final"
    },
    "vl2-6-CND-TPH": {
      "id": "vl2-6-CND-TPH",
      "league": "vl2",
      "round": 6,
      "home": "CND",
      "away": "TPH",
      "score": [
        0,
        1
      ],
      "source": "vl2r6",
      "date": "2026-11-01",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        1,
        4
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 1500,
      "status": "final"
    },
    "vl2-6-QNU-LAN": {
      "id": "vl2-6-QNU-LAN",
      "league": "vl2",
      "round": 6,
      "home": "QNU",
      "away": "LAN",
      "score": [
        0,
        0
      ],
      "source": "vl2r6",
      "date": "2026-11-01",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        2,
        3
      ],
      "red": [
        0,
        1
      ],
      "venue": "Quy Nhơn",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-7-VHI-HUE": {
      "id": "vl2-7-VHI-HUE",
      "league": "vl2",
      "round": 7,
      "home": "VHI",
      "away": "HUE",
      "score": [
        0,
        1
      ],
      "source": "vl2r7",
      "date": "2026-11-06",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        1,
        1
      ],
      "red": [
        1,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 600,
      "status": "final"
    },
    "vl2-7-LDO-KKH": {
      "id": "vl2-7-LDO-KKH",
      "league": "vl2",
      "round": 7,
      "home": "LDO",
      "away": "KKH",
      "score": [
        1,
        1
      ],
      "source": "vl2r7",
      "date": "2026-11-07",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        2,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Đà Lạt",
      "attendance": 6000,
      "status": "final"
    },
    "vl2-7-LAN-BMS": {
      "id": "vl2-7-LAN-BMS",
      "league": "vl2",
      "round": 7,
      "home": "LAN",
      "away": "BMS",
      "score": [
        1,
        1
      ],
      "source": "vl2r7",
      "date": "2026-11-07",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        2,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Long An",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-7-BEC-CND": {
      "id": "vl2-7-BEC-CND",
      "league": "vl2",
      "round": 7,
      "home": "BEC",
      "away": "CND",
      "score": [
        1,
        0
      ],
      "source": "vl2r7",
      "date": "2026-11-07",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        2,
        4
      ],
      "red": [
        0,
        1
      ],
      "venue": "Bình Dương",
      "attendance": 2000,
      "status": "final"
    },
    "vl2-7-TPH-XPT": {
      "id": "vl2-7-TPH-XPT",
      "league": "vl2",
      "round": 7,
      "home": "TPH",
      "away": "XPT",
      "score": [
        3,
        0
      ],
      "source": "vl2r7",
      "date": "2026-11-08",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        0,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 700,
      "status": "final"
    },
    "vl2-7-TCT-TNG": {
      "id": "vl2-7-TCT-TNG",
      "league": "vl2",
      "round": 7,
      "home": "TCT",
      "away": "TNG",
      "score": [
        0,
        4
      ],
      "source": "vl2r7",
      "date": "2026-11-08",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        3,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Cần Thơ",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-7-HYE-QNU": {
      "id": "vl2-7-HYE-QNU",
      "league": "vl2",
      "round": 7,
      "home": "HYE",
      "away": "QNU",
      "score": [
        0,
        0
      ],
      "source": "vl2r7",
      "date": "2026-11-08",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        4,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 3000,
      "status": "final"
    },
    "vl2-8-TPH-TNG": {
      "id": "vl2-8-TPH-TNG",
      "league": "vl2",
      "round": 8,
      "home": "TPH",
      "away": "TNG",
      "score": [
        1,
        0
      ],
      "source": "vl2r8",
      "date": "2026-11-20",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 1200,
      "status": "final"
    },
    "vl2-8-LDO-BMS": {
      "id": "vl2-8-LDO-BMS",
      "league": "vl2",
      "round": 8,
      "home": "LDO",
      "away": "BMS",
      "score": [
        0,
        2
      ],
      "source": "vl2r8",
      "date": "2026-11-21",
      "time": "15:30",
      "timingSource": "archive",
      "yellow": [
        0,
        2
      ],
      "red": [
        0,
        0
      ],
      "venue": "Đà Lạt",
      "attendance": 6000,
      "status": "final"
    },
    "vl2-8-XPT-LAN": {
      "id": "vl2-8-XPT-LAN",
      "league": "vl2",
      "round": 8,
      "home": "XPT",
      "away": "LAN",
      "score": [
        3,
        2
      ],
      "source": "vl2r8",
      "date": "2026-11-21",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        2,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Việt Trì",
      "attendance": 500,
      "status": "final"
    },
    "vl2-8-BEC-HUE": {
      "id": "vl2-8-BEC-HUE",
      "league": "vl2",
      "round": 8,
      "home": "BEC",
      "away": "HUE",
      "score": [
        5,
        0
      ],
      "source": "vl2r8",
      "date": "2026-11-21",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bình Dương",
      "attendance": 1500,
      "status": "final"
    },
    "vl2-8-VHI-QNU": {
      "id": "vl2-8-VHI-QNU",
      "league": "vl2",
      "round": 8,
      "home": "VHI",
      "away": "QNU",
      "score": [
        1,
        2
      ],
      "source": "vl2r8",
      "date": "2026-11-22",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        1,
        3
      ],
      "red": [
        0,
        0
      ],
      "venue": "Bà Rịa",
      "attendance": 1000,
      "status": "final"
    },
    "vl2-8-KKH-HYE": {
      "id": "vl2-8-KKH-HYE",
      "league": "vl2",
      "round": 8,
      "home": "KKH",
      "away": "HYE",
      "score": [
        1,
        3
      ],
      "source": "vl2r8",
      "date": "2026-11-22",
      "time": "17:00",
      "timingSource": "archive",
      "yellow": [
        2,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "19/8 Nha Trang",
      "attendance": 3000,
      "status": "final"
    },
    "vl2-8-CND-TCT": {
      "id": "vl2-8-CND-TCT",
      "league": "vl2",
      "round": 8,
      "home": "CND",
      "away": "TCT",
      "score": [
        2,
        1
      ],
      "source": "vl2r8",
      "date": "2026-11-22",
      "time": "18:00",
      "timingSource": "archive",
      "yellow": [
        1,
        1
      ],
      "red": [
        0,
        0
      ],
      "venue": "PVF",
      "attendance": 2500,
      "status": "final"
    },
    "vl2-9-HUE-LAN": {
      "id": "vl2-9-HUE-LAN",
      "league": "vl2",
      "round": 9,
      "home": "HUE",
      "away": "LAN",
      "score": null,
      "source": "r9",
      "date": "2026-11-27",
      "time": "15:30",
      "venue": "Tự Do",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl2-9-TNG-HYE": {
      "id": "vl2-9-TNG-HYE",
      "league": "vl2",
      "round": 9,
      "home": "TNG",
      "away": "HYE",
      "score": null,
      "source": "r9",
      "date": "2026-11-27",
      "time": "18:00",
      "venue": "Thái Nguyên",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl2-9-CND-VHI": {
      "id": "vl2-9-CND-VHI",
      "league": "vl2",
      "round": 9,
      "home": "CND",
      "away": "VHI",
      "score": null,
      "source": "r9",
      "date": "2026-11-27",
      "time": "18:00",
      "venue": "PVF",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl2-9-XPT-LDO": {
      "id": "vl2-9-XPT-LDO",
      "league": "vl2",
      "round": 9,
      "home": "XPT",
      "away": "LDO",
      "score": null,
      "source": "r9",
      "date": "2026-11-27",
      "time": "18:00",
      "venue": "Việt Trì",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl2-9-BMS-BEC": {
      "id": "vl2-9-BMS-BEC",
      "league": "vl2",
      "round": 9,
      "home": "BMS",
      "away": "BEC",
      "score": null,
      "source": "r9",
      "date": "2026-11-28",
      "time": "17:00",
      "venue": "Bà Rịa",
      "broadcast": "FPT Play, Ứng dụng HTV",
      "timingSource": "r9",
      "status": "scheduled",
      "changed": true
    },
    "vl2-9-TCT-TPH": {
      "id": "vl2-9-TCT-TPH",
      "league": "vl2",
      "round": 9,
      "home": "TCT",
      "away": "TPH",
      "score": null,
      "source": "r9",
      "date": "2026-11-28",
      "time": "18:00",
      "venue": "Cần Thơ",
      "broadcast": "FPT Play, Ứng dụng HTV",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl2-9-QNU-KKH": {
      "id": "vl2-9-QNU-KKH",
      "league": "vl2",
      "round": 9,
      "home": "QNU",
      "away": "KKH",
      "score": null,
      "source": "r9",
      "date": "2026-11-28",
      "time": "18:00",
      "venue": "Quy Nhơn",
      "broadcast": "FPT Play, TV360",
      "timingSource": "r9",
      "status": "scheduled"
    },
    "vl2-10-HUE-CND": {
      "id": "vl2-10-HUE-CND",
      "league": "vl2",
      "round": 10,
      "home": "HUE",
      "away": "CND",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-01",
      "time": "15:30",
      "status": "provisional",
      "venue": null
    },
    "vl2-10-LAN-LDO": {
      "id": "vl2-10-LAN-LDO",
      "league": "vl2",
      "round": 10,
      "home": "LAN",
      "away": "LDO",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-01",
      "time": "15:30",
      "status": "provisional",
      "venue": null
    },
    "vl2-10-TNG-XPT": {
      "id": "vl2-10-TNG-XPT",
      "league": "vl2",
      "round": 10,
      "home": "TNG",
      "away": "XPT",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-01",
      "time": "18:00",
      "status": "provisional",
      "venue": null
    },
    "vl2-10-HYE-VHI": {
      "id": "vl2-10-HYE-VHI",
      "league": "vl2",
      "round": 10,
      "home": "HYE",
      "away": "VHI",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-01",
      "time": "18:00",
      "status": "provisional",
      "venue": null
    },
    "vl2-10-BMS-TCT": {
      "id": "vl2-10-BMS-TCT",
      "league": "vl2",
      "round": 10,
      "home": "BMS",
      "away": "TCT",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-02",
      "time": "17:00",
      "status": "provisional",
      "venue": null
    },
    "vl2-10-KKH-TPH": {
      "id": "vl2-10-KKH-TPH",
      "league": "vl2",
      "round": 10,
      "home": "KKH",
      "away": "TPH",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-02",
      "time": "17:00",
      "status": "provisional",
      "venue": null
    },
    "vl2-10-QNU-BEC": {
      "id": "vl2-10-QNU-BEC",
      "league": "vl2",
      "round": 10,
      "home": "QNU",
      "away": "BEC",
      "score": null,
      "source": "v2ref",
      "pairSource": "archive",
      "date": "2026-12-02",
      "time": "18:00",
      "status": "provisional",
      "venue": null
    },
    "vl2-11-LDO-HYE": {
      "id": "vl2-11-LDO-HYE",
      "league": "vl2",
      "round": 11,
      "home": "LDO",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-11-VHI-LAN": {
      "id": "vl2-11-VHI-LAN",
      "league": "vl2",
      "round": 11,
      "home": "VHI",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-11-XPT-HUE": {
      "id": "vl2-11-XPT-HUE",
      "league": "vl2",
      "round": 11,
      "home": "XPT",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-11-CND-TNG": {
      "id": "vl2-11-CND-TNG",
      "league": "vl2",
      "round": 11,
      "home": "CND",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-11-TPH-BMS": {
      "id": "vl2-11-TPH-BMS",
      "league": "vl2",
      "round": 11,
      "home": "TPH",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-11-TCT-QNU": {
      "id": "vl2-11-TCT-QNU",
      "league": "vl2",
      "round": 11,
      "home": "TCT",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-11-BEC-KKH": {
      "id": "vl2-11-BEC-KKH",
      "league": "vl2",
      "round": 11,
      "home": "BEC",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-VHI-TCT": {
      "id": "vl2-12-VHI-TCT",
      "league": "vl2",
      "round": 12,
      "home": "VHI",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-HUE-LDO": {
      "id": "vl2-12-HUE-LDO",
      "league": "vl2",
      "round": 12,
      "home": "HUE",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-XPT-BMS": {
      "id": "vl2-12-XPT-BMS",
      "league": "vl2",
      "round": 12,
      "home": "XPT",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-TPH-LAN": {
      "id": "vl2-12-TPH-LAN",
      "league": "vl2",
      "round": 12,
      "home": "TPH",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-TNG-KKH": {
      "id": "vl2-12-TNG-KKH",
      "league": "vl2",
      "round": 12,
      "home": "TNG",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-BEC-HYE": {
      "id": "vl2-12-BEC-HYE",
      "league": "vl2",
      "round": 12,
      "home": "BEC",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-12-CND-QNU": {
      "id": "vl2-12-CND-QNU",
      "league": "vl2",
      "round": 12,
      "home": "CND",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-LDO-TNG": {
      "id": "vl2-13-LDO-TNG",
      "league": "vl2",
      "round": 13,
      "home": "LDO",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-BMS-CND": {
      "id": "vl2-13-BMS-CND",
      "league": "vl2",
      "round": 13,
      "home": "BMS",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-QNU-XPT": {
      "id": "vl2-13-QNU-XPT",
      "league": "vl2",
      "round": 13,
      "home": "QNU",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-LAN-BEC": {
      "id": "vl2-13-LAN-BEC",
      "league": "vl2",
      "round": 13,
      "home": "LAN",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-KKH-VHI": {
      "id": "vl2-13-KKH-VHI",
      "league": "vl2",
      "round": 13,
      "home": "KKH",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-TCT-HUE": {
      "id": "vl2-13-TCT-HUE",
      "league": "vl2",
      "round": 13,
      "home": "TCT",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-13-HYE-TPH": {
      "id": "vl2-13-HYE-TPH",
      "league": "vl2",
      "round": 13,
      "home": "HYE",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-LAN-HYE": {
      "id": "vl2-14-LAN-HYE",
      "league": "vl2",
      "round": 14,
      "home": "LAN",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-BMS-VHI": {
      "id": "vl2-14-BMS-VHI",
      "league": "vl2",
      "round": 14,
      "home": "BMS",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-LDO-QNU": {
      "id": "vl2-14-LDO-QNU",
      "league": "vl2",
      "round": 14,
      "home": "LDO",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-TNG-BEC": {
      "id": "vl2-14-TNG-BEC",
      "league": "vl2",
      "round": 14,
      "home": "TNG",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-CND-XPT": {
      "id": "vl2-14-CND-XPT",
      "league": "vl2",
      "round": 14,
      "home": "CND",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-TPH-HUE": {
      "id": "vl2-14-TPH-HUE",
      "league": "vl2",
      "round": 14,
      "home": "TPH",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-14-TCT-KKH": {
      "id": "vl2-14-TCT-KKH",
      "league": "vl2",
      "round": 14,
      "home": "TCT",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-VHI-LDO": {
      "id": "vl2-15-VHI-LDO",
      "league": "vl2",
      "round": 15,
      "home": "VHI",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-BEC-TPH": {
      "id": "vl2-15-BEC-TPH",
      "league": "vl2",
      "round": 15,
      "home": "BEC",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-HUE-TNG": {
      "id": "vl2-15-HUE-TNG",
      "league": "vl2",
      "round": 15,
      "home": "HUE",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-XPT-TCT": {
      "id": "vl2-15-XPT-TCT",
      "league": "vl2",
      "round": 15,
      "home": "XPT",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-QNU-BMS": {
      "id": "vl2-15-QNU-BMS",
      "league": "vl2",
      "round": 15,
      "home": "QNU",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-KKH-LAN": {
      "id": "vl2-15-KKH-LAN",
      "league": "vl2",
      "round": 15,
      "home": "KKH",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-15-HYE-CND": {
      "id": "vl2-15-HYE-CND",
      "league": "vl2",
      "round": 15,
      "home": "HYE",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-BMS-XPT": {
      "id": "vl2-16-BMS-XPT",
      "league": "vl2",
      "round": 16,
      "home": "BMS",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-QNU-CND": {
      "id": "vl2-16-QNU-CND",
      "league": "vl2",
      "round": 16,
      "home": "QNU",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-LAN-TPH": {
      "id": "vl2-16-LAN-TPH",
      "league": "vl2",
      "round": 16,
      "home": "LAN",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-KKH-TNG": {
      "id": "vl2-16-KKH-TNG",
      "league": "vl2",
      "round": 16,
      "home": "KKH",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-TCT-VHI": {
      "id": "vl2-16-TCT-VHI",
      "league": "vl2",
      "round": 16,
      "home": "TCT",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-LDO-HUE": {
      "id": "vl2-16-LDO-HUE",
      "league": "vl2",
      "round": 16,
      "home": "LDO",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-16-HYE-BEC": {
      "id": "vl2-16-HYE-BEC",
      "league": "vl2",
      "round": 16,
      "home": "HYE",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-TPH-HYE": {
      "id": "vl2-17-TPH-HYE",
      "league": "vl2",
      "round": 17,
      "home": "TPH",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-XPT-QNU": {
      "id": "vl2-17-XPT-QNU",
      "league": "vl2",
      "round": 17,
      "home": "XPT",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-HUE-TCT": {
      "id": "vl2-17-HUE-TCT",
      "league": "vl2",
      "round": 17,
      "home": "HUE",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-CND-BMS": {
      "id": "vl2-17-CND-BMS",
      "league": "vl2",
      "round": 17,
      "home": "CND",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-TNG-LDO": {
      "id": "vl2-17-TNG-LDO",
      "league": "vl2",
      "round": 17,
      "home": "TNG",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-VHI-KKH": {
      "id": "vl2-17-VHI-KKH",
      "league": "vl2",
      "round": 17,
      "home": "VHI",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-17-BEC-LAN": {
      "id": "vl2-17-BEC-LAN",
      "league": "vl2",
      "round": 17,
      "home": "BEC",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-LDO-XPT": {
      "id": "vl2-18-LDO-XPT",
      "league": "vl2",
      "round": 18,
      "home": "LDO",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-VHI-CND": {
      "id": "vl2-18-VHI-CND",
      "league": "vl2",
      "round": 18,
      "home": "VHI",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-LAN-HUE": {
      "id": "vl2-18-LAN-HUE",
      "league": "vl2",
      "round": 18,
      "home": "LAN",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-KKH-QNU": {
      "id": "vl2-18-KKH-QNU",
      "league": "vl2",
      "round": 18,
      "home": "KKH",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-HYE-TNG": {
      "id": "vl2-18-HYE-TNG",
      "league": "vl2",
      "round": 18,
      "home": "HYE",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-TPH-TCT": {
      "id": "vl2-18-TPH-TCT",
      "league": "vl2",
      "round": 18,
      "home": "TPH",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-18-BEC-BMS": {
      "id": "vl2-18-BEC-BMS",
      "league": "vl2",
      "round": 18,
      "home": "BEC",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-BMS-LDO": {
      "id": "vl2-19-BMS-LDO",
      "league": "vl2",
      "round": 19,
      "home": "BMS",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-TCT-CND": {
      "id": "vl2-19-TCT-CND",
      "league": "vl2",
      "round": 19,
      "home": "TCT",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-HUE-BEC": {
      "id": "vl2-19-HUE-BEC",
      "league": "vl2",
      "round": 19,
      "home": "HUE",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-TNG-TPH": {
      "id": "vl2-19-TNG-TPH",
      "league": "vl2",
      "round": 19,
      "home": "TNG",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-LAN-XPT": {
      "id": "vl2-19-LAN-XPT",
      "league": "vl2",
      "round": 19,
      "home": "LAN",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-QNU-VHI": {
      "id": "vl2-19-QNU-VHI",
      "league": "vl2",
      "round": 19,
      "home": "QNU",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-19-HYE-KKH": {
      "id": "vl2-19-HYE-KKH",
      "league": "vl2",
      "round": 19,
      "home": "HYE",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-BMS-LAN": {
      "id": "vl2-20-BMS-LAN",
      "league": "vl2",
      "round": 20,
      "home": "BMS",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-XPT-TPH": {
      "id": "vl2-20-XPT-TPH",
      "league": "vl2",
      "round": 20,
      "home": "XPT",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-HUE-VHI": {
      "id": "vl2-20-HUE-VHI",
      "league": "vl2",
      "round": 20,
      "home": "HUE",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-QNU-HYE": {
      "id": "vl2-20-QNU-HYE",
      "league": "vl2",
      "round": 20,
      "home": "QNU",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-KKH-LDO": {
      "id": "vl2-20-KKH-LDO",
      "league": "vl2",
      "round": 20,
      "home": "KKH",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-TNG-TCT": {
      "id": "vl2-20-TNG-TCT",
      "league": "vl2",
      "round": 20,
      "home": "TNG",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-20-CND-BEC": {
      "id": "vl2-20-CND-BEC",
      "league": "vl2",
      "round": 20,
      "home": "CND",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-LAN-QNU": {
      "id": "vl2-21-LAN-QNU",
      "league": "vl2",
      "round": 21,
      "home": "LAN",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-VHI-TNG": {
      "id": "vl2-21-VHI-TNG",
      "league": "vl2",
      "round": 21,
      "home": "VHI",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-LDO-TCT": {
      "id": "vl2-21-LDO-TCT",
      "league": "vl2",
      "round": 21,
      "home": "LDO",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-KKH-HUE": {
      "id": "vl2-21-KKH-HUE",
      "league": "vl2",
      "round": 21,
      "home": "KKH",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-BEC-XPT": {
      "id": "vl2-21-BEC-XPT",
      "league": "vl2",
      "round": 21,
      "home": "BEC",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-TPH-CND": {
      "id": "vl2-21-TPH-CND",
      "league": "vl2",
      "round": 21,
      "home": "TPH",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-21-HYE-BMS": {
      "id": "vl2-21-HYE-BMS",
      "league": "vl2",
      "round": 21,
      "home": "HYE",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-HUE-HYE": {
      "id": "vl2-22-HUE-HYE",
      "league": "vl2",
      "round": 22,
      "home": "HUE",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-BMS-KKH": {
      "id": "vl2-22-BMS-KKH",
      "league": "vl2",
      "round": 22,
      "home": "BMS",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-QNU-TPH": {
      "id": "vl2-22-QNU-TPH",
      "league": "vl2",
      "round": 22,
      "home": "QNU",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-XPT-VHI": {
      "id": "vl2-22-XPT-VHI",
      "league": "vl2",
      "round": 22,
      "home": "XPT",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-TNG-LAN": {
      "id": "vl2-22-TNG-LAN",
      "league": "vl2",
      "round": 22,
      "home": "TNG",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-TCT-BEC": {
      "id": "vl2-22-TCT-BEC",
      "league": "vl2",
      "round": 22,
      "home": "TCT",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-22-CND-LDO": {
      "id": "vl2-22-CND-LDO",
      "league": "vl2",
      "round": 22,
      "home": "CND",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-LDO-LAN": {
      "id": "vl2-23-LDO-LAN",
      "league": "vl2",
      "round": 23,
      "home": "LDO",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-VHI-HYE": {
      "id": "vl2-23-VHI-HYE",
      "league": "vl2",
      "round": 23,
      "home": "VHI",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-TPH-KKH": {
      "id": "vl2-23-TPH-KKH",
      "league": "vl2",
      "round": 23,
      "home": "TPH",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-XPT-TNG": {
      "id": "vl2-23-XPT-TNG",
      "league": "vl2",
      "round": 23,
      "home": "XPT",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-BEC-QNU": {
      "id": "vl2-23-BEC-QNU",
      "league": "vl2",
      "round": 23,
      "home": "BEC",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-TCT-BMS": {
      "id": "vl2-23-TCT-BMS",
      "league": "vl2",
      "round": 23,
      "home": "TCT",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-23-CND-HUE": {
      "id": "vl2-23-CND-HUE",
      "league": "vl2",
      "round": 23,
      "home": "CND",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-HUE-XPT": {
      "id": "vl2-24-HUE-XPT",
      "league": "vl2",
      "round": 24,
      "home": "HUE",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-BMS-TPH": {
      "id": "vl2-24-BMS-TPH",
      "league": "vl2",
      "round": 24,
      "home": "BMS",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-LAN-VHI": {
      "id": "vl2-24-LAN-VHI",
      "league": "vl2",
      "round": 24,
      "home": "LAN",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-KKH-BEC": {
      "id": "vl2-24-KKH-BEC",
      "league": "vl2",
      "round": 24,
      "home": "KKH",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-QNU-TCT": {
      "id": "vl2-24-QNU-TCT",
      "league": "vl2",
      "round": 24,
      "home": "QNU",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-TNG-CND": {
      "id": "vl2-24-TNG-CND",
      "league": "vl2",
      "round": 24,
      "home": "TNG",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-24-HYE-LDO": {
      "id": "vl2-24-HYE-LDO",
      "league": "vl2",
      "round": 24,
      "home": "HYE",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-LDO-BEC": {
      "id": "vl2-25-LDO-BEC",
      "league": "vl2",
      "round": 25,
      "home": "LDO",
      "away": "BEC",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-HUE-QNU": {
      "id": "vl2-25-HUE-QNU",
      "league": "vl2",
      "round": 25,
      "home": "HUE",
      "away": "QNU",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-VHI-TPH": {
      "id": "vl2-25-VHI-TPH",
      "league": "vl2",
      "round": 25,
      "home": "VHI",
      "away": "TPH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-XPT-HYE": {
      "id": "vl2-25-XPT-HYE",
      "league": "vl2",
      "round": 25,
      "home": "XPT",
      "away": "HYE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-TCT-LAN": {
      "id": "vl2-25-TCT-LAN",
      "league": "vl2",
      "round": 25,
      "home": "TCT",
      "away": "LAN",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-TNG-BMS": {
      "id": "vl2-25-TNG-BMS",
      "league": "vl2",
      "round": 25,
      "home": "TNG",
      "away": "BMS",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-25-CND-KKH": {
      "id": "vl2-25-CND-KKH",
      "league": "vl2",
      "round": 25,
      "home": "CND",
      "away": "KKH",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-BMS-HUE": {
      "id": "vl2-26-BMS-HUE",
      "league": "vl2",
      "round": 26,
      "home": "BMS",
      "away": "HUE",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-LAN-CND": {
      "id": "vl2-26-LAN-CND",
      "league": "vl2",
      "round": 26,
      "home": "LAN",
      "away": "CND",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-TPH-LDO": {
      "id": "vl2-26-TPH-LDO",
      "league": "vl2",
      "round": 26,
      "home": "TPH",
      "away": "LDO",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-KKH-XPT": {
      "id": "vl2-26-KKH-XPT",
      "league": "vl2",
      "round": 26,
      "home": "KKH",
      "away": "XPT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-QNU-TNG": {
      "id": "vl2-26-QNU-TNG",
      "league": "vl2",
      "round": 26,
      "home": "QNU",
      "away": "TNG",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-BEC-VHI": {
      "id": "vl2-26-BEC-VHI",
      "league": "vl2",
      "round": 26,
      "home": "BEC",
      "away": "VHI",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "vl2-26-HYE-TCT": {
      "id": "vl2-26-HYE-TCT",
      "league": "vl2",
      "round": 26,
      "home": "HYE",
      "away": "TCT",
      "score": null,
      "source": "plan",
      "pairSource": "archive",
      "status": "tbd"
    },
    "nc-1": {
      "id": "nc-1",
      "league": "nc",
      "round": 1,
      "tie": "1",
      "leg": 1,
      "home": "DNC",
      "away": "BMS",
      "score": [
        4,
        3
      ],
      "source": "cupcal",
      "number": "1",
      "date": "2026-10-06",
      "time": "18:00",
      "venue": "Bình Phước",
      "broadcast": "FPT Play, TV360",
      "attendance": 3000,
      "timingSource": "cupcal",
      "status": "final"
    },
    "nc-2": {
      "id": "nc-2",
      "league": "nc",
      "round": 1,
      "tie": "2",
      "leg": 1,
      "home": "LAN",
      "away": "BNI",
      "score": [
        2,
        3
      ],
      "source": "cupcal",
      "number": "2",
      "date": "2026-09-19",
      "time": "16:00",
      "venue": "Long An",
      "broadcast": "FPT Play, TV360",
      "attendance": 1000,
      "timingSource": "cupcal",
      "goals": [
        [],
        [
          "Brenner Marlos",
          " Brenner Marlos",
          " Brenner Marlos"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "nc-3": {
      "id": "nc-3",
      "league": "nc",
      "round": 1,
      "tie": "3",
      "leg": 1,
      "home": "KKH",
      "away": "VHI",
      "score": [
        1,
        1
      ],
      "source": "cupcal",
      "number": "3",
      "date": "2026-09-19",
      "time": "17:00",
      "venue": "19/8 Nha Trang",
      "penalties": [
        2,
        3
      ],
      "broadcast": "FPT Play, TV360",
      "attendance": 2000,
      "timingSource": "cupcal",
      "status": "final"
    },
    "nc-4": {
      "id": "nc-4",
      "league": "nc",
      "round": 1,
      "tie": "4",
      "leg": 1,
      "home": "THA",
      "away": "BEC",
      "score": [
        0,
        2
      ],
      "source": "cupcal",
      "number": "4",
      "date": "2026-09-19",
      "time": "17:00",
      "venue": "Thanh Hóa",
      "broadcast": "FPT Play, HTV Thể thao, TV360, MyTV",
      "attendance": 700,
      "timingSource": "cupcal",
      "goals": [
        [],
        [
          "Dos Anjos",
          " Nguyễn Trần Việt Cường"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "nc-5": {
      "id": "nc-5",
      "league": "nc",
      "round": 1,
      "tie": "5",
      "leg": 1,
      "home": "QNU",
      "away": "TPH",
      "score": [
        1,
        1
      ],
      "source": "cupcal",
      "number": "5",
      "date": "2026-09-18",
      "time": "18:00",
      "venue": "Quy Nhơn",
      "penalties": [
        3,
        4
      ],
      "broadcast": "FPT Play, HTV Thể thao, TV360, MyTV",
      "attendance": 1000,
      "timingSource": "cupcal",
      "status": "final"
    },
    "nc-6": {
      "id": "nc-6",
      "league": "nc",
      "round": 1,
      "tie": "6",
      "leg": 1,
      "home": "XPT",
      "away": "HLH",
      "score": [
        0,
        0
      ],
      "source": "cupcal",
      "number": "6",
      "date": "2026-09-20",
      "time": "18:00",
      "venue": "Việt Trì",
      "penalties": [
        3,
        2
      ],
      "broadcast": "FPT Play, TV360",
      "attendance": 1000,
      "timingSource": "cupcal",
      "status": "final"
    },
    "nc-7": {
      "id": "nc-7",
      "league": "nc",
      "round": 1,
      "tie": "7",
      "leg": 1,
      "home": "HNO",
      "away": "DNA",
      "score": [
        1,
        1
      ],
      "source": "cupcal",
      "number": "7",
      "date": "2026-09-20",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "penalties": [
        3,
        4
      ],
      "broadcast": "FPT Play, HTV Thể thao, TV360, MyTV",
      "attendance": 4500,
      "timingSource": "cupcal",
      "status": "final"
    },
    "nc-8": {
      "id": "nc-8",
      "league": "nc",
      "round": 1,
      "tie": "8",
      "leg": 1,
      "home": "HPH",
      "away": "TCT",
      "score": [
        0,
        1
      ],
      "source": "cupcal",
      "number": "8",
      "date": "2026-09-20",
      "time": "18:00",
      "venue": "Lạch Tray",
      "broadcast": "FPT Play, TV360",
      "attendance": 2500,
      "timingSource": "cupcal",
      "status": "final"
    },
    "nc-9": {
      "id": "nc-9",
      "league": "nc",
      "round": 1,
      "tie": "9",
      "leg": 1,
      "home": "LDO",
      "away": "SLN",
      "score": [
        0,
        2
      ],
      "source": "cupcal",
      "number": "9",
      "date": "2026-10-06",
      "time": "15:30",
      "venue": "Đà Lạt",
      "broadcast": "FPT Play, TV360",
      "attendance": 3000,
      "timingSource": "cupcal",
      "goals": [
        [],
        [
          "Văn Lắm 85'",
          " Bruno 90+'"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "nc-10": {
      "id": "nc-10",
      "league": "nc",
      "round": 1,
      "tie": "10",
      "leg": 1,
      "home": "CND",
      "away": "HUE",
      "score": [
        4,
        1
      ],
      "source": "cupcal",
      "number": "10",
      "date": "2026-10-06",
      "time": "18:00",
      "venue": "PVF",
      "broadcast": "FPT Play, TV360",
      "attendance": 800,
      "timingSource": "cupcal",
      "goals": [
        [
          "Minh Vương",
          " Phi Long",
          " Gonzalo Schnorr Fornari",
          " Bá Đạt"
        ],
        [
          "Anh Vũ 85'"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "nc-11": {
      "id": "nc-11",
      "league": "nc",
      "round": 1,
      "tie": "11",
      "leg": 1,
      "home": "HAG",
      "away": "HYE",
      "score": [
        2,
        3
      ],
      "source": "cupcal",
      "number": "11",
      "date": "2026-09-20",
      "time": "17:00",
      "venue": "Quy Nhơn",
      "broadcast": "FPT Play",
      "attendance": 1500,
      "timingSource": "cupcal",
      "goals": [
        [
          "Lucas 62'"
        ],
        [
          "Đăng Dương 55'",
          " Khalio",
          " Khalio"
        ]
      ],
      "goalsSource": "archive",
      "status": "final"
    },
    "nc-12": {
      "id": "nc-12",
      "league": "nc",
      "round": 2,
      "tie": "12",
      "leg": 1,
      "home": "CAH",
      "away": "DNC",
      "score": null,
      "source": "cupcal",
      "number": "12",
      "date": "2027-01-19",
      "time": "19:15",
      "venue": "Hàng Đẫy",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-19",
            "time": "19:15",
            "venue": "Hàng Đẫy",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-13": {
      "id": "nc-13",
      "league": "nc",
      "round": 2,
      "tie": "13",
      "leg": 1,
      "home": "BNI",
      "away": "VHI",
      "score": null,
      "source": "cupcal",
      "number": "13",
      "date": "2027-01-02",
      "time": "18:00",
      "venue": "Việt Yên",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-02",
            "time": "18:00",
            "venue": "Việt Yên",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-14": {
      "id": "nc-14",
      "league": "nc",
      "round": 2,
      "tie": "14",
      "leg": 1,
      "home": "HCM",
      "away": "BEC",
      "score": null,
      "source": "cupcal",
      "number": "14",
      "date": "2027-01-03",
      "time": "18:00",
      "venue": "Bình Dương",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-03",
            "time": "18:00",
            "venue": "Bình Dương",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-15": {
      "id": "nc-15",
      "league": "nc",
      "round": 2,
      "tie": "15",
      "leg": 1,
      "home": "TCV",
      "away": "TPH",
      "score": null,
      "source": "cupcal",
      "number": "15",
      "date": "2027-01-03",
      "time": "19:15",
      "venue": "Mỹ Đình",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-03",
            "time": "19:15",
            "venue": "Mỹ Đình",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-16": {
      "id": "nc-16",
      "league": "nc",
      "round": 2,
      "tie": "16",
      "leg": 1,
      "home": "NDI",
      "away": "XPT",
      "score": null,
      "source": "cupcal",
      "number": "16",
      "date": "2027-01-02",
      "time": "18:00",
      "venue": "Thiên Trường",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-02",
            "time": "18:00",
            "venue": "Thiên Trường",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-17": {
      "id": "nc-17",
      "league": "nc",
      "round": 2,
      "tie": "17",
      "leg": 1,
      "home": "DNA",
      "away": "TCT",
      "score": null,
      "source": "cupcal",
      "number": "17",
      "date": "2027-01-03",
      "time": "18:00",
      "venue": "Chi Lăng",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-03",
            "time": "18:00",
            "venue": "Chi Lăng",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-18": {
      "id": "nc-18",
      "league": "nc",
      "round": 2,
      "tie": "18",
      "leg": 1,
      "home": "SLN",
      "away": "CND",
      "score": null,
      "source": "cupcal",
      "number": "18",
      "date": "2027-01-02",
      "time": "18:00",
      "venue": "Vinh",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-02",
            "time": "18:00",
            "venue": "Vinh",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-19": {
      "id": "nc-19",
      "league": "nc",
      "round": 2,
      "tie": "19",
      "leg": 1,
      "home": "NBI",
      "away": "HYE",
      "score": null,
      "source": "cupcal",
      "number": "19",
      "date": "2027-01-03",
      "time": "18:00",
      "venue": "Ninh Bình",
      "timingSource": "cupcal",
      "changed": true,
      "status": "scheduled",
      "history": [
        {
          "at": "2026-11-21T00:00:00+07:00",
          "beforeLabel": "Dự kiến 12–14/02/2027, chưa có giờ đá từng trận.",
          "beforeSource": "cupOriginalWindow",
          "after": {
            "date": "2027-01-03",
            "time": "18:00",
            "venue": "Ninh Bình",
            "status": "scheduled"
          },
          "source": "plan"
        }
      ]
    },
    "nc-20": {
      "id": "nc-20",
      "league": "nc",
      "round": 3,
      "tie": "20",
      "leg": 1,
      "home": "@12",
      "away": "@13",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-21": {
      "id": "nc-21",
      "league": "nc",
      "round": 3,
      "tie": "21",
      "leg": 1,
      "home": "@14",
      "away": "@15",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-22": {
      "id": "nc-22",
      "league": "nc",
      "round": 3,
      "tie": "22",
      "leg": 1,
      "home": "@16",
      "away": "@17",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-23": {
      "id": "nc-23",
      "league": "nc",
      "round": 3,
      "tie": "23",
      "leg": 1,
      "home": "@18",
      "away": "@19",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-24-1": {
      "id": "nc-24-1",
      "league": "nc",
      "round": 4,
      "tie": "24",
      "leg": 1,
      "home": "@20",
      "away": "@21",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-24-2": {
      "id": "nc-24-2",
      "league": "nc",
      "round": 4,
      "tie": "24",
      "leg": 2,
      "home": "@21",
      "away": "@20",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-25-1": {
      "id": "nc-25-1",
      "league": "nc",
      "round": 4,
      "tie": "25",
      "leg": 1,
      "home": "@22",
      "away": "@23",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-25-2": {
      "id": "nc-25-2",
      "league": "nc",
      "round": 4,
      "tie": "25",
      "leg": 2,
      "home": "@23",
      "away": "@22",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-26-1": {
      "id": "nc-26-1",
      "league": "nc",
      "round": 5,
      "tie": "26",
      "leg": 1,
      "home": "@24",
      "away": "@25",
      "score": null,
      "source": "plan",
      "status": "tbd"
    },
    "nc-26-2": {
      "id": "nc-26-2",
      "league": "nc",
      "round": 5,
      "tie": "26",
      "leg": 2,
      "home": "@25",
      "away": "@24",
      "score": null,
      "source": "plan",
      "status": "tbd"
    }
  },
  "ties": {
    "1": {
      "round": 1,
      "slots": [
        "DNC",
        "BMS"
      ],
      "legs": 1
    },
    "2": {
      "round": 1,
      "slots": [
        "LAN",
        "BNI"
      ],
      "legs": 1
    },
    "3": {
      "round": 1,
      "slots": [
        "KKH",
        "VHI"
      ],
      "legs": 1
    },
    "4": {
      "round": 1,
      "slots": [
        "THA",
        "BEC"
      ],
      "legs": 1
    },
    "5": {
      "round": 1,
      "slots": [
        "QNU",
        "TPH"
      ],
      "legs": 1
    },
    "6": {
      "round": 1,
      "slots": [
        "XPT",
        "HLH"
      ],
      "legs": 1
    },
    "7": {
      "round": 1,
      "slots": [
        "HNO",
        "DNA"
      ],
      "legs": 1
    },
    "8": {
      "round": 1,
      "slots": [
        "HPH",
        "TCT"
      ],
      "legs": 1
    },
    "9": {
      "round": 1,
      "slots": [
        "LDO",
        "SLN"
      ],
      "legs": 1
    },
    "10": {
      "round": 1,
      "slots": [
        "CND",
        "HUE"
      ],
      "legs": 1
    },
    "11": {
      "round": 1,
      "slots": [
        "HAG",
        "HYE"
      ],
      "legs": 1
    },
    "12": {
      "round": 2,
      "slots": [
        "CAH",
        "@1"
      ],
      "legs": 1
    },
    "13": {
      "round": 2,
      "slots": [
        "@2",
        "@3"
      ],
      "legs": 1
    },
    "14": {
      "round": 2,
      "slots": [
        "HCM",
        "@4"
      ],
      "legs": 1
    },
    "15": {
      "round": 2,
      "slots": [
        "TCV",
        "@5"
      ],
      "legs": 1
    },
    "16": {
      "round": 2,
      "slots": [
        "NDI",
        "@6"
      ],
      "legs": 1
    },
    "17": {
      "round": 2,
      "slots": [
        "@7",
        "@8"
      ],
      "legs": 1
    },
    "18": {
      "round": 2,
      "slots": [
        "@9",
        "@10"
      ],
      "legs": 1
    },
    "19": {
      "round": 2,
      "slots": [
        "NBI",
        "@11"
      ],
      "legs": 1
    },
    "20": {
      "round": 3,
      "slots": [
        "@12",
        "@13"
      ],
      "legs": 1
    },
    "21": {
      "round": 3,
      "slots": [
        "@14",
        "@15"
      ],
      "legs": 1
    },
    "22": {
      "round": 3,
      "slots": [
        "@16",
        "@17"
      ],
      "legs": 1
    },
    "23": {
      "round": 3,
      "slots": [
        "@18",
        "@19"
      ],
      "legs": 1
    },
    "24": {
      "round": 4,
      "slots": [
        "@20",
        "@21"
      ],
      "legs": 2
    },
    "25": {
      "round": 4,
      "slots": [
        "@22",
        "@23"
      ],
      "legs": 2
    },
    "26": {
      "round": 5,
      "slots": [
        "@24",
        "@25"
      ],
      "legs": 2
    }
  },
  "standings": {
    "vl1": [
      [
        1,
        "NDI",
        8,
        6,
        1,
        1,
        18,
        7,
        11,
        19
      ],
      [
        2,
        "NBI",
        8,
        5,
        1,
        2,
        15,
        10,
        5,
        16
      ],
      [
        3,
        "SLN",
        8,
        3,
        5,
        0,
        13,
        7,
        6,
        14
      ],
      [
        4,
        "CAH",
        7,
        4,
        2,
        1,
        11,
        5,
        6,
        14
      ],
      [
        5,
        "HLH",
        8,
        4,
        2,
        2,
        12,
        10,
        2,
        14
      ],
      [
        6,
        "THA",
        8,
        3,
        3,
        2,
        11,
        11,
        0,
        12
      ],
      [
        7,
        "HNO",
        8,
        4,
        0,
        4,
        11,
        13,
        -2,
        12
      ],
      [
        8,
        "HPH",
        8,
        3,
        1,
        4,
        15,
        14,
        1,
        10
      ],
      [
        9,
        "HCM",
        8,
        3,
        1,
        4,
        8,
        8,
        0,
        10
      ],
      [
        10,
        "DNA",
        8,
        3,
        0,
        5,
        8,
        13,
        -5,
        9
      ],
      [
        11,
        "BNI",
        7,
        2,
        2,
        3,
        5,
        6,
        -1,
        8
      ],
      [
        12,
        "TCV",
        8,
        1,
        3,
        4,
        7,
        11,
        -4,
        6
      ],
      [
        13,
        "HAG",
        8,
        2,
        0,
        6,
        10,
        17,
        -7,
        6
      ],
      [
        14,
        "DNC",
        8,
        1,
        1,
        6,
        2,
        14,
        -12,
        4
      ]
    ],
    "vl2": [
      [
        1,
        "BEC",
        8,
        6,
        1,
        1,
        19,
        6,
        13,
        19
      ],
      [
        2,
        "HYE",
        8,
        5,
        2,
        1,
        23,
        7,
        16,
        17
      ],
      [
        3,
        "TNG",
        8,
        5,
        1,
        2,
        17,
        8,
        9,
        16
      ],
      [
        4,
        "TPH",
        8,
        5,
        1,
        2,
        11,
        6,
        5,
        16
      ],
      [
        5,
        "BMS",
        8,
        5,
        1,
        2,
        13,
        9,
        4,
        16
      ],
      [
        6,
        "CND",
        8,
        4,
        1,
        3,
        11,
        12,
        -1,
        13
      ],
      [
        7,
        "KKH",
        8,
        3,
        3,
        2,
        11,
        9,
        2,
        12
      ],
      [
        8,
        "VHI",
        8,
        3,
        2,
        3,
        8,
        9,
        -1,
        11
      ],
      [
        9,
        "QNU",
        8,
        2,
        3,
        3,
        10,
        9,
        1,
        9
      ],
      [
        10,
        "TCT",
        8,
        2,
        2,
        4,
        6,
        14,
        -8,
        8
      ],
      [
        11,
        "XPT",
        8,
        1,
        2,
        5,
        9,
        22,
        -13,
        5
      ],
      [
        12,
        "HUE",
        8,
        1,
        2,
        5,
        7,
        20,
        -13,
        5
      ],
      [
        13,
        "LAN",
        8,
        0,
        4,
        4,
        6,
        11,
        -5,
        4
      ],
      [
        14,
        "LDO",
        8,
        1,
        1,
        6,
        6,
        15,
        -9,
        4
      ]
    ]
  },
  "archive": {
    "vl1": [
      {
        "s": "2000-01",
        "n": 10,
        "c": "Sông Lam Nghệ An",
        "l": "Sông Lam Nghệ An",
        "k": "SLN",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "CA Hải Phòng",
            ""
          ],
          [
            "Công An TPHCM (cũ)",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thừa Thiên Huế",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Công An Hà Nội (cũ)",
            ""
          ]
        ],
        "p": [
          "Bình Định",
          "Đà Nẵng"
        ],
        "r": [
          "Đồng Tháp",
          "Khánh Hòa"
        ],
        "d": []
      },
      {
        "s": "2001-02",
        "n": 10,
        "c": "Cảng Sài Gòn",
        "l": "Công An TP.HCM",
        "k": "HCM",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "CA Hải Phòng",
            ""
          ],
          [
            "Ngân Hàng Đông Á",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thừa Thiên Huế",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Công An Hà Nội (cũ)",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ]
        ],
        "p": [
          "Đồng Tháp",
          "LG.ACB",
          "Hoàng Anh Gia Lai",
          "Gạch ĐTLA"
        ],
        "r": [
          "CA Hải Phòng",
          "Thừa Thiên Huế"
        ],
        "d": []
      },
      {
        "s": "2003",
        "n": 12,
        "c": "Hoàng Anh Gia Lai",
        "l": "Hoàng Anh Gia Lai",
        "k": "HAG",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "Ngân Hàng Đông Á",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Hàng Không VN",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ]
        ],
        "p": [
          "CA Hải Phòng",
          "Bình Dương"
        ],
        "r": [
          "Cảng Sài Gòn",
          "LG.ACB"
        ],
        "d": []
      },
      {
        "s": "2004",
        "n": 12,
        "c": "Hoàng Anh Gia Lai",
        "l": "Hoàng Anh Gia Lai",
        "k": "HAG",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Ngân Hàng Đông Á",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.HN.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ]
        ],
        "p": [
          "Cảng Sài Gòn",
          "Hoà Phát HN"
        ],
        "r": [
          "Ngân Hàng Đông Á",
          "Thể Công"
        ],
        "d": []
      },
      {
        "s": "2005",
        "n": 12,
        "c": "Gạch ĐTLA",
        "l": "Gạch Đồng Tâm Long An",
        "k": "",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.HN.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hoà Phát HN",
            ""
          ]
        ],
        "p": [
          "Khánh Hòa",
          "Tiền Giang"
        ],
        "r": [
          "Đồng Tháp"
        ],
        "d": []
      },
      {
        "s": "2006",
        "n": 13,
        "c": "Gạch ĐTLA",
        "l": "Gạch Đồng Tâm Long An",
        "k": "",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.HN.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hoà Phát HN",
            ""
          ],
          [
            "Tiền Giang",
            ""
          ]
        ],
        "p": [
          "Đồng Tháp",
          "Thừa Thiên Huế",
          "Thanh Hoá"
        ],
        "r": [
          "Hải Phòng",
          "Tiền Giang"
        ],
        "d": []
      },
      {
        "s": "2007",
        "n": 14,
        "c": "Bình Dương",
        "l": "Becamex Bình Dương",
        "k": "",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thừa Thiên Huế",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.HN.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hoà Phát HN",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ]
        ],
        "p": [
          "Hải Phòng",
          "Thể Công"
        ],
        "r": [
          "Đồng Tháp",
          "Thừa Thiên Huế"
        ],
        "d": []
      },
      {
        "s": "2008",
        "n": 14,
        "c": "Bình Dương",
        "l": "Becamex Bình Dương",
        "k": "",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.HN.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hoà Phát HN",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ]
        ],
        "p": [
          "Đồng Tháp",
          "Quân Khu 4",
          "Hà Nội T&T"
        ],
        "r": [
          "Bình Định",
          "LG.HN.ACB",
          "Hoà Phát HN"
        ],
        "d": []
      },
      {
        "s": "2009",
        "n": 14,
        "c": "Đà Nẵng",
        "l": "SHB Đà Nẵng",
        "k": "DNA",
        "t": [
          [
            "Cảng Sài Gòn",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Quân Khu 4",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ]
        ],
        "p": [
          "Vissai Ninh Bình",
          "Hoà Phát HN"
        ],
        "r": [
          "Cảng Sài Gòn",
          "Thanh Hoá"
        ],
        "d": []
      },
      {
        "s": "2010",
        "n": 14,
        "c": "Hà Nội T&T",
        "l": "Hà Nội FC",
        "k": "HNO",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Vissai Ninh Bình",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hoà Phát HN",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Navibank Sài Gòn",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ]
        ],
        "p": [
          "LG.HN.ACB"
        ],
        "r": [
          "Nam Định"
        ],
        "d": []
      },
      {
        "s": "2011",
        "n": 14,
        "c": "Sông Lam Nghệ An",
        "l": "Sông Lam Nghệ An",
        "k": "SLN",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Vissai Ninh Bình",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "LG.HN.ACB",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hoà Phát HN",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Navibank Sài Gòn",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ]
        ],
        "p": [
          "SG Xuân Thành",
          "Kienlongbank Kiên Giang"
        ],
        "r": [
          "LG.HN.ACB",
          "Gạch ĐTLA"
        ],
        "d": []
      },
      {
        "s": "2012",
        "n": 14,
        "c": "Đà Nẵng",
        "l": "SHB Đà Nẵng",
        "k": "DNA",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Vissai Ninh Bình",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Navibank Sài Gòn",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ],
          [
            "SG Xuân Thành",
            ""
          ],
          [
            "Kienlongbank Kiên Giang",
            ""
          ]
        ],
        "p": [
          "Gạch ĐTLA",
          "Đồng Nai"
        ],
        "r": [
          "Đồng Tháp"
        ],
        "d": [
          "Khánh Hòa",
          "Hà Nội FC",
          "Navibank Sài Gòn"
        ]
      },
      {
        "s": "2013",
        "n": 12,
        "c": "Hà Nội T&T",
        "l": "Hà Nội FC",
        "k": "HNO",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Vissai Ninh Bình",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ],
          [
            "SG Xuân Thành",
            ""
          ],
          [
            "Kienlongbank Kiên Giang",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ]
        ],
        "p": [
          "Hùng Vương AG",
          "Quảng Nam",
          "Than Quảng Ninh"
        ],
        "r": [],
        "d": [
          "SG Xuân Thành",
          "Kienlongbank Kiên Giang"
        ]
      },
      {
        "s": "2014",
        "n": 13,
        "c": "Bình Dương",
        "l": "Becamex Bình Dương",
        "k": "",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Vissai Ninh Bình",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Hùng Vương AG",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ]
        ],
        "p": [
          "Đồng Tháp",
          "Khánh Hòa",
          "XSKT Cần Thơ"
        ],
        "r": [],
        "d": [
          "Vissai Ninh Bình",
          "Hùng Vương AG"
        ]
      },
      {
        "s": "2015",
        "n": 14,
        "c": "Bình Dương",
        "l": "Becamex Bình Dương",
        "k": "",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ]
        ],
        "p": [
          "Sài Gòn FC"
        ],
        "r": [
          "Đồng Nai"
        ],
        "d": []
      },
      {
        "s": "2016",
        "n": 14,
        "c": "Hà Nội FC",
        "l": "Hà Nội FC",
        "k": "HNO",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Sài Gòn FC",
            ""
          ]
        ],
        "p": [
          "TPHCM"
        ],
        "r": [
          "Đồng Tháp"
        ],
        "d": []
      },
      {
        "s": "2017",
        "n": 14,
        "c": "Quảng Nam",
        "l": "Quảng Nam",
        "k": "",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Gạch ĐTLA",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Sài Gòn FC",
            ""
          ]
        ],
        "p": [
          "Nam Định"
        ],
        "r": [
          "Gạch ĐTLA"
        ],
        "d": []
      },
      {
        "s": "2018",
        "n": 14,
        "c": "Hà Nội FC",
        "l": "Hà Nội FC",
        "k": "HNO",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Sài Gòn FC",
            ""
          ]
        ],
        "p": [
          "Viettel"
        ],
        "r": [
          "XSKT Cần Thơ"
        ],
        "d": []
      },
      {
        "s": "2019",
        "n": 14,
        "c": "Hà Nội FC",
        "l": "Hà Nội FC",
        "k": "HNO",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "Sài Gòn FC",
            ""
          ]
        ],
        "p": [
          "Hồng Lĩnh Hà Tĩnh"
        ],
        "r": [
          "Khánh Hòa"
        ],
        "d": []
      },
      {
        "s": "2020",
        "n": 14,
        "c": "Viettel",
        "l": "Thể Công–Viettel",
        "k": "TCV",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "Sài Gòn FC",
            ""
          ],
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ]
        ],
        "p": [
          "Bình Định"
        ],
        "r": [
          "Quảng Nam"
        ],
        "d": [
          "Than Quảng Ninh"
        ]
      },
      {
        "s": "2022",
        "n": 13,
        "c": "Hà Nội FC",
        "l": "Hà Nội FC",
        "k": "HNO",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Sài Gòn FC",
            ""
          ],
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ]
        ],
        "p": [
          "Khánh Hòa",
          "Công An Nhân Dân"
        ],
        "r": [],
        "d": [
          "Sài Gòn FC"
        ]
      },
      {
        "s": "2023",
        "n": 14,
        "c": "Công An Hà Nội",
        "l": "Công An Hà Nội",
        "k": "CAH",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ],
          [
            "Công An Hà Nội",
            ""
          ]
        ],
        "p": [
          "Quảng Nam"
        ],
        "r": [
          "Đà Nẵng"
        ],
        "d": []
      },
      {
        "s": "2023-24",
        "n": 14,
        "c": "Nam Định",
        "l": "Thép Xanh Nam Định",
        "k": "NDI",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công–Viettel",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ],
          [
            "Công An Hà Nội",
            ""
          ]
        ],
        "p": [
          "Đà Nẵng"
        ],
        "r": [
          "Khánh Hòa"
        ],
        "d": []
      },
      {
        "s": "2024-25",
        "n": 14,
        "c": "Nam Định",
        "l": "Thép Xanh Nam Định",
        "k": "NDI",
        "t": [
          [
            "TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công–Viettel",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ],
          [
            "Công An Hà Nội",
            ""
          ]
        ],
        "p": [
          "Công An Nhân Dân FC",
          "Ninh Bình FC"
        ],
        "r": [
          "Bình Định"
        ],
        "d": [
          "Quảng Nam"
        ]
      },
      {
        "s": "2025-26",
        "n": 14,
        "c": "Công An Hà Nội",
        "l": "Công An Hà Nội",
        "k": "CAH",
        "t": [
          [
            "Công An TPHCM",
            ""
          ],
          [
            "Hải Phòng",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Sông Lam Nghệ An",
            ""
          ],
          [
            "Thể Công–Viettel",
            ""
          ],
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hoá",
            ""
          ],
          [
            "Hà Nội FC",
            ""
          ],
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ],
          [
            "Công An Hà Nội",
            ""
          ],
          [
            "Công An Nhân Dân FC",
            ""
          ],
          [
            "Ninh Bình FC",
            ""
          ]
        ],
        "p": [
          "Trường Tươi Bình Phước",
          "Bắc Ninh"
        ],
        "r": [
          "Bình Dương",
          "Công An Nhân Dân FC"
        ],
        "d": []
      }
    ],
    "vl2": [
      {
        "s": "2000-01",
        "n": 12,
        "c": "Bình Định",
        "l": "",
        "k": "",
        "t": [
          [
            "Đà Nẵng",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Hải Quan",
            ""
          ],
          [
            "Quân khu 7",
            ""
          ],
          [
            "Gia Lai",
            ""
          ],
          [
            "Tiền Giang",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Lâm Đồng",
            ""
          ],
          [
            "Ngân hàng Á Châu (ACB)",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2001-02",
        "n": 12,
        "c": "Gạch Đồng Tâm Long An",
        "l": "",
        "k": "",
        "t": [
          [
            "Gạch Đồng Tâm Long An",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Hoàng Anh Gia Lai",
            ""
          ],
          [
            "LG.ACB",
            ""
          ],
          [
            "Tiền Giang",
            ""
          ],
          [
            "Thanh Hóa",
            ""
          ],
          [
            "Lâm Đồng",
            ""
          ],
          [
            "Cần Thơ",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Quân khu 7",
            ""
          ],
          [
            "Hải Quan",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2003",
        "n": 12,
        "c": "Hải Phòng",
        "l": "",
        "k": "",
        "t": [
          [
            "Hải Phòng",
            ""
          ],
          [
            "Bình Dương",
            ""
          ],
          [
            "Thanh Hóa",
            ""
          ],
          [
            "Thừa Thiên Huế",
            ""
          ],
          [
            "Tiền Giang",
            ""
          ],
          [
            "Quân khu 7",
            ""
          ],
          [
            "Cần Thơ",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Quân khu 5",
            ""
          ],
          [
            "Bưu Điện",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Lâm Đồng",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2004",
        "n": 12,
        "c": "Cảng Sài Gòn",
        "l": "",
        "k": "",
        "t": [
          [
            "Thép Miền Nam – Cảng Sài Gòn",
            ""
          ],
          [
            "Hòa Phát Hà Nội",
            ""
          ],
          [
            "Thừa Thiên Huế",
            ""
          ],
          [
            "Khải Hoàn Q10 TP.HCM",
            ""
          ],
          [
            "Bưu Điện",
            ""
          ],
          [
            "Tiền Giang",
            ""
          ],
          [
            "Thanh Hóa",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Cần Thơ",
            ""
          ],
          [
            "Quân khu 5",
            ""
          ],
          [
            "Quân khu 7",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2005",
        "n": 12,
        "c": "Khatoco Khánh Hòa",
        "l": "",
        "k": "",
        "t": [
          [
            "Khatoco Khánh Hòa",
            ""
          ],
          [
            "Tiền Giang",
            ""
          ],
          [
            "NHĐA Thép Pomina",
            ""
          ],
          [
            "Tôn Hoa Sen Cần Thơ",
            ""
          ],
          [
            "Huda Huế",
            ""
          ],
          [
            "Thể Công",
            ""
          ],
          [
            "Thanh Hóa",
            ""
          ],
          [
            "Đá Mỹ Nghệ TP.HCM",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Strata Đồng Nai",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Bưu Điện",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2006",
        "n": 14,
        "c": "Đồng Tháp",
        "l": "",
        "k": "",
        "t": [
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Halida Thanh Hóa",
            ""
          ],
          [
            "Huda Huế",
            ""
          ],
          [
            "Thể Công Viettel",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Sơn ĐT.LA",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Quân khu 4",
            ""
          ],
          [
            "Quân khu 5",
            ""
          ],
          [
            "Tây Ninh",
            ""
          ],
          [
            "Đá Mỹ Nghệ TP.HCM",
            ""
          ],
          [
            "XSKT Lâm Đồng",
            ""
          ],
          [
            "CLB BĐ TP.HCM",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2007",
        "n": 14,
        "c": "Thể Công",
        "l": "",
        "k": "",
        "t": [
          [
            "Thể Công Viettel",
            ""
          ],
          [
            "Vạn Hoa Hải Phòng",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Thanh Nghĩa Quảng Ngãi",
            ""
          ],
          [
            "Cần Thơ",
            ""
          ],
          [
            "Xi măng Vinakansai Ninh Bình",
            ""
          ],
          [
            "Giày Thành Công Tiền Giang",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "Tây Ninh",
            ""
          ],
          [
            "Quân khu 4",
            ""
          ],
          [
            "Quân khu 5",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Đá Mỹ Nghệ Sài Gòn",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2008",
        "n": 14,
        "c": "Quân khu 4",
        "l": "",
        "k": "",
        "t": [
          [
            "Quân khu 4",
            ""
          ],
          [
            "Hà Nội T&T",
            ""
          ],
          [
            "Cao su Đồng Tháp",
            ""
          ],
          [
            "Hancofood Cần Thơ",
            ""
          ],
          [
            "Xi măng Vinakansai Ninh Bình",
            ""
          ],
          [
            "Huda Huế",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "Đồng Nai Berjaya",
            ""
          ],
          [
            "SHS Tiền Giang",
            ""
          ],
          [
            "Giày Thành Công Tây Ninh",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Thanh Nghĩa Quảng Ngãi",
            ""
          ],
          [
            "Quân khu 5",
            ""
          ],
          [
            "Quân khu 7",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2009",
        "n": 13,
        "c": "Vissai Ninh Bình",
        "l": "",
        "k": "",
        "t": [
          [
            "XM Vissai Ninh Bình",
            ""
          ],
          [
            "Hòa Phát Hà Nội",
            ""
          ],
          [
            "Thành phố Cần Thơ",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Tây Ninh",
            ""
          ],
          [
            "Quảng Ninh Hạ Long",
            ""
          ],
          [
            "Hà Nội ACB",
            ""
          ],
          [
            "Đồng Nai Biên Hòa",
            ""
          ],
          [
            "Tiền Giang Mỹ Tho",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Sài Gòn United",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2010",
        "n": 13,
        "c": "Hà Nội ACB",
        "l": "",
        "k": "",
        "t": [
          [
            "Hà Nội ACB",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "SQC Bình Định",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Thành phố Cần Thơ",
            ""
          ],
          [
            "TDC Bình Dương",
            ""
          ],
          [
            "Xi măng Fico Tây Ninh",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Thành phố Hồ Chí Minh",
            ""
          ],
          [
            "Huda Huế",
            ""
          ],
          [
            "Đồng Nai Berjaya",
            ""
          ],
          [
            "Hải Nhân Tiền Giang",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2011",
        "n": 14,
        "c": "Xuân Thành Sài Gòn",
        "l": "",
        "k": "",
        "t": [
          [
            "Xuân Thành Sài Gòn",
            ""
          ],
          [
            "Kienlongbank Kiên Giang",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Trẻ Hà Nội T&T",
            ""
          ],
          [
            "QNK Quảng Nam",
            ""
          ],
          [
            "TDC Bình Dương",
            ""
          ],
          [
            "Thành phố Hồ Chí Minh",
            ""
          ],
          [
            "XM Fico Tây Ninh",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Huda Huế",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2012",
        "n": 14,
        "c": "Đồng Tâm Long An",
        "l": "",
        "k": "",
        "t": [
          [
            "Đồng Tâm Long An",
            ""
          ],
          [
            "Trẻ Hà Nội T&T",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Trẻ SHB Đà Nẵng",
            ""
          ],
          [
            "XSKT Lâm Đồng",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "QNK Quảng Nam",
            ""
          ],
          [
            "Trẻ Hà Nội",
            ""
          ],
          [
            "TDC Bình Dương",
            ""
          ],
          [
            "XM Fico Tây Ninh",
            ""
          ],
          [
            "Thành phố Hồ Chí Minh",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2013",
        "n": 8,
        "c": "QNK Quảng Nam",
        "l": "",
        "k": "",
        "t": [
          [
            "QNK Quảng Nam",
            ""
          ],
          [
            "Than Quảng Ninh",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "TĐCS Đồng Tháp",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Hà Nội",
            ""
          ],
          [
            "TDC Bình Dương",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2014",
        "n": 8,
        "c": "TĐCS Đồng Tháp",
        "l": "",
        "k": "",
        "t": [
          [
            "TĐCS Đồng Tháp",
            ""
          ],
          [
            "Sanna Khánh Hòa",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Hà Nội",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "TP. Hồ Chí Minh",
            ""
          ],
          [
            "XM Fico Tây Ninh",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2015",
        "n": 8,
        "c": "Hà Nội",
        "l": "",
        "k": "",
        "t": [
          [
            "Hà Nội",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "TP. Hồ Chí Minh",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Phú Yên",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "Công An Nhân Dân",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2016",
        "n": 10,
        "c": "TP. Hồ Chí Minh",
        "l": "",
        "k": "",
        "t": [
          [
            "TP. Hồ Chí Minh",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Nam Định",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Fico Tây Ninh",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "Phú Yên",
            ""
          ],
          [
            "Cà Mau",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2017",
        "n": 7,
        "c": "Nam Định",
        "l": "",
        "k": "",
        "t": [
          [
            "Nam Định",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "Viettel",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Fico Tây Ninh",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2018",
        "n": 10,
        "c": "Viettel",
        "l": "",
        "k": "",
        "t": [
          [
            "Viettel",
            ""
          ],
          [
            "Hà Nội B",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Fico Tây Ninh",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "Bình Định TMS",
            ""
          ],
          [
            "Công An Nhân Dân",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2019",
        "n": 12,
        "c": "Hồng Lĩnh Hà Tĩnh",
        "l": "",
        "k": "",
        "t": [
          [
            "Hồng Lĩnh Hà Tĩnh",
            ""
          ],
          [
            "Phố Hiến",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "XM Fico Tây Ninh",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Bình Định",
            ""
          ],
          [
            "Phù Đổng",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2020",
        "n": 12,
        "c": "Bình Định",
        "l": "",
        "k": "",
        "t": [
          [
            "Bình Định",
            ""
          ],
          [
            "Bà Rịa – Vũng Tàu",
            ""
          ],
          [
            "Sanna Khánh Hòa BVN",
            ""
          ],
          [
            "Phố Hiến",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "An Giang",
            ""
          ],
          [
            "Tây Ninh",
            ""
          ],
          [
            "XSKT Cần Thơ",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2021",
        "n": 13,
        "c": "",
        "l": "",
        "k": "",
        "t": [
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Bà Rịa – Vũng Tàu",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Phù Đổng",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ],
          [
            "Công An Nhân Dân",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Cần Thơ",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Phú Thọ",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "Phố Hiến",
            ""
          ],
          [
            "An Giang",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2022",
        "n": 12,
        "c": "Công An Nhân Dân",
        "l": "",
        "k": "",
        "t": [
          [
            "Công An Nhân Dân",
            ""
          ],
          [
            "Khánh Hòa",
            ""
          ],
          [
            "Quảng Nam",
            ""
          ],
          [
            "Bà Rịa – Vũng Tàu",
            ""
          ],
          [
            "Phố Hiến",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Cần Thơ",
            ""
          ],
          [
            "Phú Thọ",
            ""
          ],
          [
            "Bình Phước",
            ""
          ],
          [
            "Phù Đổng",
            ""
          ],
          [
            "Đắk Lắk",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2023",
        "n": 10,
        "c": "Quảng Nam",
        "l": "",
        "k": "",
        "t": [
          [
            "Quảng Nam",
            ""
          ],
          [
            "PVF-CAND",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Hòa Bình",
            ""
          ],
          [
            "Bình Thuận",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Phù Đổng",
            ""
          ],
          [
            "Phú Thọ",
            ""
          ],
          [
            "Bà Rịa – Vũng Tàu",
            ""
          ],
          [
            "Bình Phước",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2023-24",
        "n": 11,
        "c": "SHB Đà Nẵng",
        "l": "",
        "k": "",
        "t": [
          [
            "SHB Đà Nẵng",
            ""
          ],
          [
            "PVF-CAND",
            ""
          ],
          [
            "Trường Tươi Bình Phước",
            ""
          ],
          [
            "Huế",
            ""
          ],
          [
            "Phù Đổng Ninh Bình",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Bà Rịa – Vũng Tàu",
            ""
          ],
          [
            "Hòa Bình",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Phú Thọ",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2024-25",
        "n": 11,
        "c": "Phù Đổng Ninh Bình",
        "l": "",
        "k": "",
        "t": [
          [
            "Phù Đổng Ninh Bình",
            ""
          ],
          [
            "Trường Tươi Bình Phước",
            ""
          ],
          [
            "PVF-CAND",
            ""
          ],
          [
            "Trẻ TP. Hồ Chí Minh",
            ""
          ],
          [
            "Khatoco Khánh Hòa",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Hòa Bình",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Đồng Nai",
            ""
          ],
          [
            "Bà Rịa – Vũng Tàu",
            ""
          ],
          [
            "Huế",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      },
      {
        "s": "2025-26",
        "n": 12,
        "c": "Trường Tươi Đồng Nai",
        "l": "",
        "k": "",
        "t": [
          [
            "Trường Tươi Đồng Nai",
            ""
          ],
          [
            "Bắc Ninh",
            ""
          ],
          [
            "TP. Hồ Chí Minh",
            ""
          ],
          [
            "Quy Nhơn United",
            ""
          ],
          [
            "Xuân Thiện Phú Thọ",
            ""
          ],
          [
            "PVF-CAND B",
            ""
          ],
          [
            "Đại học Văn Hiến",
            ""
          ],
          [
            "Khatoco Khánh Hòa",
            ""
          ],
          [
            "Quảng Ninh",
            ""
          ],
          [
            "Đồng Tháp",
            ""
          ],
          [
            "Long An",
            ""
          ],
          [
            "Trẻ TP. Hồ Chí Minh",
            ""
          ]
        ],
        "p": [],
        "r": [],
        "d": []
      }
    ],
    "nc": [
      [
        "1992",
        "Cảng Sài Gòn",
        "CSG",
        "1–1 (luân lưu 5–4)",
        "Quân Đội",
        "TCV"
      ],
      [
        "1993",
        "Quảng Nam-Đà Nẵng",
        "DNA",
        "2–1",
        "Tổng Cục Đường Sắt",
        "TCDS"
      ],
      [
        "1994",
        "Sông Bé",
        "BEC",
        "1–0",
        "Cảng Sài Gòn",
        "CSG"
      ],
      [
        "1995",
        "Công An Hải Phòng",
        "HPH",
        "1–0",
        "Công An Hà Nội",
        "CAH"
      ],
      [
        "1996",
        "Hải Quan",
        "n:Hải Quan",
        "0–0 (luân lưu 6–5)",
        "Cảng Sài Gòn",
        "CSG"
      ],
      [
        "1997",
        "Hải Quan",
        "n:Hải Quan",
        "3–0",
        "Cảng Sài Gòn",
        "CSG"
      ],
      [
        "1998",
        "Công An TP.HCM",
        "HCM",
        "2–0",
        "Hải Quan",
        "n:Hải Quan"
      ],
      [
        "1999/00",
        "Cảng Sài Gòn",
        "CSG",
        "2–1",
        "Công An TP.HCM",
        "HCM"
      ],
      [
        "2000/01",
        "Công An TP.HCM",
        "HCM",
        "2–1",
        "Công An Hà Nội",
        "CAH"
      ],
      [
        "2001/02",
        "Pico Sông Lam Nghệ An",
        "SLN",
        "1–0",
        "Thừa Thiên Huế",
        "HUE"
      ],
      [
        "2003",
        "Pisico Bình Định",
        "QNU",
        "2–1",
        "Ngân Hàng Đông Á",
        "DAB"
      ],
      [
        "2004",
        "Pisico Bình Định",
        "QNU",
        "2–0",
        "Quân Đội",
        "TCV"
      ],
      [
        "2005",
        "Đồng Tâm Long An",
        "LAN",
        "5–0",
        "Hải Phòng",
        "HPH"
      ],
      [
        "2006",
        "Hòa Phát Hà Nội",
        "HPD",
        "2–1",
        "Đồng Tâm Long An",
        "LAN"
      ],
      [
        "2007",
        "Đạm Phú Mỹ Nam Định",
        "NDI",
        "1–0",
        "Pisico Bình Định",
        "QNU"
      ],
      [
        "2008",
        "Hà Nội ACB",
        "ACB",
        "1–0",
        "Becamex Bình Dương",
        "BEC"
      ],
      [
        "2009",
        "SHB Đà Nẵng",
        "DNA",
        "1–0",
        "Thể Công",
        "TCV"
      ],
      [
        "2010",
        "Sông Lam Nghệ An",
        "SLN",
        "1–0",
        "Hoàng Anh Gia Lai",
        "HAG"
      ],
      [
        "2011",
        "Navibank Sài Gòn",
        "NAV",
        "3–0",
        "Sông Lam Nghệ An",
        "SLN"
      ],
      [
        "2012",
        "Sài Gòn Xuân Thành",
        "XTH",
        "4–1",
        "Hà Nội T&T",
        "HNO"
      ],
      [
        "2013",
        "Vissai Ninh Bình",
        "VIS",
        "1–1 (luân lưu 6–5)",
        "SHB Đà Nẵng",
        "DNA"
      ],
      [
        "2014",
        "Hải Phòng",
        "HPH",
        "2–0",
        "Becamex Bình Dương",
        "BEC"
      ],
      [
        "2015",
        "Becamex Bình Dương",
        "BEC",
        "4–2",
        "Hà Nội T&T",
        "HNO"
      ],
      [
        "2016",
        "Than Quảng Ninh",
        "TQN",
        "2 lượt: 4–4, 2–1",
        "Hà Nội T&T",
        "HNO"
      ],
      [
        "2017",
        "Sông Lam Nghệ An",
        "SLN",
        "2 lượt: 2–1, 5–1",
        "Becamex Bình Dương",
        "BEC"
      ],
      [
        "2018",
        "Becamex Bình Dương",
        "BEC",
        "3–1",
        "FLC Thanh Hóa",
        "THA"
      ],
      [
        "2019",
        "Hà Nội",
        "HNO",
        "2–1",
        "Quảng Nam",
        "QNA"
      ],
      [
        "2020",
        "Hà Nội",
        "HNO",
        "2–1",
        "Viettel",
        "TCV"
      ],
      [
        "2021",
        "",
        "",
        "",
        "",
        ""
      ],
      [
        "2022",
        "Hà Nội",
        "HNO",
        "2–0",
        "Topenland Bình Định",
        "QNU"
      ],
      [
        "2023",
        "Đông Á Thanh Hóa",
        "THA",
        "0–0 (luân lưu 5–3)",
        "Viettel",
        "TCV"
      ],
      [
        "2023/24",
        "Đông Á Thanh Hóa",
        "THA",
        "0–0 (luân lưu 9–8)",
        "Hà Nội",
        "HNO"
      ],
      [
        "2024/25",
        "Công An Hà Nội",
        "CAH",
        "5–0",
        "Sông Lam Nghệ An",
        "SLN"
      ],
      [
        "2025/26",
        "Công An TP.HCM",
        "HCM",
        "2–1",
        "Ninh Bình",
        "NBI"
      ]
    ]
  },
  "goals": {
    "vl1": [
      [
        "Milan Makaric",
        "HPH",
        8
      ],
      [
        "Daniel Floro Da Silva",
        "HLH",
        6
      ],
      [
        "Goncalves Silva Lucas Vinicius",
        "NBI",
        5
      ],
      [
        "Tagueu Tadjo Diederrick Joel",
        "HPH",
        5
      ],
      [
        "Saliou Guindo",
        "THA",
        4
      ],
      [
        "Alan Sebastiao Alexandre",
        "CAH",
        4
      ],
      [
        "Luiz Antonio De Souza Soares",
        "HLH",
        4
      ],
      [
        "Nguyễn Lê Phát",
        "NBI",
        4
      ],
      [
        "Luiz Guilherme Vieira Da Silva",
        "SLN",
        4
      ],
      [
        "Caio César da Silva Silveira",
        "NDI",
        3
      ],
      [
        "Nguyễn Quang Vinh",
        "SLN",
        3
      ],
      [
        "Ivan Saponjic",
        "DNA",
        3
      ],
      [
        "Leonardo Artur De Melo",
        "CAH",
        3
      ],
      [
        "Brenner Marlos Varanda De Oliveira",
        "BNI",
        3
      ],
      [
        "Luann Augusto Xavier Boy",
        "HAG",
        3
      ],
      [
        "Trần Ngọc Sơn",
        "NDI",
        3
      ]
    ],
    "vl2": [
      [
        "Mansaray Victor Nabay",
        "TNG",
        11
      ],
      [
        "Joseph Shaqkeem Jaylon Khalio",
        "HYE",
        8
      ],
      [
        "Daniel Da Silva Dos Anjos",
        "BEC",
        6
      ]
    ]
  },
  "sources": {
    "rule-vl1": ["Điều lệ V.League 1 2026/27", "https://vpf.vn/wp-content/uploads/2026/08/2026-08-26-Dieu-le-Giai-VDQG-LPBank-2026-27.pdf#page=18"],
    "rule-vl2": ["Điều lệ V.League 2 2026/27", "https://vpf.vn/wp-content/uploads/2026/08/2026-08-26-Dieu-le-Giai-HNQG-2026-27.pdf#page=17"],
    "afc-slots": ["Phân bổ suất AFC 2027/28", "https://assets.the-afc.com/downloads/tournament-regulations/AFC-Club-Comps-2027-28-Slot-Allocation.pdf#page=2"],
    "plan": [
      "VPF · Thông báo 296/TB-VPF, 21/11/2026",
      "https://vpf.vn/tin-tuc/tin-vleague/thong-bao-v-v-dieu-chinh-ke-hoach-thi-dau-va-ban-hanh-lich-thi-dau-giai-doan-2-cac-giai-bdcn-qg-2026-27/"
    ],
    "rule": [
      "VPF · Điều lệ Cúp Quốc gia 2026/27",
      "https://vpf.vn/tin-tuc/tin-cup-quoc-gia/dieu-le-giai-bong-da-cup-quoc-gia-2026-27/"
    ],
    "r9": [
      "VPF · Lịch vòng 9, sân và kênh phát",
      "https://vpf.vn/season/v-league-2027/"
    ],
    "vl1cal": [
      "VPF · Lịch và kết quả V.League 1",
      "https://vpf.vn/season/v-league-2027/?action=calendar"
    ],
    "vl2cal": [
      "VPF · Lịch và kết quả V.League 2",
      "https://vpf.vn/season/hang-nhat-quoc-gia-2027/?action=calendar&pagejs=1"
    ],
    "cupcal": [
      "VPF · Lịch và kết quả Cúp Quốc gia",
      "https://vpf.vn/season/cup-quoc-gia-2027/?action=calendar&pagejs=1"
    ],
    "cupPairs": [
      "VPF · Kết quả vòng loại và các cặp vòng 1/8",
      "https://vpf.vn/tin-tuc/tin-cup-quoc-gia/xac-dinh-cac-cap-dau-vong-1-8-cup-qg-sacombank-2026-27/"
    ],
    "vl1table": [
      "VPF · Bảng xếp hạng V.League 1",
      "https://vpf.vn/season/v-league-2027/"
    ],
    "vl2table": [
      "VPF · Bảng xếp hạng V.League 2",
      "https://vpf.vn/season/hang-nhat-quoc-gia-2027/"
    ],
    "v1goals": [
      "VPF · Thống kê ghi bàn V.League 1",
      "https://vpf.vn/top-vua-pha-luoi/?sid=154439"
    ],
    "v2goals": [
      "VPF · Thống kê nổi bật V.League 2",
      "https://vpf.vn/"
    ],
    "v2ref": [
      "Flashscore · Lịch tham chiếu V.League 2",
      "https://www.flashscore.com/football/vietnam/v-league-2/fixtures/"
    ],
    "archive": [
      "Dữ liệu kế thừa từ ZIP gốc",
      null
    ],
    "vl1r1": [
      "VPF · Số liệu vòng 1 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-1-vdqg-lpbank-2026-27/"
    ],
    "vl1r2": [
      "VPF · Số liệu vòng 2 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-2-vdqg-lpbank-2026-27/"
    ],
    "vl1r3": [
      "VPF · Số liệu vòng 3 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-3-lpbank-v-league-1-2026-27/"
    ],
    "vl1r4": [
      "VPF · Số liệu vòng 4 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-4-lpbank-v-league-1-2026-27/"
    ],
    "vl1r5": [
      "VPF · Số liệu vòng 5 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-5-lpbank-v-league-1-2026-27/"
    ],
    "vl1r6": [
      "VPF · Số liệu vòng 6 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-6-lpbank-v-league-1-2026-27/"
    ],
    "vl1r7": [
      "VPF · Số liệu vòng 7 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-7-lpbank-v-league-1-2026-27/"
    ],
    "vl1r8": [
      "VPF · Số liệu vòng 8 V.League 1",
      "https://vpf.vn/tin-tuc/tin-vleague/so-lieu-chuyen-mon-sau-vong-8-lpbank-v-league-1-2026-27/"
    ],
    "vl2r1": [
      "VPF · Số liệu vòng 1 V.League 2",
      "https://vpf.vn/hang-nhat-tai-lieu/hang-nhat-thong-bao/so-lieu-chuyen-mon-sau-vong-1-sacombank-v-league-2-2026-27/"
    ],
    "vl2r2": [
      "VPF · Số liệu vòng 2 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-2-sacombank-v-league-2-2026-27/"
    ],
    "vl2r3": [
      "VPF · Số liệu vòng 3 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-3-sacombank-v-league-2-2026-27/"
    ],
    "vl2r4": [
      "VPF · Số liệu vòng 4 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-4-sacombank-v-league-2-2026-27/"
    ],
    "vl2r5": [
      "VPF · Số liệu vòng 5 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-5-sacombank-v-league-2-2026-27/"
    ],
    "vl2r6": [
      "VPF · Số liệu vòng 6 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-6-sacombank-v-league-2-2026-27/"
    ],
    "vl2r7": [
      "VPF · Số liệu vòng 7 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-7-sacombank-v-league-1-2026-27/"
    ],
    "vl2r8": [
      "VPF · Số liệu vòng 8 V.League 2",
      "https://vpf.vn/tin-tuc/tin-hang-nhat/so-lieu-chuyen-mon-sau-vong-8-sacombank-v-league-2-2026-27/"
    ],
    "cupOriginalWindow": [
      "VPF · Khung dự kiến vòng 1/8 công bố ngày 07/10/2026",
      "https://vpf.vn/tin-tuc/tin-cup-quoc-gia/xac-dinh-cac-cap-dau-vong-1-8-cup-qg-sacombank-2026-27/"
    ]
  },
  "news": {
    "vl1": [
      "vl1r8",
      "plan"
    ],
    "vl2": [
      "vl2r8",
      "plan",
      "rule"
    ],
    "nc": [
      "plan",
      "cupPairs",
      "rule"
    ]
  }
};
