# VPF App 2.4.2 rev16

## Mở trên laptop

1. Giải nén gói Source rồi mở `index.html` bằng Chrome hoặc Edge. Gói này có lịch, kết quả và chi tiết đã lưu, dùng được khi mất mạng. Liên kết nguồn, video và phát sóng cần kết nối mạng.
2. Mở DevTools bằng **Ctrl + Shift + I**, rồi bật khung điện thoại bằng **Ctrl + Shift + M**. Có thể chọn Responsive, nhập **320 × 640** hoặc **390 × 844**.
3. Để thử gói Web, mở Terminal trong thư mục đã giải nén, chạy `python -m http.server 8000` rồi mở [localhost:8000](http://localhost:8000). Gói Web phục vụ dữ liệu chi tiết theo yêu cầu. Mở bằng HTTP cục bộ hoặc HTTPS để dùng đủ chức năng.

Trên iPhone, các API trình duyệt mà app dùng yêu cầu ít nhất Safari 15.4. Đợt này kiểm tra riêng đường dẫn trận khi trình duyệt thiếu `URLSearchParams.size`. Nghiệm thu cài PWA và lịch đăng ký vẫn cần thực hiện trên iPhone và Android thật. Mở **Nguồn dữ liệu** để xem revision đang dùng.

Mở **CLB → Tìm CLB** để xem sân nhà, HLV trưởng, năm thành lập nếu xác nhận được và **Danh sách đăng ký cầu thủ**. Để xem **Vua phá lưới**, mở **Thống kê → Cầu thủ**. Chọn **Thu gọn** để xem 15 người hoặc **Đầy đủ** để xem toàn bộ. Ở Cúp Quốc gia, mở **Nhánh đấu → Sơ đồ** để xem hai nhánh và khu vực chung kết. Vòng loại mở riêng ngay dưới sơ đồ. Từ trang trận, có thể mở **Đội hình và thay người** hoặc **Nguồn và đối chiếu**. **Sao chép link lịch CLB** dùng để đăng ký lịch bằng URL. Thao tác **Thêm vào lịch** tạo một tệp riêng cho trận.

**Theo dõi** có **Đội của tôi** và **Trận đã lưu**. Chọn một đội đã theo dõi để xem tối đa năm trận tới và năm kết quả gần nhất ở các giải có trong ứng dụng. Danh sách đội và danh sách trận đã lưu được lọc theo giải đang mở. Trên điện thoại, chuyển giữa hai mục bằng nút đầu trang và vuốt ngang danh sách đội hoặc dùng hai nút chuyển đội.

**Bảng xếp hạng** tách Bàn thắng và Bàn thua. Màu đánh dấu vị trí cuối mùa theo Điều 27 của từng giải. Xem các điều kiện cấp phép, thay đại diện và liên kết văn bản chính thức bên dưới bảng.

**Thống kê → Câu lạc bộ** có bộ lọc Bàn thắng, Bàn thua, Thẻ vàng và Thẻ đỏ. Chế độ Thu gọn hiện 7 đội. Chế độ Đầy đủ hiện 14 đội ở mỗi giải V.League và 27 đội ở Cúp Quốc gia. Các đội có cùng số liệu đồng hạng. Dấu — chỉ đội chưa có số liệu cho chỉ số đang xem. Bàn thắng và bàn thua tính từ tỷ số, không cộng luân lưu. Số thẻ lấy từ tổng số VPF đã đối chiếu hoặc từ diễn biến trận Cúp. Truất quyền thi đấu do thẻ vàng thứ hai được tính vào thẻ đỏ.

Nút mặt trăng hoặc mặt trời ở góc trên chuyển giao diện sáng và tối. Ứng dụng mặc định theo thiết bị và nhớ lựa chọn trong trình duyệt.

## Dữ liệu mùa 2026/27 · ngày 26/11/2026

| Giải | Trận đã đấu có diễn biến và đội hình | Trận có đủ 11 cầu thủ xuất phát của mỗi đội | Bàn trong diễn biến |
|---|---:|---:|---:|
| V.League 1 | 55/55 | 52/55 | 146 |
| V.League 2 | 56/56 | 56/56 | 157 |
| Cúp Quốc gia | 11/11 | 11/11 | 33 |

Hồ sơ mùa 2026/27 đã được đối chiếu trên trang VPF của **28/28 CLB**, gồm **789 cầu thủ**. Danh sách chỉ hiển thị tên, vị trí và số áo. Những mốc năm thành lập và vị trí chưa được xác nhận không được suy ra từ tên hoặc nhà tài trợ. Người dùng có thể xem hai nhóm **Xuất phát** và **Dự bị** của từng trận, cùng mốc **Vào sân** và **Rời sân** khi nguồn cung cấp.

| Vua phá lưới | Cầu thủ đã ghi bàn | Bàn tính cho cầu thủ | Dẫn đầu |
|---|---:|---:|---|
| V.League 1 | 73 | 141 | Milan Makaric · 8 bàn |
| V.League 2 | 83 | 152 | Mansaray Victor Nabay · 11 bàn |
| Cúp Quốc gia | 28 | 33 | Brenner Marlos Varanda De Oliveira · 3 bàn |

Bảng dùng các trận đã kết thúc và sự kiện ghi bàn đã kiểm chứng. Bàn phạt đền trong trận được tính. Phản lưới, cú sút phạt đền hỏng và luân lưu được loại khỏi bảng. Người cùng số bàn đồng hạng. Trong nhóm đồng hạng, dùng tên để sắp thứ tự hiển thị. Nếu người ghi bàn có mã hồ sơ VPF, có thể gộp số bàn ở hai CLB trong cùng giải. Khi bản ghi được sửa, bảng tính lại từ toàn bộ trận đã chấp nhận.

- Kiểm tra 67 trận mới theo đội, ngày và tỷ số giữa lịch VPF và trang trận. 190 bàn khớp tỷ số từng đội. Các đối chiếu ngoài VPF được ghi theo từng trận hoặc từng trường đã kiểm tra.
- **Xuân Thiện Phú Thọ 1–2 Becamex.** Báo cáo trận VPF ghi Nguyễn Trần Việt Cường (số 7) ghi bàn phút 67. Trang trận VPF và Sofascore ghi Phan Thanh Hậu. Danh sách đăng ký trận và báo cáo đều không có Phan Thanh Hậu. Bản xuất bản dùng báo cáo trận, ghi lại sự khác biệt.
- **Hoàng Anh Gia Lai 2–3 Hưng Yên.** Các bàn của Khalio ở 74′ và 77′. Lucas ở 61′ và 94′ theo cách VPF hiển thị. DBscore ghi cùng các mốc, với bàn 94′ viết là 90+4′.
- **Thép Cần Thơ 2–0 Lâm Đồng.** Trang trận thiếu đội hình Thép Cần Thơ. Bản 2.4 dùng báo cáo trận và đối chiếu danh sách đăng ký. Phút vào sân của Hà Văn Việt được để trống do ghi chú nguồn lỗi định dạng. Một số mốc thay người khác có ghi chú tại **Nguồn và đối chiếu**.
- Các trận chưa có kết quả vẫn có lịch theo mốc đã công bố. Bản dữ liệu ngày 26/11/2026 ghép được 99 video VPF trên 122 trận đã đấu và có 3 liên kết trang phát sóng. Các liên kết phụ thuộc vào trang của nhà cung cấp.

## Cấu trúc mã nguồn

| Tệp | Trách nhiệm |
|---|---|
| `app.js` | Điều hướng, bộ lọc, theo dõi, danh sách trận và CLB |
| `match-view.js` | Tỷ số, diễn biến, đội hình, thống kê và nguồn |
| `competition-view.js` | Bảng xếp hạng, Vua phá lưới, thống kê CLB và sơ đồ Cúp |
| `theme.js` | Cài đặt giao diện sáng/tối theo hệ thống và theo lựa chọn của người dùng |
| `web-data.js` | Tải chi tiết theo yêu cầu, thử lại, kiểm tra bản phát hành |
| `data-update.js` | Ghép dữ liệu và kiểm tra quy tắc trận, bảng và Cúp |
| `data.js`, `updates.json` | Dữ liệu nền, mã trận ổn định và các sửa đổi đã duyệt |
| `tools/import-vpf.py`, `tools/backfill-vpf.py`, `tools/vpf_clubs.py` | Đọc VPF và tạo bản nháp kèm nguồn |
| `tools/sync-vpf.py`, `tools/vpf_highlights.py` | Đồng bộ ba giải và video VPF, phát hành theo lịch trên máy chủ |
| `tools/publish.cjs` | Kiểm tra dữ liệu, tái tạo lịch và bản dùng ngoại tuyến |
| `tools/audit.py`, `tools/release.py` | Nhật ký SQLite riêng, niêm phong đầu vào và đóng gói Web |
| `tools/check*` | Kiểm thử dữ liệu, lịch, đồng bộ, tệp phát hành và trình duyệt |

## Cập nhật và phát hành

Cài Node.js 22 trở lên, Python 3.10 trở lên và curl. Cài các gói Python bằng `python -m pip install lxml "Pillow>=10.1" "fonttools[woff]"`. Trong nhóm biên tập, lưu cùng bản Node và Python khi cần tái tạo đúng từng byte.

1. Tạo bản nháp của mùa hiện tại. Dùng thư mục cache mới khi muốn kiểm tra HTML mới nhất. Importer khớp đúng giải, mùa, hai CLB, ngày, giờ và tỷ số. Bản nháp nhận đổi ngày, giờ, sân và thông báo hoãn cho trận đã nhận diện. Mã trận mới cần bổ sung vào dữ liệu nền sau khi đối chiếu văn bản VPF. Giờ ghi trong lịch cả mùa chưa đủ để chuyển một trận dự kiến thành đã xác nhận. Với kết quả vừa công bố ở Hạng Nhất hoặc Cúp, thêm `--include-new-results` và duyệt BXH hoặc loạt luân lưu trước khi xuất bản.

   ```text
   python tools/import-vpf.py --round 9 --out ../vl1-draft.json
   python tools/backfill-vpf.py --cache ../vpf-html --out ../draft.json --report ../import-report.json
   ```

2. Duyệt từng trường khác nhau. Bổ sung dữ liệu có nguồn, giữ thứ tự lịch sử và tăng `revision`. Kiểm tra số điểm, hiệu số, số bàn và bàn sân khách theo điều lệ xếp hạng tạm thời của cả hai giải. Với xếp hạng cuối mùa, dùng thứ hạng chính thức đã xác minh. Quy tắc Cúp kiểm tra loạt luân lưu ở cặp một trận hoặc ở lượt về khi tổng tỷ số hòa.

   ```text
   node tools/publish.cjs --verify-next ../draft.json
   python tools/audit.py --db ../private/review.sqlite record ../draft.json
   python tools/release.py --db ../private/review.sqlite --draft ../draft.json --out ../releases/next
   node tools/publish.cjs ../draft.json
   python tools/check-release.py ../releases/next
   ```

   Tạo trước thư mục `../private`. SQLite lưu dữ liệu duyệt, tên trường, nguồn và hàm băm của mã nguồn, dữ liệu, công cụ build. Build Web ghi dấu vân tay của toàn bộ tệp đầu ra. Phiên bản đã duyệt phải có cùng nội dung khi tái dựng.

3. Triển khai thư mục đầu ra cùng một lần sau thử nghiệm. Giữ lại đường dẫn `releases/<mã bản>` của bản trước trong giai đoạn chuyển tiếp. Phục vụ HTML, worker, manifest, release-info và ICS với chế độ kiểm tra lại. Tài nguyên trong thư mục có mã bản dùng cache dài hạn. Khi có bản dữ liệu mới, người dùng có thể bấm **Kiểm tra cập nhật** để mở. Đăng ký lịch qua URL giữ định danh sự kiện và tăng `SEQUENCE` khi lịch đổi. Thời điểm đồng bộ phụ thuộc ứng dụng lịch.

## Đồng bộ sau khi đưa lên máy chủ

Chạy thử bằng `python tools/sync-vpf.py --state ../vpf-state`. Lệnh đọc lịch và hồ sơ VPF mới, ghi nhật ký kiểm tra và tạo bản nháp nếu phát hiện thay đổi đủ điều kiện.

Trên máy chủ Linux, dùng `python tools/sync-vpf.py --state /srv/vpf-state --publish` sau khi thử bản nháp. Phục vụ `/srv/vpf-state/site/current` trên HTTPS. Dùng tài khoản phục vụ có quyền đọc đúng thư mục web và tài nguyên phiên bản được liên kết. Giữ SQLite, bản nháp và các nhật ký ngoài web root. Thử cấu hình quyền đọc bằng tài khoản chạy web server.

Đặt tác vụ đồng bộ theo giờ. Lịch trước trận được kiểm tra mỗi lần chạy. Kết quả đã đấu được đọc lại trong 10 ngày gần nhất và toàn mùa mỗi 24 giờ. Dùng `--all` để kiểm tra toàn mùa ngay. Chỉ dùng `--cache` để phát lại dữ liệu HTML khi kiểm thử. Xem `latest-check.json` cho lần kiểm tra gần nhất và `review-queue.json` cho các hồ sơ còn chờ đối chiếu.

Cấu hình giám sát chạy `python tools/sync-vpf.py --state /srv/vpf-state --check-health`. Lệnh trả mã lỗi nếu lần chạy cuối lỗi hoặc đã quá 3 giờ từ lần đọc nguồn thành công. Tùy chọn `--max-age-hours` đặt ngưỡng riêng. Nếu dùng cron, chuyển mã lỗi và stderr đến hệ thống cảnh báo của máy chủ. `sync-status.json` lưu mốc chạy và số hồ sơ đang chờ.

Mỗi gói niêm phong nằm trong `versions/rev-N`. Dùng `check-release.py` trên gói độc lập này. `site/current` trỏ vào một thư mục trong `deployments` có tài nguyên của bản đang phục vụ và bản ngay trước. Để khôi phục trên staging, tạm dừng job đồng bộ, xác minh gói đích, rồi thay symlink `current` nguyên tử về thư mục triển khai đã biết. Mở thử lịch, trang trận và lịch CLB. Trên tab còn mở, bấm **Kiểm tra cập nhật** để nạp bản đang phục vụ. Sau khi khắc phục lỗi, tiếp tục bằng revision cao hơn. Giữ thư mục của bản đang chạy, bản dự phòng và các tài nguyên mà chúng liên kết khi dọn đĩa.

Kết quả mới hoặc sửa phải khớp lịch, trang trận và diễn biến. Tỷ số luân lưu phải khớp cả hai nguồn và thể thức Cúp. Hai giải V.League cần bảng điểm VPF khớp kết quả. Trường hợp nguồn thiếu, khác nhau hoặc dữ liệu đã được duyệt từ báo cáo trận thì giữ bản đang dùng và ghi vào nhật ký để xử lý. Trận mới ngoài lịch nền hoặc mùa khác cần bổ sung cấu hình và mã trận. Khi cần sửa bản đã công bố, xuất bản một revision mới.

Các lệnh kiểm tra cho gói này:

```text
node tools/check.cjs
python tools/check-calendar.py .
python tools/check-sync.py
python tools/check-highlights.py
python -m pip install playwright
playwright install chromium
python tools/check-browser.py ../releases/next
```

Gói Web có cấu hình PWA và biểu tượng để thêm vào màn hình chính. Sau khi đã mở trang trên máy chủ đủ điều kiện, lịch và chi tiết từng xem có thể mở lại từ bộ nhớ đệm khi mất mạng. Trải nghiệm cài đặt iOS/Android và lịch đăng ký bằng tài khoản thật cần thử riêng trước beta công khai. Trước khi công bố, xác nhận quyền sử dụng dữ liệu và nhận diện, rồi thử các tác vụ chính với fan của cả ba giải.

**Video tổng hợp.** Mỗi lần chạy đồng bộ, máy chủ đọc mục video của VPF và đối chiếu ngày đăng, mùa, giải và cặp đấu đã kết thúc. Bài đăng mới được tìm theo ngày đăng và lượt rà soát toàn mùa lặp lại mỗi 24 giờ. Thông tin đối chiếu và lỗi nguồn ghi trong `highlight-check.json`. Lần gần nhất đọc được kho video ghi trong `sync-status.json`. Nút xem mở trang bài gốc của VPF, nơi VPF cung cấp trình phát. Trận chưa kết thúc hoặc bài chưa ghép chắc chắn sẽ không tự nhận link. Khi chỉ giải nén Web, bộ dữ liệu là ảnh chụp tại thời điểm build. Muốn cập nhật từ VPF, cần chạy tác vụ đồng bộ ở máy chủ và giữ lịch chạy theo giờ như trên. Trình duyệt kiểm tra phiên bản mới mỗi năm phút.

## Nguồn chính

- [Lịch V.League 1](https://vpf.vn/season/v-league-2027/?action=calendar)
- [Lịch V.League 2](https://vpf.vn/season/hang-nhat-quoc-gia-2027/?action=calendar&pagejs=1)
- [Lịch Cúp Quốc gia](https://vpf.vn/season/cup-quoc-gia-2027/?action=calendar&pagejs=1)
- [Quyết định và điều lệ mùa 2026/27](https://vpf.vn/tin-tuc/tin-vleague/quyet-dinh-ban-hanh-dieu-le-cac-giai-bong-da-chuyen-nghiep-quoc-gia-2026-27/)
- [Phông Inter](https://rsms.me/inter/). Giấy phép đi kèm trong `assets/`.

## Tin tức

Mục Tin tức gom liên kết từ Bóng Đá Plus, Thanh Niên, Znews, VTC News, VnExpress và VFF. Chỉ lưu tiêu đề, thời gian đăng, URL, nguồn và nhãn giải/CLB. Dùng nhận diện giải, CLB và nguồn để minh họa thẻ. Người đọc mở bài tại trang báo. Bộ lọc có ba giải và 28 CLB, dựa trên tên và biến thể tên có trong dữ liệu mùa giải. Từ khóa trùng với đội tuyển, bóng đá trẻ hoặc cúp quốc tế có thể tạo ca cần rà thêm.

Bản đính kèm có 70 liên kết từ sáu nguồn được kiểm tra lúc 12:15 ngày 27/11/2026. Bóng Đá Plus được đọc từ trang Bóng đá Việt Nam và ba chuyên mục giải. Link trên trang tổng phải thuộc một trong ba chuyên mục đó. Bài trùng URL chỉ xuất hiện một lần. Tệp bản chụp có `mode: snapshot`. Tệp do tác vụ máy chủ cập nhật có `mode: sync`. Giao diện ghi rõ khi đang dùng bản chụp hoặc nguồn gián đoạn. Tin lấy được vẫn phục vụ trong thời hạn lưu khi nguồn tạm thời lỗi.

- Nguồn HTML và RSS nằm trong `tools/sync-news.py`. Bật đồng bộ trên máy chủ bằng `python tools/sync-news.py --output /srv/vpf-news/news-feed.json`. Sau mỗi lần, chương trình ghi JSON nguyên tử và xuất số bài theo nguồn. Mã thoát khác 0 báo nguồn bị lỗi hoặc chưa có tin, dù các nguồn còn lại vẫn có thể xuất bản.
- Đặt tác vụ riêng **mỗi 5 phút** bằng systemd timer hoặc cron. Với cron trên Linux, dùng khóa để tránh chạy chồng, ví dụ `*/5 * * * * flock -n /srv/vpf-news/sync.lock /opt/vpf/.venv/bin/python /opt/vpf/tools/sync-news.py --output /srv/vpf-news/news-feed.json`. Trên máy chủ thật, gửi lỗi liên tiếp và mốc dữ liệu cũ tới người vận hành. Đây là lịch lấy tin, thời điểm bài xuất hiện còn phụ thuộc nguồn và cache.
- Phục vụ đường dẫn `/news-feed.json` cùng origin với Web, ưu tiên tệp cập nhật trong `/srv/vpf-news/`. Nếu tệp chưa tồn tại, phục vụ ảnh chụp JSON đã đóng gói. Đặt `Cache-Control: public, max-age=60, stale-while-revalidate=30` cho JSON tin tức tại CDN, phục vụ `application/json` và nén. Giữ thư mục tin ngoài thư mục niêm phong và ánh xạ riêng trên máy chủ. Giữ `no-cache` cho metadata trận, service worker, HTML và lịch ICS, cùng `immutable` cho tài nguyên trong `releases/<mã-bản>/`.
- App chỉ yêu cầu JSON khi mở mục Tin tức, rồi kiểm tra lại trong tab đang hiển thị sau khoảng 5 phút. Trang đầu hiện 12 bài và mở thêm từng nhóm 12. Tệp dữ liệu giữ tối đa 20 bài mỗi nguồn và 120 bài tổng. Bản Source mở offline có ảnh chụp tin và bản Web có thể xem lại bản tin đã lưu.
- Bản Web phục vụ qua HTTPS và giới hạn CSP theo origin. Trên hosting sản xuất, đặt thêm HTTP `Content-Security-Policy: frame-ancestors 'none'` và HSTS sau khi xác nhận HTTPS. Khóa định danh sự kiện lịch đang giữ để lịch đã đăng ký tiếp tục theo đúng sự kiện. Rà lại tên miền lịch công khai và nghiệm thu trên thiết bị thật trước khi thay đổi định danh.
- Kiểm thử trình gom tin với `python tools/check-news.py` và `python tools/check-news-web.py ../releases/next`. Nghiệm thu tác vụ thật trên hosting bằng hai lần xuất bản JSON và mở lại tab Tin tức để kiểm tra thứ tự thời gian, lọc nguồn và khả năng đọc khi mất mạng.

### Đối chiếu báo cáo kiểm thử Gemini

Rev14 chỉnh màu theo thứ hạng hiển thị trong BXH, giới hạn kiểm tra bản phát hành nền một lần mỗi 60 giây, dừng tự tải lại màn Thống kê, bỏ `file:` trong CSP Web và ghi revision để giữ cache đã đánh dấu gần nhất. Logo giải và icon cài app được nạp khi cài service worker. Tab chi tiết trận đã đấu chưa có video vẫn có thể nhận bản mới theo luồng trước đây.

Bản dữ liệu vẫn có 9 trận lệch thẻ vàng và 4 trận lệch thẻ đỏ giữa tổng số và diễn biến. Cần đối chiếu bản ghi trận, đặc biệt các lần truất quyền do thẻ vàng thứ hai, trước khi sửa số. Các hồ sơ còn thiếu cầu thủ xuất phát hoặc năm thành lập giữ trạng thái hiện tại. Việc thử Apple Calendar và Google Calendar trên thiết bị thật, cấu hình header bảo vệ và giám sát trên hosting thật, ảnh xem trước chia sẻ, cùng những tính năng phân tích mới thuộc các đợt nghiệm thu tiếp theo.

## Rev15 · Nghiệm thu dữ liệu đang phục vụ

**Data-status và bản tin.** Hộp trạng thái ở đầu Web cho biết khi nào người dùng đang xem bản chụp, hoặc khi chưa xác nhận được một lần đọc mới từ VPF. Mốc trong chân trang là lần trình duyệt đọc bản phát hành. Hai mốc này khác nhau. Màn Tin tức hiển thị mốc đọc nguồn thành công và báo nếu dùng dữ liệu cũ. Ca thẻ có chênh lệch hiển thị hai số đối chiếu và nêu rõ thứ tự đội.

**Phục vụ Web trên Linux.** Dùng Caddy với cấu hình ví dụ `deploy/Caddyfile`, thư mục phát hành do `sync-vpf.py --publish` quản lý và một thư mục riêng cho hai JSON động. Các unit trong `deploy/systemd` giả định Source ở `/opt/vpf`, Python venv ở `/opt/vpf/.venv` và Node trên PATH của dịch vụ. Tạo tài khoản dịch vụ `vpf` với nhóm `vpf-web`. Cho tài khoản chạy Caddy thêm nhóm này. Hai thư mục trạng thái có mode `0750`, thư mục `/var/lib/vpf-sync/deployments` có mode `2750` và thuộc `vpf:vpf-web`. Cần ghi được tệp phát hành sinh ra trong cây Source `/opt/vpf`. Web chỉ phục vụ thư mục `site/current` và hai JSON động theo tên tệp. Kiểm tra quyền đọc bằng chính tài khoản web server trước khi mở cổng public.

Cấu hình biến `VPF_DOMAIN` bằng tên miền TLS. Có thể đổi `VPF_WEB` và `VPF_LIVE` nếu sử dụng đường dẫn khác. Chạy hai service một lần và kiểm tra trên trình duyệt trước khi bật timer. Lịch trận đọc nguồn mỗi giờ, tin tức mỗi 5 phút, kiểm tra sức khỏe mỗi 15 phút. Kết nối lỗi service và thông báo dữ liệu cũ với hệ thống giám sát của nơi triển khai. Unit hiện ghi kết quả vào nhật ký systemd. Người vận hành cần xác nhận đường nhận cảnh báo thật.

**Kiểm chứng.** `python tools/check-beta.py https://<tên-miền>` kiểm tra quyền phục vụ dữ liệu qua TLS, mã bản và service worker, tệp ICS, cache và mốc đọc nguồn. Lệnh trả mã lỗi nếu có nguồn gián đoạn. `--snapshot` bỏ kiểm tra tính mới, dùng cho bản chụp staging. `node tools/check-load.cjs http://127.0.0.1:8975 30000 256` chỉ chạy với máy chủ hoặc container trên loopback. Kết quả tải cục bộ không thay cho số liệu tải trên CDN và máy chủ dự định triển khai.
